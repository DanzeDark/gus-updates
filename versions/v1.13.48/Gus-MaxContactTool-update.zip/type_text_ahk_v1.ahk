#NoEnv
#SingleInstance Force
SetBatchLines, -1
SendMode, Event
FileEncoding, UTF-8

if (A_Args.Length() < 1) {
    ExitApp, 2
}

textFile := A_Args[1]
pressEnter := "1"
if (A_Args.Length() >= 2) {
    pressEnter := A_Args[2]
}

FileRead, text, %textFile%
if (ErrorLevel) {
    ExitApp, 3
}

Sleep, 350

Loop, Parse, text
{
    SendRaw, %A_LoopField%
    Random, delay, 18, 45
    Sleep, %delay%
}

if (pressEnter = "1") {
    Sleep, 450
    Send, {Enter}
}

ExitApp, 0
