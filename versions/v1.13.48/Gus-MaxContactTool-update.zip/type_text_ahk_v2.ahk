#Requires AutoHotkey v2.0
#SingleInstance Force

if (A_Args.Length < 1) {
    ExitApp 2
}

textFile := A_Args[1]
pressEnter := "1"
if (A_Args.Length >= 2) {
    pressEnter := A_Args[2]
}

try {
    text := FileRead(textFile, "UTF-8")
} catch {
    ExitApp 3
}

Sleep 350

for ch in StrSplit(text) {
    SendText ch
    Sleep Random(18, 45)
}

if (pressEnter = "1") {
    Sleep 450
    Send "{Enter}"
}

ExitApp 0
