﻿param(
    [string]$TrainingPath = "",
    [string]$StartMessagesPath = "",
    [string]$AiConfigPath = "",
    [string]$AiModel = "",
    [string]$Once = "",
    [switch]$Trace,
    [switch]$NoRealAI,
    [switch]$LibraryMode
)

$ErrorActionPreference = 'Stop'
try {
    [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
    [Console]::InputEncoding = [System.Text.Encoding]::UTF8
}
catch {
}

if ([string]::IsNullOrWhiteSpace($TrainingPath)) {
    $TrainingPath = Join-Path $PSScriptRoot 'ai_training_examples.json'
}

if ([string]::IsNullOrWhiteSpace($StartMessagesPath)) {
    $StartMessagesPath = Join-Path $PSScriptRoot 'домофон_и_MAX_12_июля.txt'
}

if ([string]::IsNullOrWhiteSpace($AiConfigPath)) {
    $AiConfigPath = Join-Path $PSScriptRoot 'gus_ai_config.json'
}

function Import-ChatEnvFile {
    param([string]$Root)

    $envPath = Join-Path $Root '.env'
    if (-not (Test-Path -LiteralPath $envPath -PathType Leaf)) { return }
    try {
        foreach ($line in @(Get-Content -LiteralPath $envPath -Encoding UTF8)) {
            $trimmed = ([string]$line).Trim()
            if ([string]::IsNullOrWhiteSpace($trimmed) -or $trimmed.StartsWith('#')) { continue }
            $idx = $trimmed.IndexOf('=')
            if ($idx -le 0) { continue }
            $name = $trimmed.Substring(0, $idx).Trim()
            $value = $trimmed.Substring($idx + 1).Trim()
            if (($value.StartsWith('"') -and $value.EndsWith('"')) -or ($value.StartsWith("'") -and $value.EndsWith("'"))) {
                $value = $value.Substring(1, $value.Length - 2)
            }
            if ([string]::IsNullOrWhiteSpace([Environment]::GetEnvironmentVariable($name, 'Process'))) {
                [Environment]::SetEnvironmentVariable($name, $value, 'Process')
            }
        }
    }
    catch {
    }
}

Import-ChatEnvFile -Root $PSScriptRoot

if (Test-Path -LiteralPath $AiConfigPath -PathType Leaf) {
    try {
        $aiConfig = Get-Content -Raw -Encoding UTF8 -LiteralPath $AiConfigPath | ConvertFrom-Json
        if ([string]::IsNullOrWhiteSpace($AiModel) -and -not [string]::IsNullOrWhiteSpace([string]$aiConfig.model)) {
            $AiModel = [string]$aiConfig.model
        }
    }
    catch {
    }
}

if ([string]::IsNullOrWhiteSpace($AiModel)) {
    if (-not [string]::IsNullOrWhiteSpace([string]$env:OPENAI_MODEL)) {
        $AiModel = [string]$env:OPENAI_MODEL
    }
    elseif (-not [string]::IsNullOrWhiteSpace([string]$env:GUS_AI_MODEL)) {
        $AiModel = [string]$env:GUS_AI_MODEL
    }
    else {
        $AiModel = 'gpt-4.1-mini'
    }
}

$script:AiApiKey = [string]$env:OPENAI_API_KEY
$script:OpenAiClientPath = Join-Path $PSScriptRoot 'ai-openai-client.mjs'
$script:LastAiErrorCategory = ''
$script:LastAiStatus = ''
$script:LastAiError = ''
$script:AddressLookupAuditPath = Join-Path $PSScriptRoot 'address_lookup_audit.jsonl'
$script:OsintKitClientLoaded = $false
$script:OsintKitClientPath = Join-Path $PSScriptRoot 'OsintKitApiClient.ps1'
if (Test-Path -LiteralPath $script:OsintKitClientPath -PathType Leaf) {
    try {
        . $script:OsintKitClientPath
        $script:OsintKitClientLoaded = $true
    }
    catch {
        $script:OsintKitClientLoaded = $false
    }
}

$script:ChatRunning = $true
$script:AiHistory = New-Object System.Collections.ArrayList
$script:Memory = [ordered]@{
    LastIntent = ''
    LastIncoming = ''
    LastReply = ''
    LastKeyCount = 0
    LastColor = ''
    LastTopic = ''
    Expected = ''
}

function Normalize-ChatText {
    param([string]$Text)
    return (([string]$Text) -replace '\s+', ' ').Trim()
}

function Select-ChatPhrase {
    param([string[]]$Variants)
    if (-not $Variants -or $Variants.Count -eq 0) { return '' }
    if ($Variants.Count -eq 1) { return [string]$Variants[0] }
    return [string]$Variants[(Get-Random -Minimum 0 -Maximum $Variants.Count)]
}

function Get-ChatNodeExe {
    $candidates = New-Object System.Collections.Generic.List[string]
    if (-not [string]::IsNullOrWhiteSpace([string]$env:OPENAI_NODE_EXE)) { [void]$candidates.Add([string]$env:OPENAI_NODE_EXE) }
    [void]$candidates.Add((Join-Path $PSScriptRoot 'node\node.exe'))
    [void]$candidates.Add((Join-Path $PSScriptRoot 'node.exe'))
    if (-not [string]::IsNullOrWhiteSpace([string]$env:USERPROFILE)) {
        [void]$candidates.Add((Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'))
    }
    [void]$candidates.Add('C:\Program Files\nodejs\node.exe')
    [void]$candidates.Add('C:\Program Files (x86)\nodejs\node.exe')
    foreach ($candidate in @($candidates)) {
        if (-not [string]::IsNullOrWhiteSpace($candidate) -and (Test-Path -LiteralPath $candidate -PathType Leaf)) { return $candidate }
    }
    try {
        $command = Get-Command node -ErrorAction SilentlyContinue
        if ($command -and -not [string]::IsNullOrWhiteSpace([string]$command.Source)) { return [string]$command.Source }
    }
    catch {
    }
    return ''
}

function Get-StartMessages {
    $paths = New-Object System.Collections.Generic.List[string]
    if (-not [string]::IsNullOrWhiteSpace($StartMessagesPath)) { [void]$paths.Add($StartMessagesPath) }
    [void]$paths.Add((Join-Path $PSScriptRoot 'домофон_и_MAX_12_июля.txt'))
    [void]$paths.Add('C:\Users\Лепа\Desktop\домофон_и_MAX_12_июля.txt')

    foreach ($path in ($paths | Select-Object -Unique)) {
        if (-not (Test-Path -LiteralPath $path)) { continue }
        try {
            $raw = Get-Content -LiteralPath $path -Encoding UTF8 -Raw
            $messages = New-Object System.Collections.Generic.List[string]
            foreach ($part in ([regex]::Split($raw, '-{10,}'))) {
                $message = Normalize-ChatText $part
                if (-not [string]::IsNullOrWhiteSpace($message)) { [void]$messages.Add($message) }
            }
            if ($messages.Count -gt 0) { return [string[]]$messages.ToArray() }
        }
        catch {
        }
    }

    return [string[]]@(
        'Здравствуйте! Уточните, пожалуйста, количество ключей и желаемый цвет.',
        'Добрый день! Подскажите, Вас добавлять в чат дома в MAX?'
    )
}

function Get-StartMessage {
    return Select-ChatPhrase (Get-StartMessages)
}

function Get-MessageTopic {
    param([string]$Text)
    $lower = ([string]$Text).ToLowerInvariant()
    if ($lower -match '(чат|добав|приглаш)') { return 'chat' }
    if ($lower -match '(ключ|цвет|домофон|брон|замен|жкх|руб|цен|сто|бесплат)') { return 'keys' }
    return ''
}

function Reset-ChatMemory {
    $script:Memory.LastIntent = ''
    $script:Memory.LastIncoming = ''
    $script:Memory.LastReply = ''
    $script:Memory.LastKeyCount = 0
    $script:Memory.LastColor = ''
    $script:Memory.LastTopic = ''
    $script:Memory.Expected = ''
    $script:AiHistory.Clear()
}

function Save-ChatMemory {
    param([string]$Intent, [string]$Incoming, [string]$Reply, $Parsed)
    $script:Memory.LastIntent = $Intent
    $script:Memory.LastIncoming = $Incoming
    $script:Memory.LastReply = $Reply
    if ($null -ne $Parsed.Count) { $script:Memory.LastKeyCount = [int]$Parsed.Count }
    if (-not [string]::IsNullOrWhiteSpace([string]$Parsed.Color)) { $script:Memory.LastColor = [string]$Parsed.Color }

    if ($Intent -eq 'notification-missing') {
        if ($script:Memory.Expected -eq 'chat-invite' -or $script:Memory.LastTopic -eq 'chat') {
            $script:Memory.LastTopic = 'chat'
        }
        else {
            $script:Memory.LastTopic = 'keys'
        }
    }
    elseif (@('price-question', 'key-count', 'keys-topic', 'color-only', 'colors-question', 'planned-replacement', 'notification-received', 'booking-number', 'booking-help', 'logistics') -contains $Intent) {
        $script:Memory.LastTopic = 'keys'
    }
    elseif (@('add-chat', 'invite-check', 'home-chat-reason', 'old-chat-fate', 'existing-chat') -contains $Intent) {
        $script:Memory.LastTopic = 'chat'
    }
    elseif (@('identity-question', 'address-question', 'relevance-question', 'not-resident-confirm', 'not-resident-cancel') -contains $Intent) {
        # These intents answer inside the current dialog and should not reset the topic.
    }
    elseif ($Intent -eq 'not-resident') {
        if ([string]::IsNullOrWhiteSpace([string]$script:Memory.LastTopic)) {
            $script:Memory.LastTopic = 'resident-check'
        }
    }
    else {
        $topic = Get-MessageTopic "$Incoming $Reply"
        if (-not [string]::IsNullOrWhiteSpace($topic)) { $script:Memory.LastTopic = $topic }
    }

    if (@('add-chat') -contains $Intent) {
        $script:Memory.Expected = 'chat-invite'
    }
    elseif (@('home-chat-reason', 'old-chat-fate', 'existing-chat') -contains $Intent) {
        $script:Memory.Expected = 'chat-consent'
    }
    elseif (@('key-count', 'booking-help') -contains $Intent) {
        $script:Memory.Expected = 'booking-number'
    }
    elseif ($Intent -eq 'color-only') {
        if ([int]$script:Memory.LastKeyCount -gt 0) {
            $script:Memory.Expected = 'booking-number'
        }
        else {
            $script:Memory.Expected = 'key-count'
        }
    }
    elseif ($Intent -eq 'price-question') {
        if ([int]$script:Memory.LastKeyCount -gt 0) {
            $script:Memory.Expected = 'booking-number'
        }
        elseif ([string]::IsNullOrWhiteSpace([string]$script:Memory.Expected)) {
            $script:Memory.Expected = 'key-count'
        }
    }
    elseif ($Intent -eq 'not-resident') {
        $script:Memory.Expected = 'not-resident-confirm'
    }
    elseif (@('not-resident-confirm', 'not-resident-cancel') -contains $Intent) {
        $script:Memory.Expected = ''
    }
    elseif (@('booking-number', 'invite-check', 'proof-check') -contains $Intent) {
        $script:Memory.Expected = ''
    }

    [void]$script:AiHistory.Add([pscustomobject]@{ role = 'user'; content = $Incoming })
    [void]$script:AiHistory.Add([pscustomobject]@{ role = 'assistant'; content = $Reply })
    while ($script:AiHistory.Count -gt 12) {
        $script:AiHistory.RemoveAt(0)
    }
}

function Test-BlockedChatText {
    param([string]$Text)
    $value = ([string]$Text).ToLowerInvariant()
    if ([string]::IsNullOrWhiteSpace($value)) { return $true }
    if ($value -match '(код|парол|смс|sms|otp|2fa|двухфактор|вход|логин|esia|госуслуг|гос услуг|банк|карта|паспорт|снилс|пин|pin|token|токен)') { return $true }
    if ($value -match '(дура|туп|нах|хуй|пизд|еба|сука|мраз|кредит|взлом)') { return $true }
    return $false
}

function Get-KeyWord {
    param([int]$Count)
    $n = [Math]::Abs($Count)
    $lastTwo = $n % 100
    $last = $n % 10
    if ($lastTwo -ge 11 -and $lastTwo -le 14) { return 'ключей' }
    if ($last -eq 1) { return 'ключ' }
    if ($last -ge 2 -and $last -le 4) { return 'ключа' }
    return 'ключей'
}

function Get-KeyBookingPrompt {
    param([int]$Count)

    $word = Get-KeyWord $Count
    return Select-ChatPhrase @(
        "Хорошо, записала на Вас $Count $word. Также Вам должно поступить уведомление в MAX с номером брони на ключи и количеством. Проверьте, всё ли верно, и перешлите мне — закреплю их за Вами и сориентирую, когда можно будет получить ключи.",
        "Хорошо, я записала за Вами $Count $word. Вам также должно прийти уведомление в MAX с номером брони и количеством ключей. Проверьте, пожалуйста, информацию и перешлите мне — я закреплю их за Вами и сообщу, когда можно будет забрать ключи.",
        "Отметила за Вами $Count $word. Также Вам поступит уведомление в MAX с номером брони и количеством. Проверьте, пожалуйста, данные и перешлите мне — я закреплю ключи за Вами и подскажу, когда их можно получить."
    )
}

function Get-ExpectedBookingNumber {
    $value = ([string]$env:GUS_EXPECTED_BOOKING_NUMBER).Trim()
    if ([string]::IsNullOrWhiteSpace($value)) { $value = '434-322' }
    $match = [regex]::Match($value, '(?<!\d)(\d{3})\s*[-–—]?\s*(\d{3})(?!\d)')
    if ($match.Success) { return "$($match.Groups[1].Value)-$($match.Groups[2].Value)" }
    return ''
}

function Test-BookingNumberExpected {
    param([string]$Booking)

    $expected = Get-ExpectedBookingNumber
    if ([string]::IsNullOrWhiteSpace($expected)) { return $true }
    return [string]::Equals(([string]$Booking).Trim(), $expected, [StringComparison]::OrdinalIgnoreCase)
}

function Get-NumberWordValue {
    param([string]$Text)
    $lower = ([string]$Text).ToLowerInvariant()
    $map = [ordered]@{
        'один' = 1; 'одна' = 1; 'первый' = 1
        'два' = 2; 'две' = 2
        'три' = 3
        'четыре' = 4
        'пять' = 5
        'шесть' = 6
        'семь' = 7
        'восемь' = 8
        'девять' = 9
        'десять' = 10
    }
    foreach ($key in $map.Keys) {
        if ($lower -match "(?<![а-яё])$key(?![а-яё])") { return [int]$map[$key] }
    }
    return $null
}

function Test-KeyContext {
    param([string]$Text)
    $lower = ([string]$Text).ToLowerInvariant()
    if ($lower -match '(ключ|шт|штук|штуки|сколько|почем|по\s*чем|цена|ценник|стоим|стоит|стоят|стоять|стоить|руб|оплат|платн)') { return $true }
    if ($lower -match '(?<![а-яё])(любой|любого|любые|любым|цвет|цвета|цветом|красный|красных|красные|синий|синих|синие|зеленый|зелёный|зеленых|зелёных|желтый|жёлтый|черный|чёрный|белый)(?![а-яё])') { return $true }
    return $false
}

function Get-KeyCount {
    param([string]$Text)
    $lower = ([string]$Text).ToLowerInvariant()
    $matches = [regex]::Matches($lower, '(?<!\d)(\d{1,2})(?!\d)')
    $candidates = New-Object System.Collections.Generic.List[int]
    foreach ($match in $matches) {
        $candidate = [int]$match.Groups[1].Value
        if ($candidate -lt 1 -or $candidate -gt 30) { continue }
        $start = [Math]::Max(0, $match.Index - 24)
        $length = [Math]::Min($lower.Length - $start, $match.Length + 48)
        $near = $lower.Substring($start, $length)
        if ($near -match '(ключ|шт|штук|штуки|брел|цвет|красн|син|зелен|зелён|желт|жёлт|черн|чёрн|бел|салат)' -or $lower -match '^\s*\d{1,2}\s*$') {
            [void]$candidates.Add($candidate)
        }
    }
    if ($candidates.Count -gt 1) {
        $sum = 0
        foreach ($value in $candidates) { $sum += [int]$value }
        if ($sum -ge 1 -and $sum -le 30) { return $sum }
    }
    if ($candidates.Count -eq 1) { return [int]$candidates[0] }
    $wordNumber = Get-NumberWordValue $lower
    if ($null -ne $wordNumber -and (Test-KeyContext $lower)) { return [int]$wordNumber }
    return $null
}

function Get-ContextualAckDecision {
    $lastTopic = [string]$script:Memory.LastTopic
    $expected = [string]$script:Memory.Expected
    $lastIntent = [string]$script:Memory.LastIntent

    if ($lastTopic -eq 'chat' -and ($expected -eq 'chat-consent' -or @('start', 'home-chat-reason', 'old-chat-fate', 'existing-chat') -contains $lastIntent)) {
        $reply = Select-ChatPhrase @(
            'Хорошо, сейчас в MAX должно прийти сообщение с номером приглашения. Перешлите его сюда - добавлю Вас в чат.',
            'Поняла, добавляем. В MAX придет номер приглашения, перешлите его мне сюда.',
            'Хорошо. Как в MAX появится приглашение, перешлите его сюда, я Вас добавлю.'
        )
        return [pscustomobject]@{ Action = 'reply'; Reply = $reply; Reason = 'ack:chat-consent' }
    }

    if ($lastTopic -eq 'keys' -and $expected -eq 'booking-number') {
        $reply = Select-ChatPhrase @(
            'Хорошо. Как в MAX придет номер брони, перешлите его сюда.',
            'Поняла. Тогда жду номер брони из MAX.',
            'Хорошо, ожидайте сообщение в MAX и перешлите мне номер брони.'
        )
        return [pscustomobject]@{ Action = 'reply'; Reply = $reply; Reason = 'ack:booking-number' }
    }

    return [pscustomobject]@{ Action = 'reaction'; Reply = '👍'; Reason = 'ack' }
}

function Get-ColorText {
    param([string]$Text)
    $lower = ([string]$Text).ToLowerInvariant()
    $colors = New-Object System.Collections.Generic.List[string]
    if ($lower -match '(любой|любого|любые|любым|не\s+важ(ен|на|но|ны)|без\s+разницы|цвет\s+не\s+важен|цвет\s+не\s+важно)') { [void]$colors.Add('любой') }
    if ($lower -match 'красн') { [void]$colors.Add('красный') }
    if ($lower -match 'син') { [void]$colors.Add('синий') }
    if ($lower -match 'зелен|зелён') { [void]$colors.Add('зеленый') }
    if ($lower -match 'желт|жёлт') { [void]$colors.Add('желтый') }
    if ($lower -match 'черн|чёрн') { [void]$colors.Add('черный') }
    if ($lower -match 'бел') { [void]$colors.Add('белый') }
    if ($lower -match 'салат') { [void]$colors.Add('салатовый') }
    if ($colors.Count -eq 0) { return '' }
    return (($colors | Select-Object -Unique) -join ', ')
}

function Get-BookingNumber {
    param([string]$Text)
    $match = [regex]::Match([string]$Text, '(?<!\d)(\d{3})\s*[-–—]?\s*(\d{3})(?!\d)')
    if ($match.Success) { return "$($match.Groups[1].Value)-$($match.Groups[2].Value)" }
    return ''
}

function Get-Intent {
    param([string]$Text)
    $source = Normalize-ChatText $Text
    $lower = $source.ToLowerInvariant()
    $count = Get-KeyCount $source
    $color = Get-ColorText $source
    $booking = Get-BookingNumber $source
    $hasPriceWords = $lower -match '(по\s*чем|почем|цена|ценник|стоим|стоит|стоят|стоять|стоить|сколько\s+(они\s+)?(будут|будет|стоят|стоять|стоить|выйдет|обойд)|платн|оплат|руб)'
    $hasKeyWords = $lower -match '(ключ|ключи|ключей|ключа|домофон|цвет|брелок|брелки)'
    $addressPattern = '(какой|какая|каком|какому|котором|чьем|чьём|где|подскажите|напишите).{0,70}(адрес|адерс|адерус|адресу|адерсу|адресс|улиц|дом|доме|дома|подъезд|подьезд|подезде|подъезде|подьезде)|ад(ре|ер)с[ау]?[\?\.]?$|по\s+какому\s+(адрес|адерс|адерус|адресу|адерсу|дому)|в\s+каком\s+(именно\s+)?(доме|подъезде|подьезде)|какой\s+(дом|подъезд|подьезд)|где.{0,45}замен[аы]|по\s+какому.{0,30}(меня|менять|замен)'

    if (Test-BlockedChatText $source) { return [pscustomobject]@{ Intent = 'blocked'; Count = $count; Color = $color; Booking = $booking } }
    if ($script:Memory.Expected -eq 'not-resident-confirm' -and $lower -match '^(да|давайте|можно|подайте|подавайте|передайте|уберите|убрать|хорошо|ок|окей|согласна|согласен)[\s\.\!]*$') { return [pscustomobject]@{ Intent = 'not-resident-confirm'; Count = $count; Color = $color; Booking = $booking } }
    if ($script:Memory.Expected -eq 'not-resident-confirm' -and $lower -match '^(нет|не надо|не нужно|не подавайте|оставьте|отмена)[\s\.\!]*$') { return [pscustomobject]@{ Intent = 'not-resident-cancel'; Count = $count; Color = $color; Booking = $booking } }
    if ($lower -match $addressPattern) { return [pscustomobject]@{ Intent = 'address-question'; Count = $count; Color = $color; Booking = $booking } }
    if ($lower -match '(^|[^\p{L}])((а\s+)?я\s*(тут|то)?\s*(при\s*ч[еёо]м|прич[еёо]м)|почему\s+(я|мне|меня)|зачем\s+(мне|меня|это\s+мне)|что\s+от\s+меня|я\s+тут\s+зачем)([^\p{L}]|$)') { return [pscustomobject]@{ Intent = 'relevance-question'; Count = $count; Color = $color; Booking = $booking } }
    if ($hasPriceWords -and ($hasKeyWords -or $null -ne $count -or $script:Memory.LastTopic -eq 'keys' -or $lower -match 'сколько')) { return [pscustomobject]@{ Intent = 'price-question'; Count = $count; Color = $color; Booking = $booking } }
    if ($null -ne $count) { return [pscustomobject]@{ Intent = 'key-count'; Count = $count; Color = $color; Booking = $booking } }
    if (-not [string]::IsNullOrWhiteSpace($color) -and ($hasKeyWords -or $script:Memory.LastTopic -eq 'keys')) { return [pscustomobject]@{ Intent = 'color-only'; Count = $count; Color = $color; Booking = $booking } }
    if ($script:Memory.Expected -eq 'chat-invite' -and $lower -match '^(нет|нету|неа|нет пока|не пришло|не пришел|не пришёл|не пришла|не вижу|не нашел|не нашёл|не получила|не получил)[\s\.\!]*$') { return [pscustomobject]@{ Intent = 'notification-missing'; Count = $count; Color = $color; Booking = $booking } }
    if ($script:Memory.LastTopic -eq 'chat' -and (($script:Memory.Expected -eq 'chat-consent') -or @('start', 'home-chat-reason', 'old-chat-fate', 'existing-chat') -contains [string]$script:Memory.LastIntent) -and $lower -match '^(да|давайте|можно|добавьте|добавляйте|добавляйте меня|согласна|согласен|хорошо|ок|окей)[\s\.\!]*$') { return [pscustomobject]@{ Intent = 'add-chat'; Count = $count; Color = $color; Booking = $booking } }
    if ($lower -match '^(ок|оке|окей|хорошо|ладно|понял|поняла|да|ага|угу|спасибо|благодарю)[\s\.\!\)]*$') { return [pscustomobject]@{ Intent = 'ack'; Count = $count; Color = $color; Booking = $booking } }
    if ($lower -match '(у\s+нас|уже|так).{0,35}(есть|имеется).{0,25}(чат|чат дома|домовой чат)|(чат|чат дома|домовой чат).{0,25}(уже|давно).{0,25}(есть|имеется)') { return [pscustomobject]@{ Intent = 'existing-chat'; Count = $count; Color = $color; Booking = $booking } }
    if ($lower -match '(что|как|куда|а).{0,35}(стар(ый|ий|ого|ым|им|ом|ому|ые|ых)?).{0,55}(чат|чатом)|(стар(ый|ий|ого|ым|им|ом|ому|ые|ых)?).{0,60}(чат|чатом).{0,55}(буд|остан|удал|закро|перенес|пропад|пробат|денет)|чат.{0,55}стар|прежн(ий|его).{0,35}(чат|чатом)|стар(ый|ий|ого|ым|им|ом|ому)?\s+чат') { return [pscustomobject]@{ Intent = 'old-chat-fate'; Count = $count; Color = $color; Booking = $booking } }
    if ($lower -match '(какой|какая|что за|зачем|почему|для чего).{0,30}(чат|чат дома)|чат.{0,20}(какой|что за|зачем|почему)|какие\s+ключи.{0,80}чат|прич[её]м.{0,30}ключ' -or ($script:Memory.LastTopic -eq 'chat' -and $lower -match 'какие\s+ключи')) { return [pscustomobject]@{ Intent = 'home-chat-reason'; Count = $count; Color = $color; Booking = $booking } }
    if ($lower -match '(вы кто|кто вы|а кто вы|кто это|откуда вы|что за заявк|кто пишет|вы откуда)') { return [pscustomobject]@{ Intent = 'identity-question'; Count = $count; Color = $color; Booking = $booking } }
    if (($lower -match '(^|[^а-яё])(добавл|добавял|добавить|добавьте|добавте|добавление|добавляй|добавляйте|добавляем|добавляете|давайте|можно|согласна|согласен)([^а-яё]|$)' -and -not $hasKeyWords -and [string]::IsNullOrWhiteSpace($color)) -or ($script:Memory.LastTopic -eq 'chat' -and $lower -match '^(да|давайте|можно|добавьте|добавляйте|добавляйте меня|согласна|согласен|хорошо)[\s\.\!]*$')) { return [pscustomobject]@{ Intent = 'add-chat'; Count = $count; Color = $color; Booking = $booking } }
    if ($lower -match '(^|[^а-яё])(ключи|про ключи|о ключах|речь.*ключ|ключей|ключа)([^а-яё]|$)' -and $null -eq $count -and -not $hasPriceWords) { return [pscustomobject]@{ Intent = 'keys-topic'; Count = $count; Color = $color; Booking = $booking } }
    if ($lower -match '(какие|какой|какого|какие есть|в наличии).{0,30}(цвет|цвета|ключ)|цвета.{0,20}(есть|в наличии|какие)') { return [pscustomobject]@{ Intent = 'colors-question'; Count = $count; Color = $color; Booking = $booking } }
    if ($lower -match '(не живу|не прожива|там не жив|больше там|уже не жив|продал|продала|переехал|переехала|другой хозяин|не мой дом|не моя квартира)') { return [pscustomobject]@{ Intent = 'not-resident'; Count = $count; Color = $color; Booking = $booking } }
    if ($lower -match '(зачем|почему|для чего|что будет|что за замена|замена).{0,80}(домофон|ключ|жкх|планов|плановая)|плановая ли|это бесплатно') { return [pscustomobject]@{ Intent = 'planned-replacement'; Count = $count; Color = $color; Booking = $booking } }
    if ($lower -match '(стар(ый|ого|ым|ом|ому)).{0,50}(чат|домовой)|зачем.{0,30}новый чат|почему.{0,30}новый чат|что будет в чате|показания счет|показания счёт') { return [pscustomobject]@{ Intent = 'home-chat-reason'; Count = $count; Color = $color; Booking = $booking } }
    if ($lower -match '(не приш|нету|нет|не вижу|не нашел|не нашёл|не получил|не получила).{0,60}(оповещ|уведомлен|номер|брон|приглаш)|(номер|брон|приглаш).{0,25}(не приш|не получил|не получила|нету|нет)') { return [pscustomobject]@{ Intent = 'notification-missing'; Count = $count; Color = $color; Booking = $booking } }
    if ($lower -match '(получил|получила|пришло|пришел|пришёл|пришла|увидел|увидела).{0,60}(оповещ|уведомлен|номер|брон|приглаш)|(номер|брон|приглаш).{0,25}(приш|получил|получила|увидел|увидела)') { return [pscustomobject]@{ Intent = 'notification-received'; Count = $count; Color = $color; Booking = $booking } }
    if ($lower -match '(достаточно|хватит|нужен.*скрин|скрин.*нужен|так подойдет|так подойдёт|этого хватит)') { return [pscustomobject]@{ Intent = 'proof-check'; Count = $count; Color = $color; Booking = $booking } }
    if (-not [string]::IsNullOrWhiteSpace($booking)) { return [pscustomobject]@{ Intent = 'booking-number'; Count = $count; Color = $color; Booking = $booking } }
    if ($lower -match '(сколько|цена|ценник|стоим|стоит|стоят|стоять|стоить|руб|оплат|платн).*(ключ)|ключ.*(сколько|цена|ценник|стоим|стоит|стоят|стоять|стоить|руб|оплат|платн)') { return [pscustomobject]@{ Intent = 'price-question'; Count = $count; Color = $color; Booking = $booking } }
    if (-not [string]::IsNullOrWhiteSpace($color)) { return [pscustomobject]@{ Intent = 'color-only'; Count = $count; Color = $color; Booking = $booking } }
    if ($lower -match '(добавьте|добавляйте|добавляем|добавляете|добавить|добавля|добавл|добавял|давайте|можно|пожалуйста|да пожалуйста|добавьте меня|добавьте в чат)' -and -not $hasKeyWords) { return [pscustomobject]@{ Intent = 'add-chat'; Count = $count; Color = $color; Booking = $booking } }
    if ($lower -match '(приглашени|приглашение).*(чат|жильц|дом)|переслано.*приглаш|приглашение в чат') { return [pscustomobject]@{ Intent = 'invite-check'; Count = $count; Color = $color; Booking = $booking } }
    if ($lower -match '(номер|брон|брони|бронир).*(какой|где|не приш|не было|нет)|не приш.*(номер|брон)|что.*писать|писать.*адрес|адрес.*тот') { return [pscustomobject]@{ Intent = 'booking-help'; Count = $count; Color = $color; Booking = $booking } }
    if ($lower -match '(где|когда|забрать|получить|выдач|раньше|позже|сентябр|приед|успею|не попаду)') { return [pscustomobject]@{ Intent = 'logistics'; Count = $count; Color = $color; Booking = $booking } }
    return [pscustomobject]@{ Intent = 'unknown'; Count = $count; Color = $color; Booking = $booking }
}

function Get-TrainingReply {
    param([string]$Text, [string]$Intent)
    if (-not (Test-Path -LiteralPath $TrainingPath)) { return '' }
    try {
        $items = @(Get-Content -Raw -Encoding UTF8 -LiteralPath $TrainingPath | ConvertFrom-Json)
        foreach ($item in $items) {
            if ($null -ne $item.enabled -and -not [bool]$item.enabled) { continue }

            $intents = New-Object System.Collections.Generic.List[string]
            foreach ($propertyName in @('intent', 'intents')) {
                if ($item.PSObject.Properties.Name -contains $propertyName) {
                    foreach ($value in @($item.$propertyName)) {
                        if (-not [string]::IsNullOrWhiteSpace([string]$value)) { [void]$intents.Add([string]$value) }
                    }
                }
            }
            if ($intents.Count -gt 0) {
                $intentMatched = $false
                foreach ($value in $intents) {
                    if ([string]::Equals($value, $Intent, [StringComparison]::OrdinalIgnoreCase)) {
                        $intentMatched = $true
                        break
                    }
                }
                if (-not $intentMatched) { continue }
            }

            $patterns = New-Object System.Collections.Generic.List[string]
            foreach ($propertyName in @('match', 'matches', 'examples')) {
                if ($item.PSObject.Properties.Name -contains $propertyName) {
                    foreach ($value in @($item.$propertyName)) {
                        if (-not [string]::IsNullOrWhiteSpace([string]$value)) { [void]$patterns.Add([string]$value) }
                    }
                }
            }
            $matched = $patterns.Count -eq 0
            foreach ($pattern in $patterns) {
                if ($Text -match [string]$pattern) { $matched = $true; break }
            }
            if (-not $matched) { continue }

            $answers = New-Object System.Collections.Generic.List[string]
            foreach ($propertyName in @('answer', 'answers')) {
                if ($item.PSObject.Properties.Name -contains $propertyName) {
                    foreach ($value in @($item.$propertyName)) {
                        if (-not [string]::IsNullOrWhiteSpace([string]$value)) { [void]$answers.Add([string]$value) }
                    }
                }
            }
            if ($answers.Count -eq 0) { continue }
            $answer = Select-ChatPhrase ([string[]]$answers.ToArray())
            if (-not [string]::IsNullOrWhiteSpace($answer) -and -not (Test-BlockedChatText $answer)) { return $answer }
        }
    }
    catch {
    }
    return ''
}

function Invoke-RealAiReply {
    param([string]$Text, $Parsed)

    $script:LastAiErrorCategory = ''
    $script:LastAiStatus = ''
    $script:LastAiError = ''

    if ($NoRealAI) { return '' }
    if ([string]::IsNullOrWhiteSpace($script:AiApiKey)) { return '' }

    $intent = [string]$Parsed.Intent
    if (@('blocked') -contains $intent) { return '' }

    $systemPrompt = @'
Ты отвечаешь в учебном тренажере по заявкам MAX. Пиши коротко, по-русски, естественно, на Вы.
Учитывай историю диалога и текущую тему. Не сбрасывайся на шаблон, если клиент задал уточняющий вопрос.
Разделяй темы: ключи/замена домофона и домовой чат MAX.
Факты: до 5 ключей бесплатно; каждый ключ сверх пяти стоит 250 рублей; цвета: красный, желтый, синий, черный, зеленый, салатовый; после выбора ключей попроси переслать номер брони из MAX. Для чата MAX попроси переслать приглашение из MAX.
Если спрашивают "какой чат", объясни, что это общий чат жильцов дома в MAX со службами и мастерами.
Если спрашивают про старый чат, скажи, что он может оставаться временно, но основное общение переводят в новый MAX-чат дома.
Если спрашивают "кто вы", отвечай: "Я секретарь председателя, веду заявки по MAX."
Если вопрос про точный адрес, коды, SMS, пароли, Госуслуги, банк, документы или другие чувствительные данные, верни handoff.
Не проси коды подтверждения, пароли, документы, банковские данные и не ищи адрес по телефону.
Если текстовый ответ не нужен, верни ignore.
'@

    $contextPrompt = "Текущая тема диалога: $($script:Memory.LastTopic). Что сейчас ждем от клиента: $($script:Memory.Expected). Последнее количество ключей: $($script:Memory.LastKeyCount). Последний цвет: $($script:Memory.LastColor). Распознанное намерение: $intent."

    try {
        if (-not (Test-Path -LiteralPath $script:OpenAiClientPath -PathType Leaf)) { return '' }
        $nodeExe = Get-ChatNodeExe
        if ([string]::IsNullOrWhiteSpace($nodeExe)) { return '' }
        $request = [ordered]@{
            model = $AiModel
            chatId = 'console'
            envRoot = $PSScriptRoot
            intent = $intent
            context = $contextPrompt
            instructions = $systemPrompt
            history = @($script:AiHistory | Select-Object -Last 24)
            message = [string]$Text
            timeoutMs = 25000
        }
        $requestPath = Join-Path ([System.IO.Path]::GetTempPath()) ("gus_ai_console_{0}.json" -f ([Guid]::NewGuid().ToString('N')))
        try {
            Set-Content -LiteralPath $requestPath -Value ($request | ConvertTo-Json -Depth 10) -Encoding UTF8
            $nodeOutput = & $nodeExe $script:OpenAiClientPath $requestPath 2>&1
        }
        finally {
            try { Remove-Item -LiteralPath $requestPath -Force -ErrorAction SilentlyContinue } catch {}
        }
        $result = ($nodeOutput | Select-Object -Last 1) | ConvertFrom-Json
        if (-not $result.ok) {
            $script:LastAiErrorCategory = [string]$result.errorCategory
            $script:LastAiStatus = [string]$result.status
            $script:LastAiError = [string]$result.error
            if ($Trace) { Write-Host "ai-error: $($result.errorCategory):$($result.status)" }
            return ''
        }
        if ([string]$result.action -eq 'ignore') { return '' }
        if ([string]$result.action -eq 'handoff') { return 'Нужен оператор.' }
        $answer = Normalize-ChatText ([string]$result.message)
        if ([string]::IsNullOrWhiteSpace($answer)) { return '' }
        if ($answer -match '^(без ответа|нет ответа)\.?$') { return '' }
        if ($answer -ne 'Нужен оператор.' -and (Test-BlockedChatText $answer)) { return '' }
        return $answer
    }
    catch {
        $script:LastAiErrorCategory = 'exception'
        $script:LastAiStatus = '0'
        $script:LastAiError = [string]$_.Exception.Message
        if ($Trace) {
            Write-Host "ai-error: $($_.Exception.Message)"
            Write-Host '---'
        }
        return ''
    }
}

function Get-ChatHash {
    param([string]$Text)

    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $bytes = [System.Text.Encoding]::UTF8.GetBytes([string]$Text)
        $hash = $sha.ComputeHash($bytes)
        return -join ($hash | Select-Object -First 8 | ForEach-Object { $_.ToString('x2') })
    }
    finally {
        $sha.Dispose()
    }
}

function Write-ChatAddressAudit {
    param(
        [string]$Result,
        [string]$PhoneDigits = '',
        [string]$AddressKey = ''
    )

    try {
        $entry = [ordered]@{
            at = (Get-Date).ToString('o')
            event = 'address_lookup'
            result = [string]$Result
            phoneHash = if ([string]::IsNullOrWhiteSpace($PhoneDigits)) { '' } else { Get-ChatHash $PhoneDigits }
            addressHash = if ([string]::IsNullOrWhiteSpace($AddressKey)) { '' } else { Get-ChatHash $AddressKey }
        }
        Add-Content -LiteralPath $script:AddressLookupAuditPath -Value ($entry | ConvertTo-Json -Compress) -Encoding UTF8
    }
    catch {
    }
}

function Normalize-ChatPhone {
    param([string]$Phone)

    if ([string]::IsNullOrWhiteSpace($Phone)) { return '' }
    $digits = ([string]$Phone -replace '\D', '')
    if ($digits.Length -eq 10) {
        $digits = '7' + $digits
    }
    elseif ($digits.Length -eq 11 -and $digits.StartsWith('8')) {
        $digits = '7' + $digits.Substring(1)
    }
    if ($digits.Length -eq 11 -and $digits.StartsWith('7')) { return $digits }
    return ''
}

function Test-ChatAddressLookupAllowed {
    if ([string]$env:GUS_ADDRESS_LOOKUP_ALLOW_ALL -eq '1') { return $true }
    if ([string]$env:GUS_ADDRESS_LOOKUP_AUTHORIZED -eq '1') { return $true }
    return $false
}

function Get-ChatAddressBasePath {
    $path = ([string]$env:GUS_ADDRESS_BASE_PATH).Trim()
    if (-not [string]::IsNullOrWhiteSpace($path) -and (Test-Path -LiteralPath $path -PathType Leaf)) {
        return $path
    }
    return ''
}

function Get-ChatObjectField {
    param(
        $Object,
        [string[]]$Names
    )

    if ($null -eq $Object) { return '' }
    foreach ($name in @($Names)) {
        if ([string]::IsNullOrWhiteSpace($name)) { continue }
        try {
            if ($Object -is [System.Collections.IDictionary] -and $Object.Contains($name)) {
                $value = $Object[$name]
                if (-not [string]::IsNullOrWhiteSpace([string]$value)) { return ([string]$value).Trim() }
            }
            $property = $Object.PSObject.Properties[$name]
            if ($property) {
                $value = $property.Value
                if (-not [string]::IsNullOrWhiteSpace([string]$value)) { return ([string]$value).Trim() }
            }
        }
        catch {
        }
    }
    return ''
}

function Import-ChatAddressBase {
    $path = Get-ChatAddressBasePath
    if ([string]::IsNullOrWhiteSpace($path)) { return @() }

    try {
        $extension = [System.IO.Path]::GetExtension($path).ToLowerInvariant()
        if ($extension -eq '.csv') {
            return @(Import-Csv -LiteralPath $path -Encoding UTF8)
        }

        $json = Get-Content -Raw -Encoding UTF8 -LiteralPath $path | ConvertFrom-Json
        if ($json -is [System.Array]) { return @($json) }
        if ($json.PSObject.Properties['records']) { return @($json.records) }
        if ($json.PSObject.Properties['addresses']) { return @($json.addresses) }
        return @($json)
    }
    catch {
        return @()
    }
}

function Get-ChatAuthorizedClientPhone {
    return (Normalize-ChatPhone ([string]$env:GUS_CLIENT_PHONE))
}

function Get-ChatBuildingAddress {
    param($Record)

    $street = Get-ChatObjectField $Record @('street', 'Street', 'улица', 'Улица')
    $house = Get-ChatObjectField $Record @('house', 'House', 'дом', 'Дом', 'building', 'Building')
    $fullAddress = Get-ChatObjectField $Record @('address', 'Address', 'адрес', 'Адрес')

    if (-not [string]::IsNullOrWhiteSpace($street) -and -not [string]::IsNullOrWhiteSpace($house)) {
        return (("$street $house") -replace '\s+', ' ').Trim(' ', ',')
    }

    if (-not [string]::IsNullOrWhiteSpace($fullAddress)) {
        $safe = $fullAddress
        $safe = $safe -replace '(?i)(,\s*)?(кв\.?|квартира|пом\.?|помещение|офис|комн\.?|комната)\s*[\w\-\/]+', ''
        $safe = $safe -replace '\s+', ' '
        return $safe.Trim(' ', ',')
    }

    return ''
}

function Test-ChatOsintKitAvailable {
    if (-not $script:OsintKitClientLoaded) { return $false }
    $token = [Environment]::GetEnvironmentVariable('OSINTKIT_API_TOKEN', 'Process')
    if ([string]::IsNullOrWhiteSpace($token)) {
        $token = [Environment]::GetEnvironmentVariable('OSINTKIT_API_TOKEN', 'User')
    }
    if ([string]::IsNullOrWhiteSpace($token)) {
        $token = [Environment]::GetEnvironmentVariable('OSINTKIT_API_TOKEN', 'Machine')
    }
    return (-not [string]::IsNullOrWhiteSpace($token))
}

function Resolve-ChatOsintKitAddressVerification {
    param([string]$PhoneDigits)

    if (-not (Test-ChatOsintKitAvailable)) {
        return [pscustomobject]@{ Status = 'osint_unavailable'; Reply = ''; Reason = 'OSINTKit client or token missing' }
    }

    try {
        $phoneForApi = "+$PhoneDigits"
        $result = Find-OsintKitAddressVerification -Phone $phoneForApi -MaxRows 10
        $status = [string]$result.Status
        if ([string]::IsNullOrWhiteSpace($status)) { $status = 'unknown' }

        if ($result.Ok -and -not [string]::IsNullOrWhiteSpace([string]$result.SuggestedClientMessage)) {
            Write-ChatAddressAudit -Result "osint_ok" -PhoneDigits $PhoneDigits -AddressKey ([string]$result.MaskedAddress)
            return [pscustomobject]@{ Status = 'ok'; Reply = [string]$result.SuggestedClientMessage; Reason = 'osint single building match' }
        }

        Write-ChatAddressAudit -Result "osint_$status" -PhoneDigits $PhoneDigits
        return [pscustomobject]@{ Status = "osint_$status"; Reply = ''; Reason = [string]$result.Reason }
    }
    catch {
        Write-ChatAddressAudit -Result 'osint_error' -PhoneDigits $PhoneDigits
        return [pscustomobject]@{ Status = 'osint_error'; Reply = ''; Reason = 'OSINTKit safe request failed' }
    }
}

function Resolve-ChatAddressVerification {
    if (-not (Test-ChatAddressLookupAllowed)) {
        Write-ChatAddressAudit -Result 'denied'
        return [pscustomobject]@{ Status = 'denied'; Reply = ''; Reason = 'address lookup denied' }
    }

    $phone = Get-ChatAuthorizedClientPhone
    if ([string]::IsNullOrWhiteSpace($phone)) {
        Write-ChatAddressAudit -Result 'no_phone'
        return [pscustomobject]@{ Status = 'no_phone'; Reply = ''; Reason = 'no authorized phone' }
    }

    $osintResult = Resolve-ChatOsintKitAddressVerification -PhoneDigits $phone
    if ([string]$osintResult.Status -eq 'ok') {
        return $osintResult
    }
    if ((Test-ChatOsintKitAvailable) -and [string]$osintResult.Status -ne 'osint_unavailable') {
        return $osintResult
    }

    $records = @(Import-ChatAddressBase)
    if ($records.Count -eq 0) {
        Write-ChatAddressAudit -Result 'no_base' -PhoneDigits $phone
        return [pscustomobject]@{ Status = 'no_base'; Reply = ''; Reason = 'address base missing' }
    }

    $matches = New-Object System.Collections.Generic.List[object]
    foreach ($record in $records) {
        $enabled = Get-ChatObjectField $record @('enabled', 'Enabled', 'active', 'Active', 'доступ', 'Доступ')
        if (-not [string]::IsNullOrWhiteSpace($enabled) -and $enabled -match '^(0|false|нет|no|disabled|выкл)') { continue }
        $recordPhone = Normalize-ChatPhone (Get-ChatObjectField $record @('phone', 'Phone', 'телефон', 'Телефон', 'mobile', 'Mobile'))
        if ($recordPhone -eq $phone) {
            [void]$matches.Add($record)
        }
    }

    if ($matches.Count -eq 0) {
        Write-ChatAddressAudit -Result 'no_match' -PhoneDigits $phone
        return [pscustomobject]@{ Status = 'no_match'; Reply = ''; Reason = 'no address match' }
    }
    if ($matches.Count -gt 1) {
        Write-ChatAddressAudit -Result 'multiple' -PhoneDigits $phone
        return [pscustomobject]@{ Status = 'multiple'; Reply = ''; Reason = 'multiple address matches' }
    }

    $buildingAddress = Get-ChatBuildingAddress $matches[0]
    if ([string]::IsNullOrWhiteSpace($buildingAddress)) {
        Write-ChatAddressAudit -Result 'empty_address' -PhoneDigits $phone
        return [pscustomobject]@{ Status = 'empty_address'; Reply = ''; Reason = 'empty address' }
    }

    Write-ChatAddressAudit -Result 'ok' -PhoneDigits $phone -AddressKey $buildingAddress
    $reply = Select-ChatPhrase @(
        "Адрес $buildingAddress, всё еще актуально?",
        "Замена будет проходить по адресу $buildingAddress, всё актуально?"
    )
    return [pscustomobject]@{ Status = 'ok'; Reply = $reply; Reason = 'single match' }
}

function Get-ChatReply {
    param([string]$Text)
    $source = Normalize-ChatText $Text
    if ([string]::IsNullOrWhiteSpace($source)) { return [pscustomobject]@{ Action = 'skip'; Reply = ''; Reason = 'empty' } }
    $parsed = Get-Intent $source
    $intent = [string]$parsed.Intent

    if ($intent -eq 'blocked') { return [pscustomobject]@{ Action = 'operator'; Reply = 'Нужен оператор.'; Reason = 'unsafe' } }
    $hasRealAi = -not $NoRealAI -and -not [string]::IsNullOrWhiteSpace($script:AiApiKey)
    $useRealAi = $hasRealAi -and -not (@('key-count', 'color-only', 'booking-number', 'address-question') -contains $intent)
    if ($intent -eq 'ack' -and -not $useRealAi) { return (Get-ContextualAckDecision) }

    $trainingAllowed = @('proof-check') -contains $intent
    $trained = ''
    if ($trainingAllowed) {
        $trained = Get-TrainingReply -Text $source -Intent $intent
    }
    if (-not [string]::IsNullOrWhiteSpace($trained)) {
        Save-ChatMemory -Intent $intent -Incoming $source -Reply $trained -Parsed $parsed
        return [pscustomobject]@{ Action = 'reply'; Reply = $trained; Reason = "training:$intent" }
    }

    if ($useRealAi) {
        $aiReply = Invoke-RealAiReply -Text $source -Parsed $parsed
        if (-not [string]::IsNullOrWhiteSpace($aiReply)) {
            if ($aiReply -eq 'Нужен оператор.') {
                return [pscustomobject]@{ Action = 'operator'; Reply = 'Нужен оператор.'; Reason = "ai:$intent" }
            }
            Save-ChatMemory -Intent $intent -Incoming $source -Reply $aiReply -Parsed $parsed
            return [pscustomobject]@{ Action = 'reply'; Reply = $aiReply; Reason = "ai:$intent" }
        }
    }

    if ($intent -eq 'ack') { return (Get-ContextualAckDecision) }

    $reply = ''
    if ($intent -eq 'identity-question') {
        $reply = Select-ChatPhrase @(
            'Я секретарь председателя. Помогаю записать ключи, проверить номер брони и передать информацию по заявке.',
            'Я секретарь председателя, веду заявки по MAX: ключи, цвет и приглашение в чат дома.'
        )
    }
    elseif ($intent -eq 'keys-topic') {
        $reply = Select-ChatPhrase @(
            'Уточните, пожалуйста, количество ключей и желаемый цвет.',
            'Так сколько ключей мне бронировать и какой цвет нужен?',
            'Напишите, пожалуйста, сколько ключей требуется и какой цвет выбрать.'
        )
    }
    elseif ($intent -eq 'colors-question') {
        $reply = 'В наличии красный, желтый, синий, черный, зеленый и салатовый. Если цвет не важен, могу поставить любой доступный.'
    }
    elseif ($intent -eq 'not-resident') {
        $reply = Select-ChatPhrase @(
            'Поняла Вас. Вы, видимо, еще числитесь в списках жильцов. Я могу передать заявку, чтобы Вас исключили из реестра. Подавать?',
            'Услышала. Тогда могу направить заявку, чтобы Вас убрали из списка жильцов. Подавать?'
        )
    }
    elseif ($intent -eq 'not-resident-confirm') {
        $reply = Select-ChatPhrase @(
            'Хорошо, передам оператору на сверку списка.',
            'Поняла, направлю оператору, чтобы Вас проверили по списку жильцов.',
            'Хорошо, передаю на сверку, чтобы данные обновили.'
        )
    }
    elseif ($intent -eq 'not-resident-cancel') {
        $reply = Select-ChatPhrase @(
            'Хорошо, тогда ничего не передаю.',
            'Поняла, заявку на сверку не подаю.'
        )
    }
    elseif ($intent -eq 'relevance-question') {
        if ($script:Memory.LastTopic -eq 'chat') {
            $reply = Select-ChatPhrase @(
                'Вас указали в списке жильцов дома, поэтому уточняем добавление в новый чат MAX. Если уже не проживаете там, напишите - передам оператору на сверку.',
                'Пишу по списку жильцов дома: сейчас переводят жильцов в новый чат MAX. Если Вы уже не относитесь к этой квартире, я передам на проверку.'
            )
        }
        else {
            $reply = Select-ChatPhrase @(
                'Пишу по списку жильцов дома: по квартире проходит заявка на замену домофона и ключи. Если Вы уже не проживаете там, напишите - передам оператору на сверку.',
                'Вас указали в списке по дому, поэтому уточняем заявку по домофону. Если данные уже неактуальны, я передам оператору, чтобы список проверили.'
            )
        }
    }
    elseif ($intent -eq 'planned-replacement') {
        $reply = Select-ChatPhrase @(
            'Замена плановая, по инициативе ЖКХ. До 5 ключей предоставляют бесплатно.',
            'Это плановая замена домофона. ЖКХ предоставляет до 5 ключей бесплатно.'
        )
    }
    elseif ($intent -eq 'existing-chat') {
        $reply = Select-ChatPhrase @(
            'Да, понимаю. Старый чат пока может оставаться, но основное общение переводят в новый чат MAX, чтобы там были жильцы, службы и мастера.',
            'Понимаю, что чат уже есть. Сейчас делают новый MAX-чат дома: туда переводят жильцов и добавляют коммунальные службы с мастерами.',
            'Да, старый чат мог быть раньше. Новый нужен, чтобы собрать жильцов и службы дома в одном месте и дальше вести вопросы уже там.'
        )
    }
    elseif ($intent -eq 'old-chat-fate') {
        $reply = Select-ChatPhrase @(
            'Старый чат постепенно уберут, основное общение перенесут в новый чат MAX. В новом будут жильцы, коммунальные службы и мастера, чтобы вопросы по дому решались быстрее.',
            'Старый чат со временем закроют, поэтому жильцов переводят в новый чат MAX. Там будут службы дома и мастера, чтобы не терялись заявки и вопросы.',
            'Старый чат останется только временно, дальше общение будут вести в новом MAX-чате дома. Поэтому сейчас и добавляем жильцов туда.'
        )
    }
    elseif ($intent -eq 'home-chat-reason') {
        $reply = Select-ChatPhrase @(
            'Это общий чат жильцов дома в MAX. Там будут соседи, сотрудники коммунальных служб и мастера, чтобы быстрее решать вопросы по дому и передавать показания. Добавлять Вас?',
            'Речь про чат Вашего дома в MAX: туда добавляют жильцов, коммунальные службы и мастеров, чтобы по дому можно было быстрее связаться. Если хотите, отправлю приглашение.',
            'Это домовой чат в MAX. В нем будут жильцы и службы по дому, чтобы вопросы по дому не терялись. Вас добавить?'
        )
    }
    elseif ($intent -eq 'notification-received') {
        $reply = Select-ChatPhrase @(
            'Отлично. Проверьте, пожалуйста, чтобы количество ключей было указано верно, и перешлите мне номер брони.',
            'Хорошо, тогда перешлите мне номер брони, я закреплю заявку за Вами.'
        )
    }
    elseif ($intent -eq 'notification-missing') {
        if ($script:Memory.Expected -eq 'chat-invite' -or $script:Memory.LastTopic -eq 'chat') {
            $reply = Select-ChatPhrase @(
                'Поняла. Подождите пару минут и проверьте вкладку "Чаты" в MAX. Если приглашение не появится, напишите - передам на повторную отправку.',
                'Хорошо, значит пока не дошло. Проверьте MAX еще раз через пару минут, иногда приглашение приходит не сразу.',
                'Поняла, сейчас могло еще не появиться. Проверьте чаты MAX чуть позже, если не будет - напишите мне.'
            )
        }
        else {
            $reply = Select-ChatPhrase @(
                'Посмотрите, пожалуйста, еще раз в чатах MAX, иногда уведомление приходит не сразу. Если не появится, напишите мне - проверим.',
                'Поняла. Проверьте чаты MAX, уведомление могло затеряться. Если номера нет, напишите - передам на повторную проверку.'
            )
        }
    }
    elseif ($script:Memory.Expected -eq 'key-count' -and $intent -eq 'unknown') {
        $reply = 'Не поняла количество. Напишите цифрой, сколько ключей записать.'
    }
    elseif ($script:Memory.Expected -eq 'booking-number' -and $intent -eq 'unknown') {
        $reply = 'Поняла, значит номер пока не пришел. Проверьте MAX еще раз через пару минут, если номера не будет - напишите мне.'
    }
    elseif ($intent -eq 'address-question') {
        $addressCheck = Resolve-ChatAddressVerification
        if ([string]$addressCheck.Status -eq 'ok') {
            $reply = [string]$addressCheck.Reply
        }
        else {
            return [pscustomobject]@{ Action = 'operator'; Reply = 'Нужен оператор: сверка адреса.'; Reason = "address:$($addressCheck.Status)" }
        }
    }
    elseif ($intent -eq 'booking-number') {
        if (-not (Test-BookingNumberExpected ([string]$parsed.Booking))) {
            $reply = Select-ChatPhrase @(
                'Секунду, сверила: номер не совпадает. Проверьте, пожалуйста, номер брони в MAX и перешлите правильный.',
                'Минутку, проверила: этот номер не подходит. Пришлите, пожалуйста, правильный номер брони из MAX.',
                'Сейчас сверила, номер не тот. Посмотрите, пожалуйста, уведомление в MAX и перешлите верный номер брони.'
            )
        }
        else {
            $reply = Select-ChatPhrase @('Минутку, проверю.', 'Секунду, проверю.', 'Одну минуту, проверю.', 'Хорошо, сейчас сверю.')
        }
    }
    elseif ($intent -eq 'price-question') {
        $count = $parsed.Count
        if ($null -eq $count) {
            $reply = Select-ChatPhrase @('До 5 ключей бесплатно. Если больше 5, каждый следующий по 250 рублей.', 'Первые 5 ключей бесплатно, дальше по 250 рублей за ключ.')
        }
        elseif ($count -le 5) {
            $word = Get-KeyWord $count
            $reply = "$count $word бесплатно, так как до 5 ключей ЖКХ предоставляет без оплаты."
        }
        else {
            $word = Get-KeyWord $count
            $extra = $count - 5
            $extraWord = Get-KeyWord $extra
            $total = $extra * 250
            $reply = "$count ${word}: 5 бесплатно, еще $extra $extraWord по 250. Итого $total рублей."
        }
    }
    elseif ($intent -eq 'key-count') {
        $count = [int]$parsed.Count
        $word = Get-KeyWord $count
        if ($count -le 5) {
            $reply = Get-KeyBookingPrompt -Count $count
        }
        else {
            $extra = $count - 5
            $total = $extra * 250
            $reply = "Приняла, $count $word. До 5 бесплатно, еще $extra по 250 рублей, итого доплата $total рублей. Также Вам должно прийти уведомление в MAX с номером брони и количеством ключей. Проверьте, пожалуйста, информацию и перешлите мне — закреплю их за Вами."
        }
    }
    elseif ($intent -eq 'color-only') {
        if ([int]$script:Memory.LastKeyCount -gt 0) {
            $count = [int]$script:Memory.LastKeyCount
            $reply = Get-KeyBookingPrompt -Count $count
        }
        else {
            $reply = 'Поняла по цвету. Сколько ключей записать?'
        }
    }
    elseif ($intent -eq 'add-chat') {
        $reply = Select-ChatPhrase @(
            'Хорошо! Сейчас Вам в MAX должно поступить сообщение с номером приглашения. Перешлите его сюда, и я Вас добавлю.',
            'Да, добавляем. В MAX сейчас придет номер приглашения, перешлите его мне - добавлю Вас в чат.',
            'Хорошо, в течение пары минут в MAX должно прийти сообщение с номером приглашения. Перешлите его сюда.'
        )
    }
    elseif ($intent -eq 'invite-check') {
        $reply = Select-ChatPhrase @('Минутку, проверю приглашение.', 'Хорошо, сейчас проверю приглашение.', 'Одну минуту, проверю.')
    }
    elseif ($intent -eq 'booking-help') {
        $reply = Select-ChatPhrase @(
            'Номер брони должен прийти сообщением в MAX. Проверьте чаты, если не найдете - напишите мне.',
            'Посмотрите, пожалуйста, в чатах MAX. Если номера нет, напишите мне - передам на повторную проверку.'
        )
    }
    elseif ($intent -eq 'logistics') {
        $reply = Select-ChatPhrase @('Где и когда можно будет получить ключи, сообщат по факту изготовления.', 'Поняла, по получению сориентируют после изготовления ключей.')
    }
    elseif ($intent -eq 'proof-check') {
        $reply = Select-ChatPhrase @('Да, этого достаточно. Сейчас проверю.', 'Хорошо, так достаточно. Минутку, проверю.')
    }
    else {
        if ($script:Memory.LastTopic -eq 'chat') {
            $reply = Select-ChatPhrase @(
                'Я про домовой чат в MAX. В него переводят жильцов, чтобы там были соседи, коммунальные службы и мастера. Если хотите, отправлю приглашение.',
                'Речь идет о новом чате дома в MAX. Старый чат постепенно уберут, поэтому жильцов добавляют в новый. Вас добавить?',
                'Это по чату дома в MAX: туда будут приходить вопросы по дому и сообщения от служб. Если согласны, сейчас отправлю приглашение.'
            )
        }
        elseif ($script:Memory.LastTopic -eq 'keys') {
            $reply = Select-ChatPhrase @(
                'Я про замену домофона и ключи. До 5 ключей бесплатно, нужно только количество и цвет.',
                'По ключам: до 5 штук бесплатно. Напишите, сколько нужно и какой цвет выбрать.'
            )
        }
        else {
            $reply = 'Не совсем поняла вопрос. Напишите чуть точнее, и я отвечу по заявке.'
        }
    }

    Save-ChatMemory -Intent $intent -Incoming $source -Reply $reply -Parsed $parsed
    return [pscustomobject]@{ Action = 'reply'; Reply = $reply; Reason = "local:$intent" }
}

function Show-Help {
    Write-Host ''
    Write-Host 'Команды:'
    Write-Host '  /start  - включить ответы'
    Write-Host '  /stop   - остановить ответы'
    Write-Host '  /new    - новый диалог, сброс памяти'
    Write-Host '  /help   - помощь'
    Write-Host '  /exit   - выйти'
    if (-not $NoRealAI -and -not [string]::IsNullOrWhiteSpace($script:AiApiKey)) {
        Write-Host "  AI      - включен, модель: $AiModel"
    }
    else {
        Write-Host '  AI      - API-ключ не найден, работают локальные правила'
    }
    Write-Host ''
}

function Start-ChatTrainerDialog {
    $script:ChatRunning = $true
    $startReply = Get-StartMessage
    $script:Memory.LastIntent = 'start'
    $script:Memory.LastIncoming = '/start'
    $script:Memory.LastReply = $startReply
    $topic = Get-MessageTopic $startReply
    if (-not [string]::IsNullOrWhiteSpace($topic)) { $script:Memory.LastTopic = $topic }
    if ($script:Memory.LastTopic -eq 'chat') { $script:Memory.Expected = 'chat-consent' }
    elseif ($script:Memory.LastTopic -eq 'keys') { $script:Memory.Expected = 'key-count' }
    [void]$script:AiHistory.Add([pscustomobject]@{ role = 'assistant'; content = $startReply })
    return [pscustomobject]@{ Action = 'reply'; Reply = $startReply; Reason = 'start' }
}

function Invoke-ChatTrainerLine {
    param([string]$Line)

    $text = ([string]$Line).Trim()
    if ([string]::IsNullOrWhiteSpace($text)) {
        return [pscustomobject]@{ Action = 'skip'; Reply = ''; Reason = 'empty' }
    }

    $cmd = $text.ToLowerInvariant()
    if ($cmd -eq '/start' -or $cmd -eq '/statr' -or $cmd -eq '/старт') {
        return Start-ChatTrainerDialog
    }
    if ($cmd -eq '/stop') {
        $script:ChatRunning = $false
        return [pscustomobject]@{ Action = 'reply'; Reply = 'остановлен'; Reason = 'stop' }
    }
    if ($cmd -eq '/new') {
        Reset-ChatMemory
        $script:ChatRunning = $false
        return [pscustomobject]@{ Action = 'reply'; Reply = 'новый диалог'; Reason = 'new' }
    }
    if ($cmd -eq '/help') {
        return [pscustomobject]@{ Action = 'reply'; Reply = "Команды:`n/start - начать диалог`n/new - новый диалог`n/stop - остановить`n/help - помощь"; Reason = 'help' }
    }
    if ($cmd.StartsWith('/')) {
        return [pscustomobject]@{ Action = 'reply'; Reply = 'Не понял команду. Напиши /help или /start.'; Reason = 'unknown-command' }
    }
    if (-not $script:ChatRunning) {
        return [pscustomobject]@{ Action = 'reply'; Reply = 'остановлен, напиши /start'; Reason = 'not-running' }
    }

    return Get-ChatReply $text
}

if ($LibraryMode) {
    return
}

if (-not [string]::IsNullOrWhiteSpace($Once)) {
    $onceCmd = $Once.Trim().ToLowerInvariant()
    if ($onceCmd -eq '/start' -or $onceCmd -eq '/statr' -or $onceCmd -eq '/старт') {
        Write-Host (Get-StartMessage)
        return
    }
    if ($Trace) {
        $parsed = Get-Intent $Once
        Write-Host "input: $Once"
        Write-Host "intent: $($parsed.Intent)"
        Write-Host "count: $($parsed.Count)"
        Write-Host "color: $($parsed.Color)"
        Write-Host "booking: $($parsed.Booking)"
        Write-Host '---'
    }
    $decision = Get-ChatReply $Once
    if ($Trace) {
        Write-Host "action: $($decision.Action)"
        Write-Host "reason: $($decision.Reason)"
        Write-Host '---'
    }
    if ($decision.Action -eq 'reaction') {
        Write-Host "реакция: $($decision.Reply)"
    }
    else {
        Write-Host $decision.Reply
    }
    return
}

Clear-Host
Write-Host 'ИИ-тренажер Гуся'
Write-Host 'Пиши фразу клиента и жми Enter. Для выхода: /exit'
Show-Help

while ($true) {
    Write-Host -NoNewline 'Клиент> '
    $line = [Console]::ReadLine()
    if ($null -eq $line) { break }
    $cmd = $line.Trim().ToLowerInvariant()

    if ($cmd -eq '/exit' -or $cmd -eq 'exit') { break }
    if ($cmd -eq '/help') { Show-Help; continue }
    if ($cmd -eq '/start' -or $cmd -eq '/statr' -or $cmd -eq '/старт') {
        $script:ChatRunning = $true
        $startReply = Get-StartMessage
        $script:Memory.LastIntent = 'start'
        $script:Memory.LastIncoming = '/start'
        $script:Memory.LastReply = $startReply
        $topic = Get-MessageTopic $startReply
        if (-not [string]::IsNullOrWhiteSpace($topic)) { $script:Memory.LastTopic = $topic }
        if ($script:Memory.LastTopic -eq 'chat') { $script:Memory.Expected = 'chat-consent' }
        elseif ($script:Memory.LastTopic -eq 'keys') { $script:Memory.Expected = 'key-count' }
        [void]$script:AiHistory.Add([pscustomobject]@{ role = 'assistant'; content = $startReply })
        Write-Host "ИИ> $startReply"
        continue
    }
    if ($cmd -eq '/stop') { $script:ChatRunning = $false; Write-Host 'ИИ> остановлен'; continue }
    if ($cmd -eq '/new') {
        Reset-ChatMemory
        Write-Host 'ИИ> новый диалог'
        continue
    }
    if ($cmd.StartsWith('/')) {
        Write-Host 'ИИ> Не понял команду. Напиши /help или /start.'
        continue
    }

    if (-not $script:ChatRunning) {
        Write-Host 'ИИ> остановлен, напиши /start'
        continue
    }

    $decision = Get-ChatReply $line
    if ($Trace) {
        Write-Host "ИИ trace> action: $($decision.Action); reason: $($decision.Reason)"
    }
    if ($decision.Action -eq 'reaction') {
        Write-Host "ИИ> реакция: $($decision.Reply)"
    }
    else {
        Write-Host "ИИ> $($decision.Reply)"
    }
}

Write-Host 'ИИ-тренажер закрыт.'

