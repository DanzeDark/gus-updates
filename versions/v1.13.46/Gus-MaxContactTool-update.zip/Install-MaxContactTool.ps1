﻿param(
    [string]$SourceRoot = $PSScriptRoot
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$script:InstallLoadingForm = $null
$script:InstallLoadingPanel = $null
$script:InstallLoadingLabel = $null
$script:InstallLoadingProgress = $null
$script:InstallLoadingTimer = $null
$script:InstallLoadingFrame = 0

function Enable-InstallDoubleBuffer {
    param($Control)

    try {
        $property = $Control.GetType().GetProperty('DoubleBuffered', [Reflection.BindingFlags]'Instance,NonPublic')
        if ($property) { $property.SetValue($Control, $true, $null) }
    }
    catch {
    }
}

function Draw-InstallGooseScene {
    param(
        $Graphics,
        [int]$Width,
        [int]$Height
    )

    if ($null -eq $Graphics -or $Width -le 0 -or $Height -le 0) { return }

    $Graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $back = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
        (New-Object System.Drawing.Rectangle(0, 0, $Width, [Math]::Max(1, $Height))),
        [System.Drawing.Color]::FromArgb(14, 17, 27),
        [System.Drawing.Color]::FromArgb(38, 47, 68),
        [System.Drawing.Drawing2D.LinearGradientMode]::Vertical
    )
    $roadBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(35, 36, 42))
    $lineBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(255, 220, 96))
    $whiteBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(248, 248, 238))
    $wingBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(215, 222, 211))
    $orangeBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(244, 154, 54))
    $blackBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(19, 20, 23))
    $shadowBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(90, 0, 0, 0))
    $starBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(160, 235, 238, 244))
    $legPen = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(245, 154, 62), 3)
    try {
        $Graphics.FillRectangle($back, 0, 0, $Width, $Height)

        for ($i = 0; $i -lt 12; $i++) {
            $x = [int](($i * 53 + $script:InstallLoadingFrame * 2) % [Math]::Max(1, $Width))
            $y = [int](18 + (($i * 31) % [Math]::Max(1, [int]($Height * 0.45))))
            $Graphics.FillEllipse($starBrush, $x, $y, 3, 3)
        }

        $roadTop = [int]($Height * 0.62)
        $roadPoints = New-Object 'System.Drawing.Point[]' 4
        $roadPoints[0] = New-Object System.Drawing.Point -ArgumentList ([int]($Width * 0.16)), $roadTop
        $roadPoints[1] = New-Object System.Drawing.Point -ArgumentList ([int]($Width * 0.84)), $roadTop
        $roadPoints[2] = New-Object System.Drawing.Point -ArgumentList $Width, $Height
        $roadPoints[3] = New-Object System.Drawing.Point -ArgumentList 0, $Height
        $Graphics.FillPolygon($roadBrush, $roadPoints)

        $offset = ($script:InstallLoadingFrame * 12) % 92
        for ($x = -92 + $offset; $x -lt $Width + 92; $x += 92) {
            $Graphics.FillRectangle($lineBrush, $x, [int]($Height * 0.80), 42, 5)
        }

        $xGoose = [int](35 + (($script:InstallLoadingFrame * 8) % [Math]::Max(1, ($Width + 120))) - 70)
        $yGoose = [int]($Height * 0.55) + [int](3 * [Math]::Sin($script:InstallLoadingFrame * 0.55))
        $legSwing = [int](8 * [Math]::Sin($script:InstallLoadingFrame * 0.9))

        $Graphics.FillEllipse($shadowBrush, $xGoose + 7, $yGoose + 52, 78, 13)
        $Graphics.FillEllipse($whiteBrush, $xGoose + 10, $yGoose + 20, 56, 36)
        $Graphics.FillEllipse($wingBrush, $xGoose + 26, $yGoose + 28, 25, 17)
        $Graphics.FillEllipse($whiteBrush, $xGoose + 54, $yGoose + 6, 25, 25)
        $beak = New-Object 'System.Drawing.Point[]' 3
        $beak[0] = New-Object System.Drawing.Point -ArgumentList ([int]($xGoose + 76)), ([int]($yGoose + 17))
        $beak[1] = New-Object System.Drawing.Point -ArgumentList ([int]($xGoose + 96)), ([int]($yGoose + 21))
        $beak[2] = New-Object System.Drawing.Point -ArgumentList ([int]($xGoose + 76)), ([int]($yGoose + 25))
        $Graphics.FillPolygon($orangeBrush, $beak)
        $Graphics.FillEllipse($blackBrush, $xGoose + 68, $yGoose + 14, 4, 4)
        $Graphics.DrawLine($legPen, $xGoose + 30, $yGoose + 52, $xGoose + 22 + $legSwing, $yGoose + 66)
        $Graphics.DrawLine($legPen, $xGoose + 48, $yGoose + 52, $xGoose + 57 - $legSwing, $yGoose + 66)
        $Graphics.DrawLine($legPen, $xGoose + 21 + $legSwing, $yGoose + 66, $xGoose + 11 + $legSwing, $yGoose + 66)
        $Graphics.DrawLine($legPen, $xGoose + 56 - $legSwing, $yGoose + 66, $xGoose + 68 - $legSwing, $yGoose + 66)
    }
    finally {
        foreach ($item in @($back, $roadBrush, $lineBrush, $whiteBrush, $wingBrush, $orangeBrush, $blackBrush, $shadowBrush, $starBrush, $legPen)) {
            try { if ($item) { $item.Dispose() } } catch {}
        }
    }
}

function Show-InstallLoading {
    param(
        [string]$Text = 'Гусь готовит установку...',
        [int]$Percent = 0
    )

    if ($script:InstallLoadingForm) {
        Update-InstallLoading -Text $Text -Percent $Percent
        return
    }

    $form = New-Object System.Windows.Forms.Form
    $form.Text = 'Установка Гуся'
    $form.FormBorderStyle = 'FixedDialog'
    $form.StartPosition = 'CenterScreen'
    $form.ShowInTaskbar = $true
    $form.TopMost = $true
    $form.MaximizeBox = $false
    $form.MinimizeBox = $false
    $form.ClientSize = New-Object System.Drawing.Size(560, 330)
    $form.BackColor = [System.Drawing.Color]::FromArgb(13, 15, 24)
    $form.Font = New-Object System.Drawing.Font('Segoe UI', 9)
    Enable-InstallDoubleBuffer $form

    $title = New-Object System.Windows.Forms.Label
    $title.Text = 'Гусь устанавливает базу'
    $title.Dock = 'Top'
    $title.Height = 44
    $title.TextAlign = 'MiddleCenter'
    $title.ForeColor = [System.Drawing.Color]::FromArgb(255, 244, 194)
    $title.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 15)
    $form.Controls.Add($title)

    $panel = New-Object System.Windows.Forms.Panel
    $panel.Dock = 'Top'
    $panel.Height = 190
    $panel.Margin = New-Object System.Windows.Forms.Padding(10)
    Enable-InstallDoubleBuffer $panel
    $panel.Add_Paint({
        param($sender, $eventArgs)
        Draw-InstallGooseScene -Graphics $eventArgs.Graphics -Width $sender.ClientSize.Width -Height $sender.ClientSize.Height
    })
    $form.Controls.Add($panel)

    $label = New-Object System.Windows.Forms.Label
    $label.Text = $Text
    $label.Dock = 'Top'
    $label.Height = 36
    $label.TextAlign = 'MiddleCenter'
    $label.ForeColor = [System.Drawing.Color]::FromArgb(235, 238, 244)
    $label.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 10)
    $form.Controls.Add($label)

    $progress = New-Object System.Windows.Forms.ProgressBar
    $progress.Dock = 'Top'
    $progress.Height = 22
    $progress.Minimum = 0
    $progress.Maximum = 100
    $progress.Value = [Math]::Max(0, [Math]::Min(100, $Percent))
    $progress.Margin = New-Object System.Windows.Forms.Padding(24, 0, 24, 0)
    $form.Controls.Add($progress)

    $hint = New-Object System.Windows.Forms.Label
    $hint.Text = 'Не закрывай окно: гусь несет файлы на новый ПК.'
    $hint.Dock = 'Fill'
    $hint.TextAlign = 'MiddleCenter'
    $hint.ForeColor = [System.Drawing.Color]::FromArgb(156, 166, 186)
    $form.Controls.Add($hint)

    $timer = New-Object System.Windows.Forms.Timer
    $timer.Interval = 42
    $timer.Add_Tick({
        $script:InstallLoadingFrame++
        if ($script:InstallLoadingPanel) { $script:InstallLoadingPanel.Invalidate() }
    })

    $script:InstallLoadingForm = $form
    $script:InstallLoadingPanel = $panel
    $script:InstallLoadingLabel = $label
    $script:InstallLoadingProgress = $progress
    $script:InstallLoadingTimer = $timer
    $script:InstallLoadingFrame = 0
    $timer.Start()
    [void]$form.Show()
    [System.Windows.Forms.Application]::DoEvents()
}

function Update-InstallLoading {
    param(
        [string]$Text,
        [int]$Percent = -1
    )

    if ($script:InstallLoadingLabel -and -not [string]::IsNullOrWhiteSpace($Text)) {
        $script:InstallLoadingLabel.Text = $Text
    }
    if ($script:InstallLoadingProgress -and $Percent -ge 0) {
        $script:InstallLoadingProgress.Value = [Math]::Max(0, [Math]::Min(100, $Percent))
    }
    if ($script:InstallLoadingPanel) { $script:InstallLoadingPanel.Invalidate() }
    [System.Windows.Forms.Application]::DoEvents()
}

function Hide-InstallLoading {
    try { if ($script:InstallLoadingTimer) { $script:InstallLoadingTimer.Stop(); $script:InstallLoadingTimer.Dispose() } } catch {}
    try { if ($script:InstallLoadingForm) { $script:InstallLoadingForm.Close(); $script:InstallLoadingForm.Dispose() } } catch {}
    $script:InstallLoadingForm = $null
    $script:InstallLoadingPanel = $null
    $script:InstallLoadingLabel = $null
    $script:InstallLoadingProgress = $null
    $script:InstallLoadingTimer = $null
}

function Get-InstallerTempRoot {
    $candidates = @(
        $env:TEMP,
        $env:TMP,
        [IO.Path]::GetTempPath(),
        (Join-Path $env:WINDIR 'Temp')
    )

    foreach ($candidate in $candidates) {
        if ([string]::IsNullOrWhiteSpace($candidate)) { continue }
        try {
            $full = [IO.Path]::GetFullPath($candidate)
            if (Test-Path -LiteralPath $full -PathType Container) {
                return $full
            }
        }
        catch {
        }
    }

    throw 'Не удалось найти рабочую временную папку Windows.'
}

function Get-InstallerDesktopPath {
    $desktopPath = [Environment]::GetFolderPath('Desktop')
    if ([string]::IsNullOrWhiteSpace($desktopPath) -or -not (Test-Path -LiteralPath $desktopPath -PathType Container)) {
        $desktopPath = Join-Path $env:USERPROFILE 'Desktop'
    }
    if (-not (Test-Path -LiteralPath $desktopPath -PathType Container)) {
        New-Item -ItemType Directory -Path $desktopPath -Force | Out-Null
    }
    return [IO.Path]::GetFullPath($desktopPath)
}

function Get-DefaultInstallParent {
    param([string]$DesktopPath)

    $candidates = New-Object System.Collections.Generic.List[string]
    if (-not [string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)) {
        $candidates.Add((Join-Path $env:LOCALAPPDATA 'Programs')) | Out-Null
    }
    $candidates.Add($DesktopPath) | Out-Null

    foreach ($candidate in @($candidates)) {
        if ([string]::IsNullOrWhiteSpace($candidate)) { continue }
        try {
            New-Item -ItemType Directory -Path $candidate -Force | Out-Null
            if (Test-Path -LiteralPath $candidate -PathType Container) {
                return [IO.Path]::GetFullPath($candidate)
            }
        }
        catch {
        }
    }

    throw 'Не удалось выбрать папку для установки.'
}

function Get-InstallDestination {
    param([string]$SelectedPath)

    $selected = [IO.Path]::GetFullPath($SelectedPath)
    $leaf = Split-Path -Leaf $selected
    if ($leaf -in @('Гусь', 'Gus-MaxContactTool', 'MaxContactTool')) {
        return $selected
    }
    return (Join-Path $selected 'Гусь')
}

function Copy-InstallerItem {
    param(
        [string]$SourceRoot,
        [string]$DestinationRoot,
        [string]$RelativePath
    )

    $source = Join-Path $SourceRoot $RelativePath
    if (-not (Test-Path -LiteralPath $source)) { return }

    $target = Join-Path $DestinationRoot $RelativePath
    $targetParent = Split-Path -Parent $target
    if (-not (Test-Path -LiteralPath $targetParent)) {
        New-Item -ItemType Directory -Path $targetParent -Force | Out-Null
    }

    Copy-Item -LiteralPath $source -Destination $target -Recurse -Force
}

function New-GooseShortcut {
    param(
        [string]$InstallPath,
        [string]$DesktopPath
    )

    $exe = Join-Path $InstallPath 'Gus-MaxContactTool.exe'
    $target = if (Test-Path -LiteralPath $exe -PathType Leaf) { $exe } else { Join-Path $InstallPath 'Run-MaxContactTool.vbs' }
    $shortcutPath = Join-Path $DesktopPath 'Гусь.lnk'
    $wsh = New-Object -ComObject WScript.Shell
    $shortcut = $wsh.CreateShortcut($shortcutPath)
    $shortcut.TargetPath = $target
    $shortcut.WorkingDirectory = $InstallPath
    $shortcut.Description = 'Гусь'
    $shortcut.WindowStyle = 1

    $icon = Join-Path $InstallPath 'assets\goose.ico'
    if (Test-Path -LiteralPath $icon -PathType Leaf) {
        $shortcut.IconLocation = $icon
    }
    elseif (Test-Path -LiteralPath $exe -PathType Leaf) {
        $shortcut.IconLocation = $exe
    }

    $shortcut.Save()
    return $shortcutPath
}

function Backup-LocalFiles {
    param(
        [string[]]$SourceRoots,
        [string]$BackupRoot
    )

    foreach ($sourceRoot in @($SourceRoots)) {
        if ([string]::IsNullOrWhiteSpace($sourceRoot) -or -not (Test-Path -LiteralPath $sourceRoot -PathType Container)) { continue }
        foreach ($name in @('max_contact_state.json','max_contact_replies.json','update_source.txt','update_channel.txt','gus_auth.json','gus_ai_config.json')) {
            $source = Join-Path $sourceRoot $name
            $target = Join-Path $BackupRoot $name
            if ((Test-Path -LiteralPath $source -PathType Leaf) -and -not (Test-Path -LiteralPath $target)) {
                Copy-Item -LiteralPath $source -Destination $target -Force
            }
        }
    }
}

function Restore-LocalFiles {
    param(
        [string]$BackupRoot,
        [string]$InstallPath
    )

    foreach ($name in @('max_contact_state.json','max_contact_replies.json','gus_auth.json','gus_ai_config.json')) {
        $source = Join-Path $BackupRoot $name
        if (Test-Path -LiteralPath $source -PathType Leaf) {
            Copy-Item -LiteralPath $source -Destination (Join-Path $InstallPath $name) -Force
        }
    }

    foreach ($name in @('update_source.txt','update_channel.txt')) {
        $source = Join-Path $BackupRoot $name
        $target = Join-Path $InstallPath $name
        if ((-not (Test-Path -LiteralPath $target -PathType Leaf)) -and (Test-Path -LiteralPath $source -PathType Leaf)) {
            Copy-Item -LiteralPath $source -Destination $target -Force
        }
    }
}

$src = [IO.Path]::GetFullPath($SourceRoot)
$script:GusTempRoot = Get-InstallerTempRoot
$env:TEMP = $script:GusTempRoot
$env:TMP = $script:GusTempRoot
$desktop = Get-InstallerDesktopPath
$defaultParent = Get-DefaultInstallParent -DesktopPath $desktop

$dialog = New-Object System.Windows.Forms.FolderBrowserDialog
$dialog.Description = 'Выбери место, где установщик сам создаст папку Гусь'
$dialog.ShowNewFolderButton = $true
$dialog.SelectedPath = $defaultParent
$dialog.RootFolder = [System.Environment+SpecialFolder]::Desktop
if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
    throw 'Установка отменена.'
}

$dst = Get-InstallDestination $dialog.SelectedPath
if ([string]::IsNullOrWhiteSpace($dst)) {
    throw 'Папка установки не выбрана.'
}
New-Item -ItemType Directory -Path $dst -Force | Out-Null

$backup = Join-Path $script:GusTempRoot ('GusInstallBackup_' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $backup -Force | Out-Null

$loadingShown = $false
try {
    $legacyDst = Join-Path $desktop 'MaxContactTool'
    Backup-LocalFiles -SourceRoots @($dst, $legacyDst) -BackupRoot $backup

    Show-InstallLoading -Text 'Гусь проверяет папку установки...' -Percent 5
    $loadingShown = $true

    if (-not ([IO.Path]::GetFullPath($src).TrimEnd('\') -ieq [IO.Path]::GetFullPath($dst).TrimEnd('\'))) {
        $installItems = @(
            'Gus-MaxContactTool.exe',
            'Install-MaxContactTool.bat',
            'Install-MaxContactTool.ps1',
            'MaxContactTool.ps1',
            'Run-MaxContactTool.bat',
            'Run-MaxContactTool.vbs',
            'gus_update.json',
            'gus_accounts.json',
            'VERSION.txt',
            'update_source.txt',
            'update_channel.txt',
            'max_contact_replies.json',
            'README.md',
            'sample_contacts.txt',
            'sample_messages.txt',
            'type_text_ahk_v1.ahk',
            'type_text_ahk_v2.ahk',
            'Гусь.bat',
            'Гусь.vbs',
            'assets',
            'Maxitochka'
        )
        $copyIndex = 0
        foreach ($relative in $installItems) {
            $copyIndex++
            $percent = 8 + [int](($copyIndex / [Math]::Max(1, $installItems.Count)) * 72)
            Update-InstallLoading -Text ("Гусь переносит: " + $relative) -Percent $percent
            Copy-InstallerItem -SourceRoot $src -DestinationRoot $dst -RelativePath $relative
        }
    }

    Update-InstallLoading -Text 'Гусь возвращает настройки...' -Percent 84
    Restore-LocalFiles -BackupRoot $backup -InstallPath $dst

    Update-InstallLoading -Text 'Гусь ставит ярлык на рабочий стол...' -Percent 92
    $shortcutPath = New-GooseShortcut -InstallPath $dst -DesktopPath $desktop
    foreach ($oldShortcut in @(
        (Join-Path $desktop 'Gus-MaxContactTool.bat'),
        (Join-Path $desktop 'Maxitochka.bat')
    )) {
        if (Test-Path -LiteralPath $oldShortcut) {
            Remove-Item -LiteralPath $oldShortcut -Force -ErrorAction SilentlyContinue
        }
    }

    Update-InstallLoading -Text 'Гусь снимает блокировку Windows с файлов...' -Percent 97
    try { Get-ChildItem -LiteralPath $dst -Recurse -Force | Unblock-File -ErrorAction SilentlyContinue } catch {}

    Update-InstallLoading -Text 'Готово. Гусь на месте.' -Percent 100
    Start-Sleep -Milliseconds 450
    Hide-InstallLoading
    $loadingShown = $false

    Write-Host ''
    Write-Host ('Installed to: ' + $dst)
    Write-Host ('Shortcut: ' + $shortcutPath)
    Write-Host ''
    [System.Windows.Forms.MessageBox]::Show("Гусь установлен.`n`nПапка: $dst`nЯрлык: $shortcutPath", 'Гусь', 'OK', 'Information') | Out-Null
}
finally {
    if ($loadingShown) { Hide-InstallLoading }
    Remove-Item -LiteralPath $backup -Recurse -Force -ErrorAction SilentlyContinue
}
