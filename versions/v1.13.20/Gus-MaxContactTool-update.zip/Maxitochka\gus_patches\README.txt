Gus Maxitochka notification patches. These files keep desktop MAX notifications working after Maxitochka updates.
