"""Автоустановка обновления: распаковка zip и перезапуск Maxitochka."""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

from app_logger import get_logger
from settings_store import app_data_root

_log = get_logger("update")

# Не затирать при распаковке zip поверх установки — данные менеджера.
_PROTECTED_NAMES = frozenset(
    {
        "proxies.txt",
        "settings.json",
        "google_sheets.json",
    }
)
_PROTECTED_PREFIXES = (
    "tokenbase/",
    "tokenbase\\",
    "profiles/",
    "profiles\\",
    "gus_patches/",
    "gus_patches\\",
    "dotlauncher.exe_extracted/storage.json",
    "dotlauncher.exe_extracted\\storage.json",
    "dotlauncher.exe_extracted/proxy_stats.json",
    "dotlauncher.exe_extracted\\proxy_stats.json",
)

_CREATE_NO_WINDOW = 0x08000000
_DETACHED_PROCESS = 0x00000008
_CREATE_NEW_CONSOLE = 0x00000010
_PROCESS_NAME = "Maxitochka.exe"


def resolve_install_dir() -> str:
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    root = Path(__file__).resolve().parent.parent
    dist = root / "dist" / "Maxitochka"
    if (dist / _PROCESS_NAME).is_file():
        return str(dist)
    return str(root)


def can_auto_install() -> bool:
    target = resolve_install_dir()
    exe = os.path.join(target, _PROCESS_NAME)
    if os.path.isfile(exe):
        return True
    return bool(getattr(sys, "frozen", False))


def _updates_dir() -> str:
    path = os.path.join(app_data_root(), "updates")
    os.makedirs(path, exist_ok=True)
    return path


def _should_preserve_user_file(rel_name: str, out_path: Path) -> bool:
    norm = (rel_name or "").replace("\\", "/").lower()
    base = os.path.basename(norm)
    if base in _PROTECTED_NAMES and out_path.is_file():
        return True
    for prefix in _PROTECTED_PREFIXES:
        if norm.startswith(prefix.lower()) and out_path.is_file():
            return True
    return False


def extract_zip(zip_path: str, target_dir: str) -> int:
    """Распаковать release zip в папку установки. Возвращает число файлов."""
    src = os.path.abspath(zip_path)
    dest = Path(os.path.abspath(target_dir))
    if not os.path.isfile(src):
        raise FileNotFoundError(f"Архив не найден: {src}")
    dest.mkdir(parents=True, exist_ok=True)

    count = 0
    with zipfile.ZipFile(src, "r") as zf:
        for info in zf.infolist():
            name = (info.filename or "").replace("\\", "/").lstrip("/")
            if not name or name.endswith("/"):
                continue
            out_path = dest / name
            if _should_preserve_user_file(name, out_path):
                _log.info("update skip user file: %s", name)
                continue
            out_path.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(info) as zsrc, open(out_path, "wb") as out:
                shutil.copyfileobj(zsrc, out)
            count += 1
    _log.info("update extracted %s files -> %s", count, dest)
    try:
        apply_local_overrides(str(dest))
    except Exception:
        _log.exception("apply local overrides after update failed")
    return count


def _read_text_file(path: Path) -> str:
    for enc in ("utf-8-sig", "utf-8", "cp1251"):
        try:
            return path.read_text(encoding=enc)
        except UnicodeDecodeError:
            continue
    return path.read_text(encoding="utf-8", errors="ignore")


def _ensure_message_notifications_hook(src_dir: Path) -> bool:
    ui_path = src_dir / "ui_patches.py"
    if not ui_path.is_file():
        return False
    text = _read_text_file(ui_path)
    if "message_notifications" in text:
        return False

    hook = '            ("message_notifications", "install_message_notifications"),'
    anchors = (
        '            ("settings_panel", "install_settings_panel"),',
        '            ("crm_panel", "install_crm_panel"),',
    )
    updated = text
    for anchor in anchors:
        if anchor in updated:
            if anchor.startswith('            ("settings_panel"'):
                updated = updated.replace(anchor, hook + "\n" + anchor, 1)
            else:
                updated = updated.replace(anchor, anchor + "\n" + hook, 1)
            break
    if updated == text:
        return False

    ui_path.write_text(updated, encoding="utf-8", newline="")
    return True


def apply_local_overrides(target_dir: str) -> None:
    """Restore local Gus patches that should survive Maxitochka updates."""
    target = Path(os.path.abspath(target_dir))
    patch_src = target / "gus_patches" / "maxitochka" / "src"
    app_src = target / "_internal" / "src"
    if not patch_src.is_dir() or not app_src.is_dir():
        return

    restored = 0
    for name in ("message_notifications.py", "update_installer.py"):
        src = patch_src / name
        dst = app_src / name
        if src.is_file():
            shutil.copy2(src, dst)
            restored += 1

    hooked = _ensure_message_notifications_hook(app_src)
    if restored or hooked:
        _log.info("local Gus overrides restored: files=%s hook=%s", restored, hooked)


def _ps_quote(value: str) -> str:
    """Безопасно вставить строку в PowerShell single-quoted literal."""
    return "'" + str(value).replace("'", "''") + "'"


def _relaunch_target(target_dir: str) -> tuple[str, str, str]:
    """(exe, args, workdir) для перезапуска после обновления."""
    exe = os.path.join(target_dir, _PROCESS_NAME)
    if os.path.isfile(exe) or getattr(sys, "frozen", False):
        return exe, "", target_dir
    # dev-режим: перезапуск через python run_launcher.py
    root = Path(__file__).resolve().parent.parent
    launcher = root / "run_launcher.py"
    return sys.executable, str(launcher), str(root)


def _write_apply_script(zip_path: str, target_dir: str) -> str:
    """Создать скрытый PowerShell-скрипт установки (ждёт закрытие по PID)."""
    exe, exe_args, workdir = _relaunch_target(target_dir)
    ps_path = os.path.abspath(os.path.join(_updates_dir(), "apply_update.ps1"))

    header = (
        f"$ParentPid = {int(os.getpid())}\n"
        f"$Zip = {_ps_quote(zip_path)}\n"
        f"$Target = {_ps_quote(target_dir)}\n"
        f"$Exe = {_ps_quote(exe)}\n"
        f"$ExeArgs = {_ps_quote(exe_args)}\n"
        f"$WorkDir = {_ps_quote(workdir)}\n"
        f"$Self = {_ps_quote(ps_path)}\n"
    )

    body = r"""
try { $host.UI.RawUI.WindowTitle = 'Обновление Maxitochka' } catch {}
function Step($m) { Write-Host ("  " + $m) -ForegroundColor Cyan }

Write-Host ""
Write-Host "  ====== ОБНОВЛЕНИЕ MAXITOCHKA ======" -ForegroundColor Green
Write-Host "  Не закрывайте это окно — оно само исчезнет." -ForegroundColor DarkGray
Write-Host ""

# 1. Дождаться полного закрытия Maxitochka (по PID родителя).
Step "Ожидание закрытия программы..."
for ($i = 0; $i -lt 240; $i++) {
    $p = Get-Process -Id $ParentPid -ErrorAction SilentlyContinue
    if (-not $p) { break }
    Start-Sleep -Milliseconds 500
}
Start-Sleep -Milliseconds 800

# 2. Закрыть зависшие chromedriver, иначе файлы могут быть заняты.
Get-Process -Name chromedriver -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue

# 3. Распаковать архив поверх установки (с перезаписью и ретраями на занятые файлы).
Step "Распаковка файлов..."
Add-Type -AssemblyName System.IO.Compression.FileSystem
try {
    $zipObj = [System.IO.Compression.ZipFile]::OpenRead($Zip)
    $all = @($zipObj.Entries | Where-Object { -not [string]::IsNullOrEmpty($_.Name) })
    $total = $all.Count
    $n = 0
    foreach ($entry in $all) {
        $n++
        $dest = Join-Path $Target $entry.FullName
        $dir = Split-Path $dest -Parent
        if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
        $leaf = Split-Path $dest -Leaf
        $rel = ($entry.FullName -replace '\\','/').ToLower()
        if (($leaf -eq 'proxies.txt' -or $leaf -eq 'settings.json' -or $leaf -eq 'google_sheets.json') -and (Test-Path -LiteralPath $dest)) {
            continue
        }
        if (($rel.StartsWith('tokenbase/') -or $rel.StartsWith('profiles/')) -and (Test-Path -LiteralPath $dest)) {
            continue
        }
        if (($rel.StartsWith('dotlauncher.exe_extracted/storage.json') -or $rel.StartsWith('dotlauncher.exe_extracted/proxy_stats.json')) -and (Test-Path -LiteralPath $dest)) {
            continue
        }
        for ($r = 0; $r -lt 30; $r++) {
            try {
                [System.IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $dest, $true)
                break
            } catch {
                if ($r -eq 29) { throw }
                Start-Sleep -Milliseconds 300
            }
        }
        if (($n % 20) -eq 0 -or $n -eq $total) {
            $pct = [int](100 * $n / [Math]::Max(1, $total))
            Write-Progress -Activity "Распаковка обновления" -Status "$n из $total файлов" -PercentComplete $pct
        }
    }
    $zipObj.Dispose()
    Write-Progress -Activity "Распаковка обновления" -Completed
    Step "Готово: распаковано $total файлов."
} catch {
    Write-Host ""
    Write-Host ("  ОШИБКА распаковки: " + $_.Exception.Message) -ForegroundColor Red
    Write-Host "  Закройте все окна Maxitochka и попробуйте снова." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "  Нажмите Enter, чтобы закрыть это окно..."
    [void](Read-Host)
    exit 1
}

# 4. Запустить обновлённую программу.
Step "Запуск обновлённой Maxitochka..."
$PatchSrc = Join-Path $Target 'gus_patches\maxitochka\src'
$AppSrc = Join-Path $Target '_internal\src'
if ((Test-Path -LiteralPath $PatchSrc) -and (Test-Path -LiteralPath $AppSrc)) {
    foreach ($PatchName in @('message_notifications.py', 'update_installer.py')) {
        $PatchFile = Join-Path $PatchSrc $PatchName
        if (Test-Path -LiteralPath $PatchFile) {
            Copy-Item -LiteralPath $PatchFile -Destination (Join-Path $AppSrc $PatchName) -Force
        }
    }
    $UiPatch = Join-Path $AppSrc 'ui_patches.py'
    if (Test-Path -LiteralPath $UiPatch) {
        $Text = [System.IO.File]::ReadAllText($UiPatch, [System.Text.Encoding]::UTF8)
        if ($Text -notmatch 'message_notifications') {
            $Hook = '            ("message_notifications", "install_message_notifications"),'
            $Anchor = '            ("settings_panel", "install_settings_panel"),'
            if ($Text.Contains($Anchor)) {
                $Text = $Text.Replace($Anchor, ($Hook + "`r`n" + $Anchor))
                $Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
                [System.IO.File]::WriteAllText($UiPatch, $Text, $Utf8NoBom)
            }
        }
    }
    Step "Gus patches restored."
}

if ($Exe -and (Test-Path $Exe)) {
    if ($ExeArgs) {
        Start-Process -FilePath $Exe -ArgumentList $ExeArgs -WorkingDirectory $WorkDir
    } else {
        Start-Process -FilePath $Exe -WorkingDirectory $WorkDir
    }
    Step "Обновление установлено. Программа запускается."
} else {
    Write-Host "  Не найден файл запуска: $Exe" -ForegroundColor Yellow
    Write-Host "  Запустите Maxitochka вручную." -ForegroundColor Yellow
    Start-Sleep -Seconds 4
}

Start-Sleep -Seconds 2
Remove-Item -LiteralPath $Self -Force -ErrorAction SilentlyContinue
"""

    with open(ps_path, "w", encoding="utf-8-sig", newline="\r\n") as f:
        f.write(header + body)
    return ps_path


def schedule_install_and_restart(zip_path: str, *, target_dir: str | None = None) -> str:
    """Запустить скрытый установщик и закрыть текущее приложение."""
    target = os.path.abspath(target_dir or resolve_install_dir())
    zip_abs = os.path.abspath(zip_path)
    if not os.path.isfile(zip_abs):
        raise FileNotFoundError(f"Архив не найден: {zip_abs}")

    ps_path = _write_apply_script(zip_abs, target)
    subprocess.Popen(
        [
            "powershell.exe",
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            ps_path,
        ],
        cwd=_updates_dir(),
        creationflags=_CREATE_NEW_CONSOLE,
        close_fds=True,
    )
    _log.info("scheduled update install (visible): %s -> %s", zip_abs, target)
    return ps_path


def apply_update_cli(zip_path: str, target_dir: str) -> int:
    """CLI-режим: распаковать zip и запустить Maxitochka.exe."""
    try:
        extract_zip(zip_path, target_dir)
    except Exception:
        _log.exception("apply_update_cli failed")
        return 1

    exe = os.path.join(os.path.abspath(target_dir), _PROCESS_NAME)
    if os.path.isfile(exe):
        subprocess.Popen([exe], cwd=target_dir, close_fds=True)
    return 0


def install_downloaded_zip(zip_path: str, parent: object | None = None) -> bool:
    """
    Подтвердить и запустить автоустановку.
    Возвращает True, если приложение нужно закрыть.
    """
    from PyQt6.QtWidgets import QApplication, QMessageBox

    if not can_auto_install():
        QMessageBox.warning(
            parent,
            "Установка",
            "Автоустановка доступна только для собранного Maxitochka.exe.",
        )
        return False

    target = resolve_install_dir()
    box = QMessageBox(parent)
    box.setWindowTitle("Установка обновления")
    box.setText("Установить обновление сейчас?")
    box.setInformativeText(
        "Программа закроется, обновление установится в фоне "
        "(обычно 10–60 секунд) и Maxitochka откроется снова автоматически.\n\n"
        "Никаких окон терминала — всё произойдёт само.\n"
        "Закройте открытые браузеры сессий, если они ещё работают."
    )
    box.setStandardButtons(
        QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
    )
    box.button(QMessageBox.StandardButton.Yes).setText("Установить и перезапустить")
    box.button(QMessageBox.StandardButton.No).setText("Отмена")
    if box.exec() != QMessageBox.StandardButton.Yes:
        return False

    schedule_install_and_restart(zip_path, target_dir=target)
    app = QApplication.instance()
    if app is not None:
        app.quit()
    else:
        sys.exit(0)
    return True
