"""Быстрые уведомления о новых сообщениях в выбранных MAX."""

from __future__ import annotations

import re
import threading
import time
from typing import Any

from PyQt6.QtCore import (
    QEasingCurve,
    QObject,
    QPoint,
    QPropertyAnimation,
    QRect,
    Qt,
    QTimer,
    pyqtSignal,
)
from PyQt6.QtGui import QCursor, QGuiApplication
from PyQt6.QtWidgets import (
    QFrame,
    QGraphicsOpacityEffect,
    QLabel,
    QLayout,
    QSystemTrayIcon,
    QVBoxLayout,
    QWidget,
)

from app_logger import get_logger
from browser_launcher import resolve_driver
from browser_session import is_session_alive
from max_ui_actions import is_ui_chrome_title
from theme import ACCENT, BG_CARD, TEXT, TEXT_DIM

_log = get_logger("message_notifications")

_POLL_INTERVAL_MS = 20000
_MAX_NOTICES_PER_SCAN = 5
_NOTICE_W = 360
_NOTICE_MARGIN = 18
_NOTICE_GAP = 10
_NOTICE_DURATION_MS = 7600


class _NotifyBridge(QObject):
    found = pyqtSignal(object)


class _DesktopNotice(QWidget):
    def __init__(
        self,
        title: str,
        body: str,
        parent: QWidget | None = None,
        on_click: Any = None,
    ) -> None:
        super().__init__(
            parent,
            Qt.WindowType.Tool
            | Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint,
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating, True)
        self.setWindowFlag(Qt.WindowType.WindowDoesNotAcceptFocus, True)
        self.setFixedWidth(_NOTICE_W)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._on_click = on_click

        frame = QFrame(self)
        frame.setObjectName("DesktopMaxNotice")
        frame.setFixedWidth(_NOTICE_W)
        frame.setStyleSheet(
            f"""
            QFrame#DesktopMaxNotice {{
                background: {BG_CARD};
                border: 1px solid {ACCENT};
                border-radius: 14px;
            }}
            QLabel {{
                background: transparent;
                border: none;
            }}
            """
        )
        lay = QVBoxLayout(frame)
        lay.setContentsMargins(16, 12, 16, 12)
        lay.setSpacing(5)

        title_label = QLabel(title)
        title_label.setStyleSheet(f"color: {TEXT}; font-size: 13px; font-weight: 800;")
        title_label.setWordWrap(True)
        title_label.setFixedWidth(_NOTICE_W - 32)
        lay.addWidget(title_label)

        body_label = QLabel(body)
        body_label.setStyleSheet(f"color: {TEXT_DIM}; font-size: 12px; font-weight: 600;")
        body_label.setWordWrap(True)
        body_label.setFixedWidth(_NOTICE_W - 32)
        lay.addWidget(body_label)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSizeConstraint(QLayout.SizeConstraint.SetFixedSize)
        outer.addWidget(frame)

        self._opacity = QGraphicsOpacityEffect(self)
        self.setGraphicsEffect(self._opacity)
        self._opacity.setOpacity(0.0)

    def mousePressEvent(self, event) -> None:
        try:
            if event.button() == Qt.MouseButton.LeftButton and callable(self._on_click):
                self._on_click()
        except Exception:
            _log.exception("desktop notification click failed")
        super().mousePressEvent(event)

    def animate_in(self, x: int, y: int) -> None:
        start = QPoint(x + 24, y)
        end = QPoint(x, y)
        self.move(start)
        self.show()
        self.raise_()

        slide = QPropertyAnimation(self, b"pos")
        slide.setDuration(230)
        slide.setStartValue(start)
        slide.setEndValue(end)
        slide.setEasingCurve(QEasingCurve.Type.OutCubic)
        slide.start()
        self._slide = slide

        fade = QPropertyAnimation(self._opacity, b"opacity")
        fade.setDuration(210)
        fade.setStartValue(0.0)
        fade.setEndValue(1.0)
        fade.start()
        self._fade = fade

    def animate_out(self, done) -> None:
        fade = QPropertyAnimation(self._opacity, b"opacity")
        fade.setDuration(180)
        fade.setStartValue(self._opacity.opacity())
        fade.setEndValue(0.0)
        fade.finished.connect(done)
        fade.start()
        self._fade_out = fade


class _SeleniumEvaluateProxy:
    def __init__(self, driver: Any) -> None:
        self._driver = driver

    def evaluate(self, script: str) -> Any:
        return self._driver.execute_script(f"return ({script})();")


def install_message_notifications(window: Any, module: Any) -> None:
    if getattr(window, "_mx_message_notifications_installed", False):
        return
    window._mx_message_notifications_installed = True
    window._mx_msg_notice_module = module
    window._mx_msg_notice_seen = {}
    window._mx_msg_notice_scanning = False
    window._mx_msg_notice_stack = []
    window._mx_msg_notice_tray = _make_tray(window)

    bridge = _NotifyBridge(window)
    bridge.found.connect(lambda items: _on_notices(window, items))
    window._mx_msg_notice_bridge = bridge

    timer = QTimer(window)
    timer.setInterval(_POLL_INTERVAL_MS)
    timer.timeout.connect(lambda: _start_scan(window))
    timer.start()
    window._mx_msg_notice_timer = timer
    _log.info("message notifications installed: interval=%sms", _POLL_INTERVAL_MS)

    # Показываем актуальные непрочитанные сразу после запуска, чтобы уведомления
    # не выглядели "сломавшимися", если сообщение пришло до первого скана.
    QTimer.singleShot(2500, lambda: _start_scan(window, warmup=False))


def _make_tray(window: Any) -> QSystemTrayIcon | None:
    if not QSystemTrayIcon.isSystemTrayAvailable():
        return None
    try:
        icon = window.windowIcon()
        if icon.isNull():
            return None
        tray = QSystemTrayIcon(icon, window)
        tray.setToolTip("Maxitochka")
        tray.show()
        return tray
    except Exception:
        _log.debug("tray init failed", exc_info=True)
        return None


def _selected_active_drivers(window: Any) -> dict[str, Any]:
    active = dict(getattr(window, "active_drivers", {}) or {})
    if not active:
        active = _try_reconnect_open_max(window)
    checked = set(getattr(window, "_checker_checked", None) or ())
    if not checked:
        return active

    checked_norm = {_norm_session_name(x) for x in checked}
    selected = {
        name: drv
        for name, drv in active.items()
        if name in checked or _norm_session_name(name) in checked_norm
    }
    if selected:
        return selected
    if len(active) == 1:
        return active
    return {}


def _norm_session_name(value: Any) -> str:
    text = str(value or "").strip().casefold()
    if text.endswith(".txt"):
        text = text[:-4]
    return text


def _try_reconnect_open_max(window: Any) -> dict[str, Any]:
    now = time.time()
    last = float(getattr(window, "_mx_msg_notice_last_reconnect", 0.0) or 0.0)
    if now - last < 60:
        return dict(getattr(window, "active_drivers", {}) or {})
    window._mx_msg_notice_last_reconnect = now
    try:
        from browser_launcher import attach_over_cdp
        from session_registry import is_debug_port_alive, list_registered, port_for_registered

        active = dict(getattr(window, "active_drivers", {}) or {})
        attached = 0
        for fname, rec in list_registered().items():
            if fname in active:
                continue
            port = port_for_registered(rec)
            if not port or not is_debug_port_alive(port):
                continue
            driver = attach_over_cdp(port)
            if driver is None:
                continue
            active[fname] = driver
            attached += 1
        if attached:
            window.active_drivers = active
            _log.info("message reconnect: attached=%s active=%s", attached, len(active))
        else:
            _log.info("message reconnect: no live registered MAX")
        return active
    except Exception:
        _log.exception("message reconnect failed")
        return dict(getattr(window, "active_drivers", {}) or {})


def _start_scan(window: Any, *, warmup: bool = False) -> None:
    if getattr(window, "_mx_msg_notice_scanning", False):
        return
    selected = _selected_active_drivers(window)
    try:
        active_count = len(getattr(window, "active_drivers", {}) or {})
        checked_count = len(getattr(window, "_checker_checked", None) or ())
        state = (active_count, checked_count, len(selected), bool(warmup))
        now = time.time()
        prev_state = getattr(window, "_mx_msg_notice_last_scan_state", None)
        prev_log = float(getattr(window, "_mx_msg_notice_last_scan_log", 0.0) or 0.0)
        if state != prev_state or now - prev_log >= 60:
            window._mx_msg_notice_last_scan_state = state
            window._mx_msg_notice_last_scan_log = now
            _log.info(
                "message scan tick: active=%s checked=%s selected=%s warmup=%s",
                active_count,
                checked_count,
                len(selected),
                warmup,
            )
    except Exception:
        pass
    if not selected:
        return
    window._mx_msg_notice_scanning = True

    def worker() -> None:
        notices: list[dict[str, Any]] = []
        try:
            notices = _scan_selected(window, selected, warmup=warmup)
        except Exception:
            _log.exception("message notification scan failed")
        finally:
            try:
                bridge = getattr(window, "_mx_msg_notice_bridge", None)
                if bridge is not None:
                    bridge.found.emit(notices)
            except Exception:
                pass

    threading.Thread(target=worker, name="max-message-notify", daemon=True).start()


def _scan_selected(
    window: Any,
    selected: dict[str, Any],
    *,
    warmup: bool,
) -> list[dict[str, Any]]:
    seen: dict[str, dict[str, Any]] = getattr(window, "_mx_msg_notice_seen", {}) or {}
    notices: list[dict[str, Any]] = []
    now = time.time()

    for session_name, raw_driver in list(selected.items()):
        try:
            summaries = _read_unread_chat_summaries_for_driver(raw_driver)
            _log.info(
                "message scan session: %s unread_rows=%s",
                session_name,
                len(summaries),
            )
        except Exception:
            _log.exception("read unread failed: %s", session_name)
            continue
        for item in summaries:
            title = str(item.get("title") or "").strip()
            if not title or is_ui_chrome_title(title):
                continue
            unread = max(1, int(item.get("unread") or 0))
            preview = _clean_preview(item.get("preview") or "")
            key = f"{session_name}\u241f{title.casefold()}"
            prev = seen.get(key) or {}
            prev_unread = int(prev.get("unread") or 0)
            prev_preview = str(prev.get("preview") or "")
            seen[key] = {
                "unread": unread,
                "preview": preview,
                "ts": now,
            }
            if warmup:
                continue
            if unread > prev_unread or (unread > 0 and preview and preview != prev_preview):
                notices.append(
                    {
                        "session": session_name,
                        "title": title,
                        "preview": preview,
                        "unread": unread,
                    }
                )
                if len(notices) >= _MAX_NOTICES_PER_SCAN:
                    break
        if len(notices) >= _MAX_NOTICES_PER_SCAN:
            break

    # Не держим бесконечно старые ключи от закрытых/удалённых чатов.
    cutoff = now - 60 * 60 * 12
    for key, data in list(seen.items()):
        if float(data.get("ts") or 0) < cutoff:
            seen.pop(key, None)
    window._mx_msg_notice_seen = seen
    return notices


def _read_unread_chat_summaries_for_driver(raw_driver: Any) -> list[dict[str, Any]]:
    driver = resolve_driver(raw_driver)
    sess = getattr(driver, "_mx_playwright_session", None) if driver else None
    if sess is not None and is_session_alive(sess):
        return _read_unread_chat_summaries(sess.page)

    if raw_driver is None or not hasattr(raw_driver, "execute_script"):
        return []
    try:
        handles = getattr(raw_driver, "window_handles", None)
        if handles is not None and not list(handles):
            return []
    except Exception:
        return []
    return _read_unread_chat_summaries(_SeleniumEvaluateProxy(raw_driver))


def _read_unread_chat_summaries(page: Any) -> list[dict[str, Any]]:
    raw = page.evaluate(
        """() => {
          const visible = (el) => {
            if (!el || !el.isConnected) return false;
            const r = el.getBoundingClientRect();
            const st = getComputedStyle(el);
            return r.width > 24 && r.height > 18 && st.visibility !== 'hidden' && st.display !== 'none';
          };
          const skipTitle = /^(чаты|контакты|звонки|настройки|все|новые|каналы|избранное|архив|chats|contacts|calls|settings|all|new|channels|favorites|archive)(\\s+\\d+)?$/i;
          const timeRe = /^(\\d{1,2}:\\d{2}|\\d{1,2}\\s+[а-яё]{3,}\\.?|\\d{1,2}\\.\\d{1,2}\\.\\d{2,4})$/i;
          const numberRe = /^\\d{1,3}$/;
          const rows = [];
          const seen = new Set();
          const selectors = [
            'button[class*="cell"]',
            'button',
            '[class*="chat-list"] button',
            '[class*="ChatList"] button',
            '[class*="dialogs"] button',
            '[class*="Dialogs"] button',
            '[class*="dialog"] button',
            '[role="listitem"]',
            '[role="listitem"] button',
            '[class*="ChatItem"]',
            '[class*="sidebar"] [role="button"]'
          ].join(',');

          const collectUnread = (row, lines) => {
            let max = 0;
            const txt = ((row.innerText || '') + '\\n' + (row.getAttribute('aria-label') || '')).trim();
            if (/непроч|unread/i.test(txt)) {
              for (const m of txt.matchAll(/(?:непроч\\S*|unread)[^0-9]{0,16}(\\d{1,3})/gi)) {
                max = Math.max(max, Number(m[1] || 0));
              }
            }
            for (let i = 1; i < Math.min(lines.length, 5); i++) {
              const line = lines[i];
              if (numberRe.test(line)) {
                max = Math.max(max, Number(line));
              }
            }
            const rr = row.getBoundingClientRect();
            for (const el of row.querySelectorAll('*')) {
              if (!visible(el)) continue;
              const t = (el.innerText || el.textContent || '').trim();
              if (!numberRe.test(t)) continue;
              const n = Number(t);
              if (!n || n > 999) continue;
              const r = el.getBoundingClientRect();
              const nearRight = r.left > rr.left + rr.width * 0.55;
              const cls = String(el.className || '');
              const badgeName = /badge|counter|unread|notification|count/i.test(cls);
              const badgeLike = r.width <= 48 && r.height <= 38;
              if ((nearRight && badgeLike) || badgeName) max = Math.max(max, n);
            }
            return max;
          };

          const isMuted = (row) => {
            const parts = [
              row.getAttribute('aria-label') || '',
              row.getAttribute('title') || '',
              row.innerText || '',
              String(row.className || '')
            ];
            for (const el of row.querySelectorAll('[aria-label],[title],use,svg,[class]')) {
              parts.push(el.getAttribute('aria-label') || '');
              parts.push(el.getAttribute('title') || '');
              parts.push(String(el.className || ''));
              parts.push(el.getAttribute('href') || '');
              parts.push(el.getAttribute('xlink:href') || '');
            }
            const all = parts.join(' ').toLowerCase();
            return /уведомления\\s+отключены|notifications?\\s*(off|muted|disabled)|\\bmute\\b|\\bmuted\\b|iconmute|notifications_crossed|notification_crossed|🔕/.test(all);
          };

          const addRow = (row) => {
            if (!visible(row)) return;
            const rect = row.getBoundingClientRect();
            if (rect.width < 140 || rect.height < 34 || rect.height > 170) return;
            const text = (row.innerText || '').trim();
            if (!text || seen.has(text)) return;
            if (isMuted(row)) return;
            const lines = text.split('\\n').map(s => s.trim()).filter(Boolean);
            if (!lines.length) return;
            const title = lines.find(s => s.length >= 2 && s.length <= 120 && !skipTitle.test(s) && !timeRe.test(s) && !numberRe.test(s));
            if (!title) return;
            const unread = collectUnread(row, lines);
            if (unread <= 0) return;
            let preview = '';
            for (let i = 0; i < lines.length; i++) {
              const line = lines[i];
              if (line === title || skipTitle.test(line) || timeRe.test(line) || numberRe.test(line)) continue;
              if (line === ':' && i + 1 < lines.length) {
                preview = lines[i + 1];
                break;
              }
              if (i + 1 < lines.length && lines[i + 1].startsWith(':')) {
                preview = `${line}${lines[i + 1]}`;
                if (i + 2 < lines.length && !timeRe.test(lines[i + 2]) && !numberRe.test(lines[i + 2])) {
                  preview = `${preview} ${lines[i + 2]}`;
                }
                break;
              }
              preview = line;
              break;
            }
            seen.add(text);
            rows.push({ title, preview, unread });
          };

          for (const row of document.querySelectorAll(selectors)) addRow(row);
          return rows.slice(0, 25);
        }"""
    )
    if not isinstance(raw, list):
        return []
    return [x for x in raw if isinstance(x, dict)]


_CLICK_CHAT_SCRIPT = r"""
const target = String(arguments[0] || '').trim();
const norm = (s) => String(s || '').replace(/\s+/g, ' ').trim().toLowerCase();
const wanted = norm(target);
if (!wanted) return false;

const visible = (el) => {
  if (!el || !el.isConnected) return false;
  const r = el.getBoundingClientRect();
  const st = getComputedStyle(el);
  return r.width > 24 && r.height > 18 && st.visibility !== 'hidden' && st.display !== 'none';
};
const skipTitle = /^(чаты|контакты|звонки|настройки|все|новые|каналы|избранное|архив|chats|contacts|calls|settings|all|new|channels|favorites|archive)(\s+\d+)?$/i;
const timeRe = /^(\d{1,2}:\d{2}|\d{1,2}\s+[а-яё]{3,}\.?|\d{1,2}\.\d{1,2}\.\d{2,4})$/i;
const numberRe = /^\d{1,3}$/;
const titleOf = (row) => {
  const node = row.querySelector('h3 .text, h3, [class*="title"] [class*="text"], [class*="name"] [class*="text"]');
  const direct = node ? (node.innerText || node.textContent || '').trim() : '';
  if (direct) return direct;
  const lines = (row.innerText || '').split('\n').map(s => s.trim()).filter(Boolean);
  return lines.find(s => s.length >= 2 && s.length <= 120 && !skipTitle.test(s) && !timeRe.test(s) && !numberRe.test(s)) || '';
};
const selectors = [
  'button[class*="cell"]',
  'button',
  '[class*="chat-list"] button',
  '[class*="ChatList"] button',
  '[class*="dialogs"] button',
  '[class*="Dialogs"] button',
  '[class*="dialog"] button',
  '[role="listitem"]',
  '[role="listitem"] button',
  '[class*="ChatItem"]',
  '[class*="sidebar"] [role="button"]'
].join(',');
for (const row of document.querySelectorAll(selectors)) {
  if (!visible(row)) continue;
  const rowTitle = norm(titleOf(row));
  if (!rowTitle) continue;
  if (rowTitle === wanted || rowTitle.includes(wanted) || wanted.includes(rowTitle)) {
    row.scrollIntoView({ block: 'center', inline: 'nearest' });
    row.dispatchEvent(new MouseEvent('mouseover', { bubbles: true, cancelable: true, view: window }));
    row.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
    row.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window }));
    row.click();
    return true;
  }
}
return false;
"""


def _driver_for_notice(window: Any, session_name: str) -> Any | None:
    active = dict(getattr(window, "active_drivers", {}) or {})
    norm = _norm_session_name(session_name)
    for name, driver in active.items():
        if name == session_name or _norm_session_name(name) == norm:
            return driver

    active = _try_reconnect_open_max(window)
    for name, driver in active.items():
        if name == session_name or _norm_session_name(name) == norm:
            return driver
    if len(active) == 1:
        return next(iter(active.values()))
    return None


def _focus_notice_session(window: Any, session_name: str) -> None:
    try:
        focus = getattr(window, "focus_browser_window", None)
        if callable(focus):
            focus(session_name)
            return
    except Exception:
        _log.debug("focus_browser_window failed: %s", session_name, exc_info=True)


def _click_chat_for_driver(raw_driver: Any, title: str) -> bool:
    driver = resolve_driver(raw_driver)
    sess = getattr(driver, "_mx_playwright_session", None) if driver else None
    if sess is not None and is_session_alive(sess):
        try:
            sess.page.bring_to_front()
        except Exception:
            pass
        return bool(sess.page.evaluate(f"(title) => {{ {_CLICK_CHAT_SCRIPT.replace('arguments[0]', 'title')} }}", title))

    if raw_driver is None or not hasattr(raw_driver, "execute_script"):
        return False
    try:
        try:
            raw_driver.switch_to.window(raw_driver.current_window_handle)
        except Exception:
            pass
        try:
            raw_driver.execute_script("window.focus();")
        except Exception:
            pass
        return bool(raw_driver.execute_script("return (function(){ " + _CLICK_CHAT_SCRIPT + " }).apply(null, arguments);", title))
    except Exception:
        _log.debug("click MAX chat failed: %s", title, exc_info=True)
        return False


def _activate_notice_target(window: Any, item: dict[str, Any]) -> None:
    session = str(item.get("session") or "").strip()
    title = str(item.get("title") or "").strip()
    if session:
        _focus_notice_session(window, session)

    def worker() -> None:
        time.sleep(0.2)
        driver = _driver_for_notice(window, session)
        if driver is None or not title:
            return
        clicked = _click_chat_for_driver(driver, title)
        _log.info("message notification click: session=%s title=%s clicked=%s", session, title, clicked)

    threading.Thread(target=worker, name="max-message-notice-click", daemon=True).start()


def _clean_preview(value: Any) -> str:
    text = re.sub(r"\s+", " ", str(value or "")).strip()
    if len(text) > 130:
        text = text[:127].rstrip() + "..."
    return text


def _on_notices(window: Any, items: Any) -> None:
    window._mx_msg_notice_scanning = False
    notices = [x for x in (items or []) if isinstance(x, dict)]
    if not notices:
        return
    _log.info("message notifications found: %s", len(notices))
    for item in notices[:_MAX_NOTICES_PER_SCAN]:
        _show_notice(window, item)


def _show_notice(window: Any, item: dict[str, Any]) -> None:
    session = str(item.get("session") or "MAX")
    title = str(item.get("title") or "Новое сообщение")
    preview = _clean_preview(item.get("preview") or "")
    unread = int(item.get("unread") or 1)
    body = preview or f"Непрочитанных: {unread}"

    tray = getattr(window, "_mx_msg_notice_tray", None)
    if tray is not None:
        try:
            tray.showMessage(
                f"MAX: {session}",
                f"{title}\n{body}",
                QSystemTrayIcon.MessageIcon.Information,
                _NOTICE_DURATION_MS,
            )
        except Exception:
            _log.debug("tray showMessage failed", exc_info=True)

    try:
        _show_desktop_popup(window, f"MAX: {session}", f"{title}\n{body}", item)
    except Exception:
        _log.exception("desktop notification popup failed")
    try:
        if hasattr(window, "signals"):
            window.signals.notify.emit(f"MAX: {session}\n{title}: {body}", ACCENT)
    except Exception:
        pass


def _screen_rect() -> QRect:
    try:
        screen = QGuiApplication.screenAt(QCursor.pos())
    except Exception:
        screen = None
    if screen is None:
        screen = QGuiApplication.primaryScreen()
    return screen.availableGeometry() if screen is not None else QRect(0, 0, 1280, 720)


def _show_desktop_popup(
    window: Any,
    title: str,
    body: str,
    item: dict[str, Any] | None = None,
) -> None:
    stack: list = getattr(window, "_mx_msg_notice_stack", None)
    if stack is None:
        stack = []
        window._mx_msg_notice_stack = stack
    stack[:] = [n for n in stack if n is not None]

    holder: dict[str, _DesktopNotice] = {}

    def _clicked() -> None:
        if item:
            _activate_notice_target(window, item)
        notice = holder.get("notice")
        if notice is not None:
            _dismiss_notice(stack, notice)

    notice = _DesktopNotice(title, body, on_click=_clicked if item else None)
    holder["notice"] = notice
    notice.adjustSize()
    stack.append(notice)
    _relayout_stack(stack)

    def _remove() -> None:
        _dismiss_notice(stack, notice)

    QTimer.singleShot(_NOTICE_DURATION_MS, _remove)


def _dismiss_notice(stack: list[_DesktopNotice], notice: _DesktopNotice) -> None:
    if notice not in stack:
        return

    def done() -> None:
        if notice in stack:
            stack.remove(notice)
        notice.deleteLater()
        _relayout_stack(stack)

    notice.animate_out(done)


def _relayout_stack(stack: list[_DesktopNotice]) -> None:
    rect = _screen_rect()
    y = rect.bottom() - _NOTICE_MARGIN
    for notice in stack:
        lay = notice.layout()
        if lay is not None:
            lay.activate()
        notice.adjustSize()
        h = max(notice.sizeHint().height(), notice.minimumSizeHint().height(), notice.height(), 72)
        y -= h
        x = rect.right() - _NOTICE_W - _NOTICE_MARGIN
        if notice.isVisible():
            notice.move(x, y)
        else:
            notice.animate_in(x, y)
        notice.raise_()
        y -= _NOTICE_GAP
