$ErrorActionPreference = 'Stop'

try {
    [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
    [Console]::InputEncoding = [System.Text.Encoding]::UTF8
}
catch {
}

$root = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
$envPath = Join-Path $root '.env'

Write-Host ''
Write-Host 'Gus AI setup'
Write-Host 'The key will be saved only to local file: .env'
Write-Host ''

$secureKey = Read-Host 'Paste OpenAI API key' -AsSecureString
$bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureKey)
try {
    $apiKey = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
}
finally {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
}

$apiKey = ([string]$apiKey).Trim()
if ([string]::IsNullOrWhiteSpace($apiKey)) {
    throw 'API key is empty. Setup canceled.'
}

$model = Read-Host 'Model (Enter = gpt-4.1-mini)'
if ([string]::IsNullOrWhiteSpace($model)) {
    $model = 'gpt-4.1-mini'
}

$lines = New-Object System.Collections.Generic.List[string]
if (Test-Path -LiteralPath $envPath -PathType Leaf) {
    foreach ($line in @(Get-Content -LiteralPath $envPath -Encoding UTF8)) {
        $trimmed = ([string]$line).Trim()
        if ($trimmed -match '^(OPENAI_API_KEY|OPENAI_MODEL)\s*=') { continue }
        [void]$lines.Add([string]$line)
    }
}
[void]$lines.Add("OPENAI_API_KEY=$apiKey")
[void]$lines.Add("OPENAI_MODEL=$($model.Trim())")
Set-Content -LiteralPath $envPath -Value ([string[]]$lines.ToArray()) -Encoding UTF8

Write-Host ''
Write-Host "Done. Env file updated: $envPath"
Write-Host 'Restart Gus and press AI: start.'
