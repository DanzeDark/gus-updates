@echo off
chcp 65001 >nul
setlocal

set "SCRIPT=%~dp0Install-MaxContactTool.ps1"
if not exist "%SCRIPT%" (
    start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command "Add-Type -AssemblyName System.Windows.Forms;[System.Windows.Forms.MessageBox]::Show(('Installer script not found:'+[Environment]::NewLine+$env:SCRIPT),'Gus setup','OK','Error')|Out-Null"
    exit /b 1
)

start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%SCRIPT%" -SourceRoot "%~dp0"
exit /b 0
