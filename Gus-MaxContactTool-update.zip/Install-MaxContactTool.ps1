﻿param(
    [string]$SourceRoot = $PSScriptRoot
)

$ErrorActionPreference = 'Stop'

function Copy-InstallerItem {
    param(
        [string]$SourceRoot,
        [string]$DestinationRoot,
        [string]$RelativePath
    )

    $source = Join-Path $SourceRoot $RelativePath
    if (-not (Test-Path -LiteralPath $source)) { return }

    $target = Join-Path $DestinationRoot $RelativePath
    $targetParent = Split-Path -Parent $target
    if (-not (Test-Path -LiteralPath $targetParent)) {
        New-Item -ItemType Directory -Path $targetParent -Force | Out-Null
    }

    Copy-Item -LiteralPath $source -Destination $target -Recurse -Force
}

function New-GooseShortcut {
    param(
        [string]$InstallPath,
        [string]$DesktopPath
    )

    $exe = Join-Path $InstallPath 'Gus-MaxContactTool.exe'
    $target = if (Test-Path -LiteralPath $exe -PathType Leaf) { $exe } else { Join-Path $InstallPath 'Run-MaxContactTool.vbs' }
    $shortcutPath = Join-Path $DesktopPath 'Гусь.lnk'
    $wsh = New-Object -ComObject WScript.Shell
    $shortcut = $wsh.CreateShortcut($shortcutPath)
    $shortcut.TargetPath = $target
    $shortcut.WorkingDirectory = $InstallPath
    $shortcut.Description = 'Гусь'
    $shortcut.WindowStyle = 1

    $icon = Join-Path $InstallPath 'assets\goose.ico'
    if (Test-Path -LiteralPath $icon -PathType Leaf) {
        $shortcut.IconLocation = $icon
    }
    elseif (Test-Path -LiteralPath $exe -PathType Leaf) {
        $shortcut.IconLocation = $exe
    }

    $shortcut.Save()
    return $shortcutPath
}

function Backup-LocalFiles {
    param(
        [string[]]$SourceRoots,
        [string]$BackupRoot
    )

    foreach ($sourceRoot in @($SourceRoots)) {
        if ([string]::IsNullOrWhiteSpace($sourceRoot) -or -not (Test-Path -LiteralPath $sourceRoot -PathType Container)) { continue }
        foreach ($name in @('max_contact_state.json','max_contact_replies.json','update_source.txt','update_channel.txt','gus_auth.json')) {
            $source = Join-Path $sourceRoot $name
            $target = Join-Path $BackupRoot $name
            if ((Test-Path -LiteralPath $source -PathType Leaf) -and -not (Test-Path -LiteralPath $target)) {
                Copy-Item -LiteralPath $source -Destination $target -Force
            }
        }
    }
}

function Restore-LocalFiles {
    param(
        [string]$BackupRoot,
        [string]$InstallPath
    )

    foreach ($name in @('max_contact_state.json','max_contact_replies.json','gus_auth.json')) {
        $source = Join-Path $BackupRoot $name
        if (Test-Path -LiteralPath $source -PathType Leaf) {
            Copy-Item -LiteralPath $source -Destination (Join-Path $InstallPath $name) -Force
        }
    }

    foreach ($name in @('update_source.txt','update_channel.txt')) {
        $source = Join-Path $BackupRoot $name
        $target = Join-Path $InstallPath $name
        if ((-not (Test-Path -LiteralPath $target -PathType Leaf)) -and (Test-Path -LiteralPath $source -PathType Leaf)) {
            Copy-Item -LiteralPath $source -Destination $target -Force
        }
    }
}

$src = [IO.Path]::GetFullPath($SourceRoot)
$desktop = [Environment]::GetFolderPath('Desktop')
$defaultBase = Join-Path $env:LOCALAPPDATA 'Programs'
$defaultDst = Join-Path $defaultBase 'Gus-MaxContactTool'
New-Item -ItemType Directory -Path $defaultDst -Force | Out-Null

Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.Application]::EnableVisualStyles()

$dialog = New-Object System.Windows.Forms.FolderBrowserDialog
$dialog.Description = 'Выбери папку, куда установить программу Гусь'
$dialog.ShowNewFolderButton = $true
$dialog.SelectedPath = $defaultDst
$dialog.RootFolder = [System.Environment+SpecialFolder]::Desktop
if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
    throw 'Установка отменена.'
}

$dst = [IO.Path]::GetFullPath($dialog.SelectedPath)
if ([string]::IsNullOrWhiteSpace($dst)) {
    throw 'Папка установки не выбрана.'
}
New-Item -ItemType Directory -Path $dst -Force | Out-Null

$backup = Join-Path $env:TEMP ('GusInstallBackup_' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $backup -Force | Out-Null

try {
    $legacyDst = Join-Path $desktop 'MaxContactTool'
    Backup-LocalFiles -SourceRoots @($dst, $legacyDst) -BackupRoot $backup

    if (-not ([IO.Path]::GetFullPath($src).TrimEnd('\') -ieq [IO.Path]::GetFullPath($dst).TrimEnd('\'))) {
        foreach ($relative in @(
            'Gus-MaxContactTool.exe',
            'Install-MaxContactTool.bat',
            'Install-MaxContactTool.ps1',
            'MaxContactTool.ps1',
            'Run-MaxContactTool.bat',
            'Run-MaxContactTool.vbs',
            'gus_update.json',
            'gus_accounts.json',
            'VERSION.txt',
            'update_source.txt',
            'update_channel.txt',
            'max_contact_replies.json',
            'README.md',
            'sample_contacts.txt',
            'sample_messages.txt',
            'type_text_ahk_v1.ahk',
            'type_text_ahk_v2.ahk',
            'Гусь.bat',
            'Гусь.vbs',
            'assets',
            'Maxitochka'
        )) {
            Copy-InstallerItem -SourceRoot $src -DestinationRoot $dst -RelativePath $relative
        }
    }

    Restore-LocalFiles -BackupRoot $backup -InstallPath $dst

    $shortcutPath = New-GooseShortcut -InstallPath $dst -DesktopPath $desktop
    foreach ($oldShortcut in @(
        (Join-Path $desktop 'Gus-MaxContactTool.bat'),
        (Join-Path $desktop 'Maxitochka.bat')
    )) {
        if (Test-Path -LiteralPath $oldShortcut) {
            Remove-Item -LiteralPath $oldShortcut -Force -ErrorAction SilentlyContinue
        }
    }

    try { Get-ChildItem -LiteralPath $dst -Recurse -Force | Unblock-File -ErrorAction SilentlyContinue } catch {}

    Write-Host ''
    Write-Host ('Installed to: ' + $dst)
    Write-Host ('Shortcut: ' + $shortcutPath)
    Write-Host ''
    [System.Windows.Forms.MessageBox]::Show("Гусь установлен.`n`nПапка: $dst`nЯрлык: $shortcutPath", 'Гусь', 'OK', 'Information') | Out-Null
}
finally {
    Remove-Item -LiteralPath $backup -Recurse -Force -ErrorAction SilentlyContinue
}
