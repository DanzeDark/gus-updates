@echo off
set "SCRIPT_DIR=%~dp0"
wscript.exe "%SCRIPT_DIR%Гусь.vbs"
