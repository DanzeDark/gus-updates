﻿param([switch]$NoGui)

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

if (-not ('MaxContactWin32' -as [type])) {
    Add-Type @"
using System;
using System.Runtime.InteropServices;

public static class MaxContactWin32 {
    [DllImport("user32.dll")]
    public static extern bool SetForegroundWindow(IntPtr hWnd);

    [DllImport("user32.dll")]
    public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);

    [DllImport("user32.dll")]
    public static extern bool IsIconic(IntPtr hWnd);

    [DllImport("user32.dll")]
    public static extern IntPtr GetForegroundWindow();

    [DllImport("user32.dll", SetLastError=true, CharSet=CharSet.Unicode)]
    public static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

    [DllImport("user32.dll")]
    public static extern bool ReleaseCapture();

    [DllImport("user32.dll")]
    public static extern IntPtr SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

    [DllImport("user32.dll", SetLastError=true)]
    public static extern bool DestroyIcon(IntPtr hIcon);

    [DllImport("dwmapi.dll")]
    public static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int attrValue, int attrSize);
}
"@
}

[System.Windows.Forms.Application]::EnableVisualStyles()

$script:AppTitle = 'Гусь'
$script:AppVersion = '1.9.7'
$script:UpdateManifestFileName = 'gus_update.json'
$script:UpdatePackageFileName = 'Gus-MaxContactTool-update.zip'
$script:UpdateSourceFileName = 'update_source.txt'
$script:UpdateChannelFileName = 'update_channel.txt'
$script:UpdateAdminMarkerFileName = 'main_pc_update_admin.txt'
$script:DefaultWebUpdateUrl = 'https://danzedark.github.io/gus-updates/'
$script:AppMutex = $null
if (-not $NoGui) {
    $createdNew = $false
    $script:AppMutex = New-Object System.Threading.Mutex($true, 'Local\GusContactToolSingleInstance', [ref]$createdNew)
    if (-not $createdNew) {
        $foundExistingWindow = $false
        foreach ($windowTitle in @($script:AppTitle, 'MAX Contact Tool')) {
            $existingWindow = [MaxContactWin32]::FindWindow($null, $windowTitle)
            if ($existingWindow -ne [IntPtr]::Zero) {
                [MaxContactWin32]::ShowWindowAsync($existingWindow, 9) | Out-Null
                [MaxContactWin32]::SetForegroundWindow($existingWindow) | Out-Null
                $foundExistingWindow = $true
                break
            }
        }
        try { $script:AppMutex.Dispose() } catch {}
        $script:AppMutex = $null
        if ($foundExistingWindow) {
            return
        }
    }
}

$script:Contacts = New-Object System.Collections.Generic.List[object]
$script:LastFilePath = $null
$script:MaxitochkaSessions = New-Object System.Collections.Generic.List[object]
$script:AppRoot = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
$script:StatePath = Join-Path $script:AppRoot 'max_contact_state.json'
$script:LastSavedStateJson = $null
$script:RepliesPath = Join-Path $script:AppRoot 'max_contact_replies.json'
$script:ReplyRecords = New-Object System.Collections.Generic.List[object]
$script:RepliesWindow = $null
$script:RepliesWindowGrid = $null
$script:RepliesWindowStatusLabel = $null
$script:RepliesWindowTimer = $null
$script:RepliesAutoCheckBusy = $false
$script:RepliesAutoCheckCursor = 0
$script:RepliesLastAutoCheckAt = [DateTime]::MinValue
$script:RepliesLastVisibleScanAt = [DateTime]::MinValue
$script:RepliesLastVisibleScanStats = $null
$script:ReplyRecordsLoaded = $false
$script:AnswerWindowRequestTimer = $null
$script:AnswerWindowLastIdleScanAt = [DateTime]::MinValue
$script:MaxitochkaDevToolsBusy = $false
$script:SavedContactFilePath = $null
$script:OneByOneNextIndex = 0
$script:OneByOneCancelRequested = $false
$script:OneByOneRunning = $false
$script:OneByOneStopSignal = [hashtable]::Synchronized(@{ Requested = $false; Paused = $false; Close = $false; ScanRequested = $false; OpenRecordId = ""; WindowStatus = ""; CurrentIndex = 0; TotalCount = 0; CurrentContact = ""; CurrentProfile = ""; HistoryText = ""; NotificationsEnabled = $true })
$script:OneByOneStatusLog = New-Object System.Collections.Generic.List[string]
$script:OneByOneRecentMaxMessages = New-Object System.Collections.Generic.List[object]
$script:OneByOneRecentMaxMessageKeys = @{}
$script:OneByOneNotificationBaselineKeys = @{}
$script:OneByOneNotificationBaselineProfiles = @{}
$script:OneByOneLastMaxMessageScanAt = [DateTime]::MinValue
$script:OneByOneNotificationScanCursor = 0
$script:OneByOneNotificationScanIntervalSeconds = 2
$script:OneByOneNotificationFullScanSeconds = 4
$script:OneByOneVisibleMaxMessageCount = 5
$script:OneByOneStopPowerShell = $null
$script:OneByOneStopRunspace = $null
$script:OneByOneStopAsync = $null
$script:NotificationWindowEnabled = $true
$script:MessageTemplates = New-Object System.Collections.Generic.List[string]
$script:MessageTemplatesPath = $null
$script:MessageTemplateIndex = 0
$script:LastActivatedMaxWindowHandle = [IntPtr]::Zero
$script:LastActivatedMaxSessionProfile = ""
$script:UiTheme = 'Карбон'
$script:AppOpacityPercent = 94
$script:LowPerformanceMode = $false
$script:ActivateMaxWindow = $true
$script:SwitchDelayMs = 900
$script:PersonDelaySeconds = 45
$script:PeoplePerMax = 1
$script:DelayedStartEnabled = $false
$script:DelayedStartTime = '23:00'
$script:DelayedStartAt = ''
$script:DelayedStartLastRunDate = ''
$script:DelayedStartTimer = $null
$script:GroupNameExtrasText = ""
$script:GroupNameExtras = New-Object System.Collections.Generic.List[string]
$script:UseGroupNameExtras = $true
$script:UseAhkTyping = $false
$script:AhkExePath = ""
$script:WallpaperPath = ""
$script:MaxitochkaRootPath = ""
$script:UpdateSourcePath = ""
$script:WallpaperImage = $null
$script:AppIcon = $null
$script:AppTitleImage = $null
$script:GoosePhrasePopup = $null
$script:GoosePhrasePopupTimer = $null
$script:GooseLoadingForm = $null
$script:GooseLoadingPanel = $null
$script:GooseLoadingLabel = $null
$script:GooseLoadingTimer = $null
$script:GooseLoadingFrame = 0
$script:GoosePhraseQueue = New-Object System.Collections.Generic.List[string]
$script:GooseSoundPath = 'C:\Users\Лепа\Downloads\utka.mp3'
$script:GooseSoundVolume = 50
$script:GooseSoundPlayer = $null
$script:GooseSoundStream = $null
$script:GoosePhrases = @(
    'Кузя, работай красиво',
    'Актер иди работай',
    'Паша где База?',
    'Егор где перезвончики?',
    'Да ёбаный сука штора, блять.',
    'Гусь на связи'
)
$script:UpdateHistory = @(
    [pscustomobject]@{
        Version = '1.9.7'
        Date = '2026-06-11'
        Title = 'Удаление пустых групп MAX'
        Changes = @(
            'Исправлено подтверждение выхода из пустой группы MAX: программа нажимает финальную кнопку Выйти.',
            'Если пустую группу не удалось удалить, обработка останавливается и не переходит на следующий MAX.'
        )
    },
    [pscustomobject]@{
        Version = '1.9.6'
        Date = '2026-06-11'
        Title = 'Живой список сообщений MAX'
        Changes = @(
            'Окно управления теперь показывает последние 5 сообщений MAX одной строкой.',
            'Новые сообщения отображаются сверху, старые опускаются ниже и вытесняются.',
            'Проверка уведомлений MAX стала чаще, чтобы ответы появлялись в окне быстрее.'
        )
    },
    [pscustomobject]@{
        Version = '1.9.5'
        Date = '2026-06-11'
        Title = 'Темы и пропись на MAX'
        Changes = @(
            'Убран дубликат кнопки Обновить из нижнего блока настроек.',
            'Для темы Радуга добавлена радужная иконка гуся.',
            'Добавлена серо-черная тема COURAGE с фоном COURAGE.',
            'Исправлена настройка Пропись на MAX: больше лимит, автосохранение и точнее распределение при пропусках.'
        )
    },
    [pscustomobject]@{
        Version = '1.8'
        Date = '2026-06-11'
        Title = 'Исправление чтения обновлений'
        Changes = @(
            'Исправлено чтение gus_update.json с GitHub Pages в Windows PowerShell.',
            'Manifest теперь корректно читается, даже если сервер вернул JSON как текст.',
            'Файлы обновления собираются без BOM, чтобы старые версии тоже могли обновиться.'
        )
    },
    [pscustomobject]@{
        Version = '1.7'
        Date = '2026-06-11'
        Title = 'Радужная тема'
        Changes = @(
            'Добавлена новая тема оформления Радуга.',
            'У темы есть цветные акценты и отдельный радужный фон.',
            'Обновление собрано для проверки канала GitHub Pages.'
        )
    },
    [pscustomobject]@{
        Version = '1.6'
        Date = '2026-06-10'
        Title = 'Готовый сайт обновлений'
        Changes = @(
            'Папка сайта обновлений теперь содержит главную страницу, чтобы сайт не показывал 404.',
            'Для сайта автоматически готовятся gus_update.json, zip-пакет, VERSION.txt и прямые ссылки.',
            'В программу вшит канал обновлений https://danzedark.github.io/gus-updates/.'
        )
    },
    [pscustomobject]@{
        Version = '1.5'
        Date = '2026-06-10'
        Title = 'Обновления через сайт'
        Changes = @(
            'Добавлена подготовка обновления для сайта.',
            'Канал обновлений теперь может быть ссылкой https://.',
            'Рабочие ПК скачивают manifest и zip с сайта по кнопке Обновить.'
        )
    },
    [pscustomobject]@{
        Version = '1.4'
        Date = '2026-06-10'
        Title = 'Скрыт главный режим на рабочих ПК'
        Changes = @(
            'Поле Канал обновлений скрыто на рабочих компьютерах.',
            'Кнопки Выбрать, Сохранить и Опубликовать видны только на главном ПК.',
            'Главный режим включается локальным файлом main_pc_update_admin.txt.'
        )
    },
    [pscustomobject]@{
        Version = '1.3'
        Date = '2026-06-10'
        Title = 'Главный ПК и рабочие ПК'
        Changes = @(
            'Добавлен канал обновлений для рабочих компьютеров.',
            'Добавлена публикация обновления с главного ПК.',
            'Если версия уже актуальная, программа больше не предлагает переустановку.'
        )
    },
    [pscustomobject]@{
        Version = '1.2'
        Date = '2026-06-10'
        Title = 'Вкладка обновлений'
        Changes = @(
            'Добавлена отдельная вкладка Обновления.',
            'Добавлен список последних версий и изменений.',
            'Кнопка Обновить продублирована во вкладке обновлений.'
        )
    },
    [pscustomobject]@{
        Version = '1.1'
        Date = '2026-06-10'
        Title = 'Автообновление'
        Changes = @(
            'Улучшен поиск источника обновлений.',
            'Добавлена диагностика, если manifest обновления не найден.',
            'Установщик записывает несколько источников обновления.'
        )
    },
    [pscustomobject]@{
        Version = '1.0'
        Date = '2026-06-10'
        Title = 'Первая подписанная версия'
        Changes = @(
            'Добавлена версия программы.',
            'Добавлена кнопка Обновить.',
            'Собран полный установщик и отдельный пакет обновления.'
        )
    }
)

function Normalize-Phone {
    param([string]$Phone)

    if ([string]::IsNullOrWhiteSpace($Phone)) { return "" }
    $digits = ($Phone -replace '\D', '')
    if ($digits.Length -eq 10) {
        $digits = '7' + $digits
    }
    if ($digits.Length -eq 11 -and $digits.StartsWith('8')) {
        $digits = '7' + $digits.Substring(1)
    }
    if ($digits.Length -ge 10) {
        return '+' + $digits
    }
    return $Phone.Trim()
}

function Get-ContactReplyKey {
    param($Contact)

    if ($null -eq $Contact) { return "" }

    $phone = ""
    try { $phone = Normalize-Phone ([string]$Contact.Phone) } catch { $phone = "" }
    $digits = ($phone -replace '\D', '')
    if ($digits.Length -ge 10) {
        return "phone:$digits"
    }

    $name = ""
    try { $name = [string]$Contact.FullName } catch { $name = "" }
    $name = ($name.Trim().ToLowerInvariant() -replace '\s+', ' ')
    if (-not [string]::IsNullOrWhiteSpace($name)) {
        return "name:$name"
    }

    return ""
}

function Convert-Date {
    param([string]$Value)

    if ([string]::IsNullOrWhiteSpace($Value)) { return "" }
    $formats = @('dd.MM.yyyy', 'd.M.yyyy', 'yyyy-MM-dd', 'dd/MM/yyyy', 'd/M/yyyy')
    $culture = [System.Globalization.CultureInfo]::InvariantCulture
    $styles = [System.Globalization.DateTimeStyles]::None
    $result = [DateTime]::MinValue

    foreach ($format in $formats) {
        if ([DateTime]::TryParseExact($Value.Trim(), $format, $culture, $styles, [ref]$result)) {
            return $result.ToString('yyyy-MM-dd')
        }
    }

    return $Value.Trim()
}

function Escape-VCard {
    param([string]$Value)

    if ($null -eq $Value) { return "" }
    return ($Value -replace '\\', '\\' -replace ';', '\;' -replace ',', '\,' -replace "`r?`n", '\n').Trim()
}

function Split-Name {
    param([string]$FullName)

    $parts = @($FullName.Trim() -split '\s+' | Where-Object { $_ })
    $last = if ($parts.Count -ge 1) { $parts[0] } else { "" }
    $first = if ($parts.Count -ge 2) { $parts[1] } else { "" }
    $middle = if ($parts.Count -ge 3) { ($parts[2..($parts.Count - 1)] -join ' ') } else { "" }
    return @($last, $first, $middle)
}

function Apply-Template {
    param(
        [string]$Template,
        $Contact,
        [string]$GroupName
    )

    $text = $Template
    $text = $text.Replace('{fio}', [string]$Contact.FullName)
    $text = $text.Replace('{phone}', [string]$Contact.Phone)
    $text = $text.Replace('{birthdate}', [string]$Contact.BirthDate)
    $text = $text.Replace('{group}', [string]$GroupName)
    return $text
}

function Parse-MessageTemplatesFile {
    param([string]$Path)

    $raw = Get-Content -Raw -Encoding UTF8 -LiteralPath $Path
    $normalized = ($raw -replace "`r`n", "`n") -replace "`r", "`n"
    $parts = [regex]::Split($normalized, '(?m)^\s*-{3,}\s*$')

    if (@($parts).Count -le 1) {
        $parts = [regex]::Split($normalized.Trim(), "(?m)`n\s*`n+")
    }

    $templates = New-Object System.Collections.Generic.List[string]
    foreach ($part in $parts) {
        $text = ([string]$part).Trim()
        if (-not [string]::IsNullOrWhiteSpace($text)) {
            $templates.Add($text)
        }
    }

    return @($templates)
}

function Set-GroupNameExtrasFromText {
    param([string]$Text)

    $script:GroupNameExtrasText = [string]$Text
    $script:GroupNameExtras.Clear()
    $lines = ([string]$Text -replace "`r`n", "`n" -replace "`r", "`n") -split "`n"
    foreach ($line in $lines) {
        $name = ([string]$line).Trim()
        if (-not [string]::IsNullOrWhiteSpace($name)) {
            $script:GroupNameExtras.Add($name)
        }
    }
}

function Load-MessageTemplatesFromPath {
    param([string]$Path)

    $templates = @(Parse-MessageTemplatesFile $Path)
    if ($templates.Count -eq 0) {
        throw 'В файле не найдено ни одного текста.'
    }

    $script:MessageTemplates.Clear()
    foreach ($template in $templates) {
        $script:MessageTemplates.Add([string]$template)
    }
    $script:MessageTemplatesPath = $Path
    $script:MessageTemplateIndex = 0
    if ($messageBox) {
        $messageBox.Text = [string]$script:MessageTemplates[0]
    }
    if ($messageTemplatesPathBox) {
        $messageTemplatesPathBox.Text = $Path
    }
    Save-ProcessingState
    Refresh-MessageTemplatesStatus
}

function Clear-MessageTemplates {
    $script:MessageTemplates.Clear()
    $script:MessageTemplatesPath = $null
    $script:MessageTemplateIndex = 0
    if ($messageTemplatesPathBox) {
        $messageTemplatesPathBox.Text = ''
    }
    Save-ProcessingState
    Refresh-MessageTemplatesStatus
}

function Normalize-DelayedStartTime {
    param([string]$Value)

    $text = ([string]$Value).Trim()
    if ([string]::IsNullOrWhiteSpace($text)) { return '23:00' }

    $result = [DateTime]::MinValue
    $culture = [System.Globalization.CultureInfo]::InvariantCulture
    $styles = [System.Globalization.DateTimeStyles]::None
    foreach ($format in @('HH:mm', 'H:mm', 'HH.mm', 'H.mm')) {
        if ([DateTime]::TryParseExact($text, $format, $culture, $styles, [ref]$result)) {
            return $result.ToString('HH:mm')
        }
    }

    if ([DateTime]::TryParse($text, [ref]$result)) {
        return $result.ToString('HH:mm')
    }

    return '23:00'
}

function Normalize-DelayedStartAt {
    param([string]$Value)

    $text = ([string]$Value).Trim()
    if ([string]::IsNullOrWhiteSpace($text)) { return '' }

    $result = [DateTime]::MinValue
    if ([DateTime]::TryParse($text, [ref]$result)) {
        return $result.ToString('s')
    }
    return ''
}

function Save-ProcessingState {
    try {
        $state = [ordered]@{
            contactFilePath = if ($script:LastFilePath) { $script:LastFilePath } else { $script:SavedContactFilePath }
            oneByOneNextIndex = [int]$script:OneByOneNextIndex
            messageTemplatesPath = $script:MessageTemplatesPath
            messageTemplateIndex = [int]$script:MessageTemplateIndex
            uiTheme = $script:UiTheme
            appOpacityPercent = [int]$script:AppOpacityPercent
            lowPerformanceMode = [bool]$script:LowPerformanceMode
            notificationWindowEnabled = [bool]$script:NotificationWindowEnabled
            activateMaxWindow = [bool]$script:ActivateMaxWindow
            switchDelayMs = [int]$script:SwitchDelayMs
            personDelaySeconds = [int]$script:PersonDelaySeconds
            peoplePerMax = [int]$script:PeoplePerMax
            delayedStartEnabled = [bool]$script:DelayedStartEnabled
            delayedStartTime = Normalize-DelayedStartTime $script:DelayedStartTime
            delayedStartAt = Normalize-DelayedStartAt $script:DelayedStartAt
            groupNameExtrasText = $script:GroupNameExtrasText
            useGroupNameExtras = [bool]$script:UseGroupNameExtras
            useAhkTyping = [bool]$script:UseAhkTyping
            ahkExePath = $script:AhkExePath
            wallpaperPath = $script:WallpaperPath
            maxitochkaRootPath = $script:MaxitochkaRootPath
            updateSourcePath = $script:UpdateSourcePath
            appVersion = $script:AppVersion
        }
        $json = $state | ConvertTo-Json -Depth 4
        if ((Test-Path -LiteralPath $script:StatePath) -and [string]::Equals([string]$script:LastSavedStateJson, [string]$json, [StringComparison]::Ordinal)) {
            return
        }
        $json | Set-Content -LiteralPath $script:StatePath -Encoding UTF8
        $script:LastSavedStateJson = $json
    }
    catch {
        # State is only for resume convenience; automation can continue without it.
    }
}

function Load-ProcessingState {
    if (-not (Test-Path -LiteralPath $script:StatePath)) { return }

    try {
        $state = Get-Content -Raw -Encoding UTF8 -LiteralPath $script:StatePath | ConvertFrom-Json
        $script:SavedContactFilePath = [string]$state.contactFilePath
        $script:OneByOneNextIndex = [Math]::Max(0, [int]$state.oneByOneNextIndex)
        $script:MessageTemplatesPath = [string]$state.messageTemplatesPath
        $script:MessageTemplateIndex = [Math]::Max(0, [int]$state.messageTemplateIndex)
        if (-not [string]::IsNullOrWhiteSpace([string]$state.uiTheme)) {
            $script:UiTheme = [string]$state.uiTheme
        }
        if ($null -ne $state.appOpacityPercent) {
            $script:AppOpacityPercent = [Math]::Max(75, [Math]::Min(100, [int]$state.appOpacityPercent))
        }
        if ($null -ne $state.lowPerformanceMode) {
            $script:LowPerformanceMode = [bool]$state.lowPerformanceMode
        }
        if ($null -ne $state.notificationWindowEnabled) {
            $script:NotificationWindowEnabled = [bool]$state.notificationWindowEnabled
        }
        if ($null -ne $state.activateMaxWindow) {
            $script:ActivateMaxWindow = [bool]$state.activateMaxWindow
        }
        if ($null -ne $state.switchDelayMs) {
            $script:SwitchDelayMs = [Math]::Max(200, [Math]::Min(5000, [int]$state.switchDelayMs))
        }
        if ($null -ne $state.personDelaySeconds) {
            $script:PersonDelaySeconds = [Math]::Max(10, [Math]::Min(180, [int]$state.personDelaySeconds))
        }
        if ($null -ne $state.peoplePerMax) {
            $script:PeoplePerMax = [Math]::Max(1, [Math]::Min(50, [int]$state.peoplePerMax))
        }
        if ($null -ne $state.delayedStartEnabled) {
            $script:DelayedStartEnabled = [bool]$state.delayedStartEnabled
        }
        if ($null -ne $state.delayedStartTime) {
            $script:DelayedStartTime = Normalize-DelayedStartTime ([string]$state.delayedStartTime)
        }
        if ($null -ne $state.delayedStartAt) {
            $script:DelayedStartAt = Normalize-DelayedStartAt ([string]$state.delayedStartAt)
        }
        if ($null -ne $state.groupNameExtrasText) {
            Set-GroupNameExtrasFromText ([string]$state.groupNameExtrasText)
        }
        if ($null -ne $state.useGroupNameExtras) {
            $script:UseGroupNameExtras = [bool]$state.useGroupNameExtras
        }
        if ($null -ne $state.useAhkTyping) {
            $script:UseAhkTyping = [bool]$state.useAhkTyping
        }
        if (-not [string]::IsNullOrWhiteSpace([string]$state.ahkExePath)) {
            $script:AhkExePath = [string]$state.ahkExePath
        }
        if ($null -ne $state.wallpaperPath) {
            $script:WallpaperPath = [string]$state.wallpaperPath
        }
        if (-not [string]::IsNullOrWhiteSpace([string]$state.maxitochkaRootPath)) {
            $script:MaxitochkaRootPath = [string]$state.maxitochkaRootPath
        }
        if (-not [string]::IsNullOrWhiteSpace([string]$state.updateSourcePath)) {
            $script:UpdateSourcePath = [string]$state.updateSourcePath
        }

        if (-not [string]::IsNullOrWhiteSpace($script:MessageTemplatesPath) -and (Test-Path -LiteralPath $script:MessageTemplatesPath)) {
            $script:MessageTemplates.Clear()
            foreach ($template in Parse-MessageTemplatesFile $script:MessageTemplatesPath) {
                $script:MessageTemplates.Add([string]$template)
            }
            if ($script:MessageTemplates.Count -gt 0) {
                $script:MessageTemplateIndex = $script:MessageTemplateIndex % $script:MessageTemplates.Count
            }
        }
    }
    catch {
        $script:SavedContactFilePath = $null
        $script:OneByOneNextIndex = 0
        $script:MessageTemplates.Clear()
        $script:MessageTemplatesPath = $null
        $script:MessageTemplateIndex = 0
        $script:UiTheme = 'Карбон'
        $script:AppOpacityPercent = 94
        $script:LowPerformanceMode = $false
        $script:NotificationWindowEnabled = $true
        $script:ActivateMaxWindow = $true
        $script:SwitchDelayMs = 900
        $script:PersonDelaySeconds = 45
        $script:PeoplePerMax = 1
        $script:DelayedStartEnabled = $false
        $script:DelayedStartTime = '23:00'
        $script:DelayedStartAt = ''
        $script:DelayedStartLastRunDate = ''
        Set-GroupNameExtrasFromText ""
        $script:UseGroupNameExtras = $true
        $script:UseAhkTyping = $false
        $script:AhkExePath = ""
        $script:WallpaperPath = ""
        $script:MaxitochkaRootPath = ""
        $script:UpdateSourcePath = ""
    }
}

function Get-AppVersionValue {
    param([string]$Value)

    if ([string]::IsNullOrWhiteSpace($Value)) { return [version]'0.0' }
    try { return [version]$Value } catch { return [version]'0.0' }
}

function Convert-AppUpdateManifestObject {
    param($Value)

    if ($null -eq $Value) { return $null }
    if ($Value -is [string]) {
        $text = ([string]$Value).Trim().TrimStart([char]0xFEFF)
        if ([string]::IsNullOrWhiteSpace($text)) { return $null }
        return ($text | ConvertFrom-Json)
    }
    return $Value
}

function Get-AppUpdateManifestField {
    param(
        $Manifest,
        [string]$Name
    )

    if ($null -eq $Manifest -or [string]::IsNullOrWhiteSpace($Name)) { return '' }

    if ($Manifest -is [System.Collections.IDictionary]) {
        foreach ($key in $Manifest.Keys) {
            $cleanKey = ([string]$key).Trim().TrimStart([char]0xFEFF)
            if ([string]::Equals($cleanKey, $Name, [StringComparison]::OrdinalIgnoreCase)) {
                return [string]$Manifest[$key]
            }
        }
    }

    foreach ($property in $Manifest.PSObject.Properties) {
        $cleanName = ([string]$property.Name).Trim().TrimStart([char]0xFEFF)
        if ([string]::Equals($cleanName, $Name, [StringComparison]::OrdinalIgnoreCase)) {
            return [string]$property.Value
        }
    }

    return ''
}

function Get-AppUpdateManifestVersion {
    param($Manifest)
    return (Get-AppUpdateManifestField -Manifest $Manifest -Name 'version')
}

function Get-AppUpdateManifestPackage {
    param($Manifest)
    return (Get-AppUpdateManifestField -Manifest $Manifest -Name 'package')
}

function Test-AppUpdateUrl {
    param([string]$Value)

    return ([string]$Value -match '^https?://')
}

function Join-AppUpdateUrl {
    param([string]$Base, [string]$Child)

    if ([string]::IsNullOrWhiteSpace($Base)) { return $Child }
    if ([string]::IsNullOrWhiteSpace($Child)) { return $Base }
    if ($Child -match '^https?://') { return $Child }
    return ($Base.TrimEnd('/') + '/' + $Child.TrimStart('/'))
}

function Get-AppUpdateSourceFile {
    return (Join-Path $script:AppRoot $script:UpdateSourceFileName)
}

function Get-AppUpdateChannelFile {
    return (Join-Path $script:AppRoot $script:UpdateChannelFileName)
}

function Get-AppUpdateAdminMarkerFile {
    return (Join-Path $script:AppRoot $script:UpdateAdminMarkerFileName)
}

function Test-AppUpdateAdminMode {
    return (Test-Path -LiteralPath (Get-AppUpdateAdminMarkerFile) -PathType Leaf)
}

function Split-AppUpdateSources {
    param([string]$Text)

    if ([string]::IsNullOrWhiteSpace($Text)) { return @() }
    return @(
        $Text -split "(?:`r`n|`n|`r|;)" |
            ForEach-Object { $_.Trim().TrimStart([char]0xFEFF) } |
            Where-Object { -not [string]::IsNullOrWhiteSpace($_) -and -not $_.StartsWith('#') }
    )
}

function Get-AppUpdateSourceCandidates {
    $items = New-Object System.Collections.Generic.List[string]
    $add = {
        param([string]$Value)
        if ([string]::IsNullOrWhiteSpace($Value)) { return }
        $trimmed = $Value.Trim()
        if (-not $items.Contains($trimmed)) { $items.Add($trimmed) }
    }

    foreach ($source in Split-AppUpdateSources $script:DefaultWebUpdateUrl) { & $add $source }
    foreach ($source in Split-AppUpdateSources $script:UpdateSourcePath) { & $add $source }
    $sourceFile = Get-AppUpdateSourceFile
    if (Test-Path -LiteralPath $sourceFile) {
        try {
            foreach ($source in Split-AppUpdateSources (Get-Content -Raw -Encoding UTF8 -LiteralPath $sourceFile)) {
                & $add $source
            }
        }
        catch {}
    }
    $channelFile = Get-AppUpdateChannelFile
    if (Test-Path -LiteralPath $channelFile) {
        try {
            foreach ($source in Split-AppUpdateSources (Get-Content -Raw -Encoding UTF8 -LiteralPath $channelFile)) {
                & $add $source
            }
        }
        catch {}
    }
    & $add (Join-Path $script:AppRoot 'updates')
    return @($items)
}

function Get-AppUpdateSourceSummary {
    $sources = @(Get-AppUpdateSourceCandidates)
    if ($sources.Count -eq 0) {
        return 'Источники обновления не настроены.'
    }
    $preview = @($sources | Select-Object -First 5)
    return ("Проверены источники:`n" + ($preview -join "`n"))
}

function Read-AppUpdateManifestFromSource {
    param([string]$Source)

    if ([string]::IsNullOrWhiteSpace($Source)) { return $null }
    $sourceText = $Source.Trim()

    try {
        if (Test-AppUpdateUrl $sourceText) {
            $manifestUrl = if ($sourceText.ToLowerInvariant().EndsWith('.json')) {
                $sourceText
            }
            else {
                Join-AppUpdateUrl $sourceText $script:UpdateManifestFileName
            }
            $response = Invoke-WebRequest -Uri $manifestUrl -TimeoutSec 20 -UseBasicParsing -Headers @{ 'Cache-Control' = 'no-cache'; 'Pragma' = 'no-cache' } -ErrorAction Stop
            $manifest = Convert-AppUpdateManifestObject $response.Content
            return [pscustomobject]@{ Manifest = $manifest; Source = $sourceText; ManifestPath = $manifestUrl }
        }

        $manifestPath = $sourceText
        if ((Test-Path -LiteralPath $sourceText -PathType Container)) {
            $manifestPath = Join-Path $sourceText $script:UpdateManifestFileName
        }
        if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) { return $null }

        $manifest = Convert-AppUpdateManifestObject (Get-Content -Raw -Encoding UTF8 -LiteralPath $manifestPath)
        return [pscustomobject]@{ Manifest = $manifest; Source = $sourceText; ManifestPath = $manifestPath }
    }
    catch {
        return $null
    }
}

function Find-AppUpdateManifest {
    $bestInfo = $null
    $bestVersion = [version]'0.0'
    foreach ($source in Get-AppUpdateSourceCandidates) {
        $info = Read-AppUpdateManifestFromSource $source
        if (-not $info) { continue }
        $versionText = Get-AppUpdateManifestVersion $info.Manifest
        if ([string]::IsNullOrWhiteSpace($versionText)) { continue }
        $version = Get-AppVersionValue $versionText
        if (-not $bestInfo -or $version -gt $bestVersion) {
            $bestInfo = $info
            $bestVersion = $version
        }
    }
    return $bestInfo
}

function Get-AppUpdatePackagePath {
    param($ManifestInfo)

    if (-not $ManifestInfo -or -not $ManifestInfo.Manifest) {
        throw 'Не найдено описание обновления.'
    }

    $package = Get-AppUpdateManifestPackage $ManifestInfo.Manifest
    if ([string]::IsNullOrWhiteSpace($package)) {
        $package = $script:UpdatePackageFileName
    }

    if (Test-AppUpdateUrl $package) {
        $target = Join-Path $env:TEMP ("GusUpdate_{0}.zip" -f ([Guid]::NewGuid().ToString('N')))
        Invoke-WebRequest -Uri $package -OutFile $target -TimeoutSec 120 -ErrorAction Stop
        return $target
    }

    if (Test-AppUpdateUrl ([string]$ManifestInfo.Source)) {
        $base = [string]$ManifestInfo.Source
        if ($base.ToLowerInvariant().EndsWith('.json')) {
            $base = $base.Substring(0, $base.LastIndexOf('/'))
        }
        $url = Join-AppUpdateUrl $base $package
        $target = Join-Path $env:TEMP ("GusUpdate_{0}.zip" -f ([Guid]::NewGuid().ToString('N')))
        Invoke-WebRequest -Uri $url -OutFile $target -TimeoutSec 120 -ErrorAction Stop
        return $target
    }

    $packagePath = $package
    if (-not [IO.Path]::IsPathRooted($packagePath)) {
        $sourcePath = [string]$ManifestInfo.Source
        if (Test-Path -LiteralPath $sourcePath -PathType Leaf) {
            $sourcePath = Split-Path -Parent $sourcePath
        }
        $packagePath = Join-Path $sourcePath $package
    }
    if (-not (Test-Path -LiteralPath $packagePath -PathType Leaf)) {
        throw "Не найден пакет обновления: $packagePath"
    }
    return $packagePath
}

function Write-AppUpdateSource {
    param([string]$Source)

    if ([string]::IsNullOrWhiteSpace($Source)) { return }
    Set-AppUpdateSourceText $Source | Out-Null
}

function Set-AppUpdateSourceText {
    param([string]$Source)

    if ([string]::IsNullOrWhiteSpace($Source)) { return $false }
    try {
        $sources = @(Split-AppUpdateSources $Source)
        if ($sources.Count -le 0) { return $false }
        $script:UpdateSourcePath = ($sources -join [Environment]::NewLine)
        Set-Content -LiteralPath (Get-AppUpdateSourceFile) -Encoding UTF8 -Value $sources
        Set-Content -LiteralPath (Get-AppUpdateChannelFile) -Encoding UTF8 -Value $sources
        if ($updatesSourceBox) {
            $updatesSourceBox.Text = $script:UpdateSourcePath
        }
        Save-ProcessingState
        return $true
    }
    catch {
        return $false
    }
}

function Write-AppWebsiteUpdatePage {
    param(
        [string]$TargetPath,
        [string]$UpdateUrl
    )

    if ([string]::IsNullOrWhiteSpace($TargetPath)) { return }
    if (-not (Test-Path -LiteralPath $TargetPath -PathType Container)) {
        New-Item -ItemType Directory -Path $TargetPath -Force | Out-Null
    }

    $siteUrl = if ([string]::IsNullOrWhiteSpace($UpdateUrl)) { '' } else { $UpdateUrl.Trim() }
    $manifestUrl = Join-AppUpdateUrl $siteUrl $script:UpdateManifestFileName
    $packageUrl = Join-AppUpdateUrl $siteUrl $script:UpdatePackageFileName
    $versionUrl = Join-AppUpdateUrl $siteUrl 'VERSION.txt'
    $createdAt = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'

    $html = @"
<!doctype html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Гусь - обновления</title>
  <style>
    :root {
      color-scheme: dark;
      --bg: #101217;
      --panel: #191d26;
      --text: #f4f7fb;
      --muted: #a8b0bf;
      --line: #303644;
      --accent: #31a5ff;
    }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      min-height: 100vh;
      font-family: "Segoe UI", Arial, sans-serif;
      background: var(--bg);
      color: var(--text);
      display: grid;
      place-items: center;
      padding: 32px 16px;
    }
    main {
      width: min(720px, 100%);
      background: var(--panel);
      border: 1px solid var(--line);
      border-radius: 8px;
      padding: 24px;
    }
    h1 { margin: 0 0 8px; font-size: 28px; font-weight: 700; }
    p { margin: 0 0 18px; color: var(--muted); line-height: 1.5; }
    .version { color: var(--text); font-weight: 700; }
    .files { display: grid; gap: 10px; margin-top: 18px; }
    a {
      color: var(--text);
      text-decoration: none;
      border: 1px solid var(--line);
      border-radius: 6px;
      padding: 12px 14px;
      display: flex;
      justify-content: space-between;
      gap: 12px;
      min-width: 0;
    }
    a:hover { border-color: var(--accent); }
    span { color: var(--muted); overflow-wrap: anywhere; }
    footer { margin-top: 18px; color: var(--muted); font-size: 13px; }
  </style>
</head>
<body>
  <main>
    <h1>Гусь - обновления</h1>
    <p>Канал обновлений работает. Текущая версия: <span class="version">v$($script:AppVersion)</span>.</p>
    <p>Рабочие ПК читают файл manifest и скачивают zip-пакет по кнопке "Обновить".</p>
    <div class="files">
      <a href="$manifestUrl"><strong>Manifest</strong><span>$($script:UpdateManifestFileName)</span></a>
      <a href="$packageUrl"><strong>Пакет</strong><span>$($script:UpdatePackageFileName)</span></a>
      <a href="$versionUrl"><strong>Версия</strong><span>VERSION.txt</span></a>
    </div>
    <footer>Собрано: $createdAt</footer>
  </main>
</body>
</html>
"@
    Set-Content -LiteralPath (Join-Path $TargetPath 'index.html') -Encoding UTF8 -Value $html

    $headers = @"
/*
  Access-Control-Allow-Origin: *

/$($script:UpdateManifestFileName)
  Content-Type: application/json; charset=utf-8

/$($script:UpdatePackageFileName)
  Content-Type: application/zip

/VERSION.txt
  Content-Type: text/plain; charset=utf-8
"@
    Set-Content -LiteralPath (Join-Path $TargetPath '_headers') -Encoding UTF8 -Value $headers

    $netlifyConfig = @"
[build]
  publish = "."
"@
    Set-Content -LiteralPath (Join-Path $TargetPath 'netlify.toml') -Encoding UTF8 -Value $netlifyConfig
}

function Publish-AppWebsiteUpdateFiles {
    param([string]$UpdateUrl)

    if ([string]::IsNullOrWhiteSpace($UpdateUrl) -or -not (Test-AppUpdateUrl $UpdateUrl)) {
        throw 'Укажи ссылку сайта вида https://site.ru/gus-updates/'
    }

    $target = Join-Path $script:AppRoot 'Сайт обновлений'
    if (-not (Test-Path -LiteralPath $target -PathType Container)) {
        New-Item -ItemType Directory -Path $target -Force | Out-Null
    }

    foreach ($fileName in @($script:UpdateManifestFileName, $script:UpdatePackageFileName, 'VERSION.txt')) {
        $sourceFile = Join-Path $script:AppRoot $fileName
        if (-not (Test-Path -LiteralPath $sourceFile -PathType Leaf)) {
            throw "Не найден файл для сайта: $fileName"
        }
        Copy-Item -LiteralPath $sourceFile -Destination (Join-Path $target $fileName) -Force
    }

    Set-Content -LiteralPath (Join-Path $target $script:UpdateChannelFileName) -Encoding UTF8 -Value $UpdateUrl.Trim()
    Set-Content -LiteralPath (Join-Path $target 'README_UPLOAD.txt') -Encoding UTF8 -Value @(
        'Залей содержимое этой папки на сайт обновлений.',
        '',
        "Адрес канала: $($UpdateUrl.Trim())",
        '',
        'На сайте должны открываться файлы:',
        (Join-AppUpdateUrl $UpdateUrl $script:UpdateManifestFileName),
        (Join-AppUpdateUrl $UpdateUrl $script:UpdatePackageFileName),
        (Join-AppUpdateUrl $UpdateUrl 'VERSION.txt')
    )
    Write-AppWebsiteUpdatePage -TargetPath $target -UpdateUrl $UpdateUrl

    Set-AppUpdateSourceText $UpdateUrl | Out-Null
    return $target
}

function Publish-AppUpdateChannel {
    param([string]$TargetPath)

    if ([string]::IsNullOrWhiteSpace($TargetPath)) {
        throw 'Укажи папку канала обновлений.'
    }
    if (Test-AppUpdateUrl $TargetPath) {
        return (Publish-AppWebsiteUpdateFiles $TargetPath)
    }

    $target = $TargetPath.Trim()
    if (-not (Test-Path -LiteralPath $target -PathType Container)) {
        New-Item -ItemType Directory -Path $target -Force | Out-Null
    }
    $target = [IO.Path]::GetFullPath($target)

    foreach ($fileName in @($script:UpdateManifestFileName, $script:UpdatePackageFileName, 'VERSION.txt')) {
        $sourceFile = Join-Path $script:AppRoot $fileName
        if (-not (Test-Path -LiteralPath $sourceFile -PathType Leaf)) {
            throw "Не найден файл для публикации: $fileName"
        }
        $destinationFile = Join-Path $target $fileName
        $sameFile = $false
        try {
            $sameFile = [string]::Equals(
                [IO.Path]::GetFullPath($sourceFile),
                [IO.Path]::GetFullPath($destinationFile),
                [StringComparison]::OrdinalIgnoreCase
            )
        }
        catch {
        }
        if (-not $sameFile) {
            Copy-Item -LiteralPath $sourceFile -Destination $destinationFile -Force
        }
    }

    Set-AppUpdateSourceText $target | Out-Null
    Set-Content -LiteralPath (Join-Path $target $script:UpdateChannelFileName) -Encoding UTF8 -Value $target
    return $target
}

function Start-AppUpdateFromZip {
    param(
        [string]$ZipPath,
        [string]$NewVersion = ''
    )

    if ([string]::IsNullOrWhiteSpace($ZipPath) -or -not (Test-Path -LiteralPath $ZipPath -PathType Leaf)) {
        throw "Пакет обновления не найден: $ZipPath"
    }

    $quote = {
        param([string]$Value)
        return "'" + (($Value -replace "'", "''")) + "'"
    }

    $applyPath = Join-Path $env:TEMP ("GusApplyUpdate_{0}.ps1" -f ([Guid]::NewGuid().ToString('N')))
    $rootLiteral = & $quote $script:AppRoot
    $zipLiteral = & $quote ([IO.Path]::GetFullPath($ZipPath))
    $versionLiteral = & $quote $NewVersion
    $parentPid = [int]$PID
    $scriptText = @"
`$ErrorActionPreference = 'Stop'
`$root = $rootLiteral
`$zip = $zipLiteral
`$version = $versionLiteral
`$parentPid = $parentPid
while (Get-Process -Id `$parentPid -ErrorAction SilentlyContinue) {
    Start-Sleep -Milliseconds 250
}
`$extract = Join-Path `$env:TEMP ('GusUpdateExtract_' + [Guid]::NewGuid().ToString('N'))
`$stateBackup = Join-Path `$env:TEMP ('GusUpdateState_' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path `$extract | Out-Null
New-Item -ItemType Directory -Path `$stateBackup | Out-Null
foreach (`$name in @('max_contact_state.json','max_contact_replies.json','update_source.txt','update_channel.txt')) {
    `$src = Join-Path `$root `$name
    if (Test-Path -LiteralPath `$src) {
        Copy-Item -LiteralPath `$src -Destination (Join-Path `$stateBackup `$name) -Force
    }
}
Expand-Archive -LiteralPath `$zip -DestinationPath `$extract -Force
Copy-Item -Path (Join-Path `$extract '*') -Destination `$root -Recurse -Force
foreach (`$name in @('max_contact_state.json','max_contact_replies.json','update_source.txt','update_channel.txt')) {
    `$saved = Join-Path `$stateBackup `$name
    if (Test-Path -LiteralPath `$saved) {
        Copy-Item -LiteralPath `$saved -Destination (Join-Path `$root `$name) -Force
    }
}
if (-not [string]::IsNullOrWhiteSpace(`$version)) {
    Set-Content -LiteralPath (Join-Path `$root 'VERSION.txt') -Encoding UTF8 -Value `$version
}
Remove-Item -LiteralPath `$extract -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath `$stateBackup -Recurse -Force -ErrorAction SilentlyContinue
`$runner = Join-Path `$root 'Run-MaxContactTool.bat'
if (Test-Path -LiteralPath `$runner) {
    Start-Process -FilePath `$runner -WorkingDirectory `$root
}
"@
    $scriptText | Set-Content -LiteralPath $applyPath -Encoding UTF8
    Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', $applyPath) -WindowStyle Hidden
}

function Invoke-AppUpdate {
    if ($script:OneByOneRunning) {
        [System.Windows.Forms.MessageBox]::Show('Сначала останови текущую работу, потом запускай обновление.', 'Обновление', 'OK', 'Warning') | Out-Null
        return
    }

    try {
        $manifestInfo = Find-AppUpdateManifest
        $packagePath = ''
        $newVersion = ''
        if ($manifestInfo) {
            $newVersion = Get-AppUpdateManifestVersion $manifestInfo.Manifest
            if ([string]::IsNullOrWhiteSpace($newVersion)) {
                throw 'В manifest обновления не указана версия.'
            }
            $current = Get-AppVersionValue $script:AppVersion
            $latest = Get-AppVersionValue $newVersion
            if ($latest -lt $current) {
                [System.Windows.Forms.MessageBox]::Show("Установлена версия $($script:AppVersion). В канале обновлений версия $newVersion.`nКанал обновлений старее этой программы.", 'Обновление', 'OK', 'Information') | Out-Null
                return
            }
            if ($latest -eq $current) {
                [System.Windows.Forms.MessageBox]::Show("Установлена актуальная версия $($script:AppVersion). Обновление не требуется.", 'Обновление', 'OK', 'Information') | Out-Null
                return
            }
            $packagePath = Get-AppUpdatePackagePath $manifestInfo
            Write-AppUpdateSource ([string]$manifestInfo.Source)
        }
        else {
            $autoMessage = "Автоматическое обновление не нашло файл $($script:UpdateManifestFileName).`n`n$(Get-AppUpdateSourceSummary)`n`nЧтобы обновление работало в один клик, в одном из этих мест должен лежать $($script:UpdateManifestFileName) и $($script:UpdatePackageFileName), либо в update_source.txt должна быть ссылка на папку обновлений."
            $manual = [System.Windows.Forms.MessageBox]::Show("$autoMessage`n`nВыбрать файл обновления вручную?", 'Обновление', 'YesNo', 'Warning')
            if ($manual -ne 'Yes') { return }
            $dialog = New-Object System.Windows.Forms.OpenFileDialog
            $dialog.Filter = 'Обновление (*.zip;*.bat;*.json)|*.zip;*.bat;*.json|Все файлы (*.*)|*.*'
            $dialog.Title = 'Выбери пакет обновления или установщик'
            if ($dialog.ShowDialog() -ne 'OK') { return }
            $selected = $dialog.FileName
            $ext = [IO.Path]::GetExtension($selected).ToLowerInvariant()
            if ($ext -eq '.bat') {
                Write-AppUpdateSource (Split-Path -Parent $selected)
                Start-Process -FilePath $selected -WorkingDirectory (Split-Path -Parent $selected)
                if ($form) { $form.Close() }
                return
            }
            if ($ext -eq '.json') {
                $manifestInfo = Read-AppUpdateManifestFromSource $selected
                if (-not $manifestInfo) { throw 'Не удалось прочитать manifest обновления.' }
                $newVersion = Get-AppUpdateManifestVersion $manifestInfo.Manifest
                $packagePath = Get-AppUpdatePackagePath $manifestInfo
                Write-AppUpdateSource (Split-Path -Parent $selected)
            }
            else {
                $packagePath = $selected
                $newVersion = ''
                Write-AppUpdateSource (Split-Path -Parent $selected)
            }
        }

        $versionText = if ([string]::IsNullOrWhiteSpace($newVersion)) { 'выбранной версии' } else { "версии $newVersion" }
        $confirm = [System.Windows.Forms.MessageBox]::Show("Программа закроется, обновится до $versionText и запустится заново.", 'Обновление', 'OKCancel', 'Information')
        if ($confirm -ne 'OK') { return }
        Start-AppUpdateFromZip -ZipPath $packagePath -NewVersion $newVersion
        if ($form) { $form.Close() }
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show("Не удалось обновить программу:`n$($_.Exception.Message)", 'Обновление', 'OK', 'Error') | Out-Null
    }
}

function Refresh-MessageTemplatesStatus {
    if (-not $messageTemplatesStatusLabel) { return }

    if ($script:MessageTemplates.Count -gt 0) {
        $next = ($script:MessageTemplateIndex % $script:MessageTemplates.Count) + 1
        $messageTemplatesStatusLabel.Text = "Текстов: $($script:MessageTemplates.Count) | следующий: $next"
    }
    else {
        $messageTemplatesStatusLabel.Text = 'Текстов: 1 | из поля ниже'
    }
}

function Refresh-OneByOneStatus {
    if (-not $queueStatusLabel) { return }

    $total = @(Get-ValidContacts).Count
    if ($total -le 0) {
        $queueStatusLabel.Text = 'Очередь: 0/0'
        return
    }

    $next = [Math]::Min([int]$script:OneByOneNextIndex + 1, $total)
    if ($script:OneByOneNextIndex -ge $total) {
        $queueStatusLabel.Text = "Очередь: все $total обработаны"
    }
    else {
        $queueStatusLabel.Text = "Очередь: следующий $next из $total"
    }
}

function Get-DelayedStartTarget {
    if (-not [string]::IsNullOrWhiteSpace([string]$script:DelayedStartAt)) {
        $target = [DateTime]::MinValue
        if ([DateTime]::TryParse([string]$script:DelayedStartAt, [ref]$target)) {
            return $target
        }
    }

    $timeText = Normalize-DelayedStartTime $script:DelayedStartTime
    $parts = $timeText -split ':'
    $hour = [Math]::Max(0, [Math]::Min(23, [int]$parts[0]))
    $minute = [Math]::Max(0, [Math]::Min(59, [int]$parts[1]))
    $target = [DateTime]::Today.AddHours($hour).AddMinutes($minute)
    if ($target -le (Get-Date)) {
        $target = $target.AddDays(1)
    }
    return $target
}

function Refresh-DelayedStartStatus {
    if (-not $delayedStartStatusLabel) { return }

    $script:DelayedStartTime = Normalize-DelayedStartTime $script:DelayedStartTime
    if (-not [bool]$script:DelayedStartEnabled) {
        $delayedStartStatusLabel.Text = 'Отложено: нет'
        return
    }

    if ($script:OneByOneRunning) {
        $delayedStartStatusLabel.Text = 'Работа идет'
        return
    }

    $target = Get-DelayedStartTarget
    $delayedStartStatusLabel.Text = "Старт: $($target.ToString('dd.MM HH:mm'))"
}

function Invoke-DelayedStartTimerTick {
    if (-not [bool]$script:DelayedStartEnabled) {
        Refresh-DelayedStartStatus
        return
    }
    if ($script:OneByOneRunning) {
        Refresh-DelayedStartStatus
        return
    }

    $now = Get-Date
    $target = Get-DelayedStartTarget
    if ($target -lt $now.AddMinutes(-1)) {
        $script:DelayedStartEnabled = $false
        $script:DelayedStartAt = ''
        Save-ProcessingState
        if ($delayedStartStatusLabel) { $delayedStartStatusLabel.Text = 'Отложено: время прошло' }
        return
    }

    if ($now -lt $target) {
        Refresh-DelayedStartStatus
        return
    }

    $dateKey = $target.ToString('yyyy-MM-dd HH:mm')
    if ($script:DelayedStartLastRunDate -eq $dateKey) {
        Refresh-DelayedStartStatus
        return
    }

    $script:DelayedStartLastRunDate = $dateKey
    $script:DelayedStartEnabled = $false
    $script:DelayedStartAt = ''
    Save-ProcessingState
    if ($delayedStartStatusLabel) { $delayedStartStatusLabel.Text = 'Запускаю работу...' }
    [System.Windows.Forms.Application]::DoEvents()
    Invoke-OneByOneViaMaxitochka -AutoStart
    Refresh-DelayedStartStatus
}

function Show-DelayedStartDialog {
    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = 'Отложенный запуск сообщений'
    $dialog.StartPosition = 'CenterParent'
    $dialog.FormBorderStyle = 'FixedDialog'
    $dialog.MaximizeBox = $false
    $dialog.MinimizeBox = $false
    $dialog.ShowInTaskbar = $false
    $dialog.Size = New-Object System.Drawing.Size(430, 245)
    $dialog.Font = New-Object System.Drawing.Font('Segoe UI', 9)

    $layout = New-Object System.Windows.Forms.TableLayoutPanel
    $layout.Dock = 'Fill'
    $layout.ColumnCount = 3
    $layout.RowCount = 5
    $layout.Padding = New-Object System.Windows.Forms.Padding(18, 16, 18, 14)
    $layout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 96))) | Out-Null
    $layout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
    $layout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 126))) | Out-Null
    $layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 42))) | Out-Null
    $layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 42))) | Out-Null
    $layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 42))) | Out-Null
    $layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
    $layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 44))) | Out-Null
    $dialog.Controls.Add($layout)

    $storedTarget = Get-DelayedStartTarget
    $hasActiveTarget = ([bool]$script:DelayedStartEnabled -and $storedTarget -gt (Get-Date))
    $target = $storedTarget
    if (-not $hasActiveTarget) {
        $target = (Get-Date).AddMinutes(10)
    }

    $dateLabel = New-Object System.Windows.Forms.Label
    $dateLabel.Text = 'Дата'
    $dateLabel.Dock = 'Fill'
    $dateLabel.TextAlign = 'MiddleLeft'
    $dateLabel.AccessibleName = 'SettingsLabel'
    $layout.Controls.Add($dateLabel, 0, 0)

    $datePicker = New-Object System.Windows.Forms.DateTimePicker
    $datePicker.Format = [System.Windows.Forms.DateTimePickerFormat]::Short
    $datePicker.Value = $target.Date
    $datePicker.Dock = 'Fill'
    $layout.SetColumnSpan($datePicker, 2)
    $layout.Controls.Add($datePicker, 1, 0)

    $timeLabel = New-Object System.Windows.Forms.Label
    $timeLabel.Text = 'Время'
    $timeLabel.Dock = 'Fill'
    $timeLabel.TextAlign = 'MiddleLeft'
    $timeLabel.AccessibleName = 'SettingsLabel'
    $layout.Controls.Add($timeLabel, 0, 1)

    $timePicker = New-Object System.Windows.Forms.DateTimePicker
    $timePicker.Format = [System.Windows.Forms.DateTimePickerFormat]::Custom
    $timePicker.CustomFormat = 'HH:mm'
    $timePicker.ShowUpDown = $true
    $timePicker.Value = [DateTime]::Today.AddHours($target.Hour).AddMinutes($target.Minute)
    $timePicker.Dock = 'Left'
    $timePicker.Width = 96
    $layout.Controls.Add($timePicker, 1, 1)

    $currentStatusLabel = New-Object System.Windows.Forms.Label
    $currentStatusLabel.Text = if ($hasActiveTarget) { "Запланировано: $($storedTarget.ToString('dd.MM HH:mm'))" } else { 'Отложенный запуск не задан' }
    $currentStatusLabel.Dock = 'Fill'
    $currentStatusLabel.TextAlign = 'MiddleLeft'
    $currentStatusLabel.AccessibleName = 'MutedLabel'
    $layout.SetColumnSpan($currentStatusLabel, 3)
    $layout.Controls.Add($currentStatusLabel, 0, 2)

    $hintLabel = New-Object System.Windows.Forms.Label
    $hintLabel.Text = 'В выбранное время программа запустит тот же сценарий, что и кнопка "Старт". Окно программы должно быть открыто.'
    $hintLabel.Dock = 'Fill'
    $hintLabel.TextAlign = 'TopLeft'
    $hintLabel.AccessibleName = 'MutedLabel'
    $layout.SetColumnSpan($hintLabel, 3)
    $layout.Controls.Add($hintLabel, 0, 3)

    $buttons = New-Object System.Windows.Forms.FlowLayoutPanel
    $buttons.Dock = 'Fill'
    $buttons.FlowDirection = 'RightToLeft'
    $buttons.WrapContents = $false
    $layout.SetColumnSpan($buttons, 3)
    $layout.Controls.Add($buttons, 0, 4)

    $saveButton = New-Object System.Windows.Forms.Button
    $saveButton.Text = 'Запланировать'
    $saveButton.Width = 124
    $saveButton.Height = 34
    $saveButton.AccessibleName = 'PrimaryAction'
    $buttons.Controls.Add($saveButton)

    $closeButton = New-Object System.Windows.Forms.Button
    $closeButton.Text = 'Закрыть'
    $closeButton.Width = 92
    $closeButton.Height = 34
    $closeButton.AccessibleName = 'MenuRow'
    $buttons.Controls.Add($closeButton)

    $cancelButton = New-Object System.Windows.Forms.Button
    $cancelButton.Text = 'Снять'
    $cancelButton.Width = 86
    $cancelButton.Height = 34
    $cancelButton.AccessibleName = 'MenuRow'
    $buttons.Controls.Add($cancelButton)

    $saveButton.Add_Click({
        $selected = $datePicker.Value.Date.AddHours($timePicker.Value.Hour).AddMinutes($timePicker.Value.Minute)
        if ($selected -le (Get-Date)) {
            [System.Windows.Forms.MessageBox]::Show('Выбери дату и время в будущем.', 'Отложенный запуск', 'OK', 'Warning') | Out-Null
            return
        }

        $script:DelayedStartEnabled = $true
        $script:DelayedStartAt = $selected.ToString('s')
        $script:DelayedStartTime = $selected.ToString('HH:mm')
        $script:DelayedStartLastRunDate = ''
        Save-ProcessingState
        if ($script:DelayedStartTimer) { $script:DelayedStartTimer.Start() }
        Refresh-DelayedStartStatus
        $dialog.Close()
    })

    $cancelButton.Add_Click({
        $script:DelayedStartEnabled = $false
        $script:DelayedStartAt = ''
        Save-ProcessingState
        Refresh-DelayedStartStatus
        $dialog.Close()
    })

    $closeButton.Add_Click({ $dialog.Close() })

    try {
        $palette = if ($script:CurrentThemePalette) { $script:CurrentThemePalette } else { Get-AppThemePalette $script:UiTheme }
        Set-ControlTheme -Control $dialog -Palette $palette
        Set-WindowFrameTheme -TargetForm $dialog -Palette $palette -UseDarkMode ($script:UiTheme -in @('Карбон', 'Темная', 'Коричневая', 'Дота', 'Раст', 'Радуга', 'COURAGE'))
    }
    catch {
    }

    if ($form) {
        [void]$dialog.ShowDialog($form)
    }
    else {
        [void]$dialog.ShowDialog()
    }
    $dialog.Dispose()
}

function Apply-AppOpacity {
    if (-not $form) { return }

    if ([bool]$script:LowPerformanceMode) {
        try { $form.Opacity = 1.0 } catch {}
        return
    }

    $percent = [Math]::Max(75, [Math]::Min(100, [int]$script:AppOpacityPercent))
    $script:AppOpacityPercent = $percent
    try {
        if ($script:UiTheme -in @('Дота', 'Радуга', 'COURAGE')) {
            $form.Opacity = 1.0
            return
        }
        $form.Opacity = [Math]::Max(0.75, [Math]::Min(1.0, $percent / 100.0))
    }
    catch {
    }
}

function Reset-OneByOneStopSignal {
    $script:OneByOneCancelRequested = $false
    if ($script:OneByOneStatusLog) { $script:OneByOneStatusLog.Clear() }
    if ($script:OneByOneRecentMaxMessages) { $script:OneByOneRecentMaxMessages.Clear() }
    $script:OneByOneRecentMaxMessageKeys = @{}
    $script:OneByOneNotificationBaselineKeys = @{}
    $script:OneByOneNotificationBaselineProfiles = @{}
    $script:OneByOneLastMaxMessageScanAt = [DateTime]::MinValue
    $script:OneByOneNotificationScanCursor = 0
    if ($script:OneByOneStopSignal) {
        $script:OneByOneStopSignal.Requested = $false
        $script:OneByOneStopSignal.Paused = $false
        $script:OneByOneStopSignal.Close = $false
        $script:OneByOneStopSignal.ScanRequested = $false
        $script:OneByOneStopSignal.OpenRecordId = ""
        $script:OneByOneStopSignal.WindowStatus = ""
        $script:OneByOneStopSignal.CurrentIndex = 0
        $script:OneByOneStopSignal.TotalCount = 0
        $script:OneByOneStopSignal.CurrentContact = ""
        $script:OneByOneStopSignal.CurrentProfile = ""
        $script:OneByOneStopSignal.HistoryText = ""
        $script:OneByOneStopSignal.NotificationsEnabled = [bool]$script:NotificationWindowEnabled
    }
}

function Add-OneByOneStopLog {
    param([string]$Text)

    if (-not $script:OneByOneStopSignal -or [string]::IsNullOrWhiteSpace($Text)) { return }
    if (-not $script:OneByOneStatusLog) {
        $script:OneByOneStatusLog = New-Object System.Collections.Generic.List[string]
    }

    $line = "$(Get-Date -Format 'HH:mm:ss')  $Text"
    if ($script:OneByOneStatusLog.Count -gt 0 -and $script:OneByOneStatusLog[$script:OneByOneStatusLog.Count - 1] -eq $line) { return }

    $script:OneByOneStatusLog.Add($line)
    while ($script:OneByOneStatusLog.Count -gt 5) {
        $script:OneByOneStatusLog.RemoveAt(0)
    }
}

function Update-OneByOneRecentMaxMessagesText {
    if (-not $script:OneByOneStopSignal) { return }
    if ($script:OneByOneRecentMaxMessages -and $script:OneByOneRecentMaxMessages.Count -gt 0) {
        $cutoff = (Get-Date).AddMinutes(-15)
        for ($i = $script:OneByOneRecentMaxMessages.Count - 1; $i -ge 0; $i--) {
            $item = $script:OneByOneRecentMaxMessages[$i]
            $at = Get-Date
            try { $at = [DateTime]$item.At } catch {}
            if ($at -lt $cutoff) {
                $script:OneByOneRecentMaxMessages.RemoveAt($i)
            }
        }
    }
    if (-not $script:OneByOneRecentMaxMessages -or $script:OneByOneRecentMaxMessages.Count -eq 0) {
        $script:OneByOneStopSignal.HistoryText = 'Пока новых сообщений MAX нет'
        return
    }

    $lines = New-Object System.Collections.Generic.List[string]
    $visibleCount = [Math]::Max(1, [int]$script:OneByOneVisibleMaxMessageCount)
    $lastIndex = $script:OneByOneRecentMaxMessages.Count - 1
    $stopIndex = [Math]::Max(0, $script:OneByOneRecentMaxMessages.Count - $visibleCount)
    for ($i = $lastIndex; $i -ge $stopIndex; $i--) {
        $item = $script:OneByOneRecentMaxMessages[$i]
        $time = ''
        try { $time = ([DateTime]$item.At).ToString('HH:mm:ss') } catch { $time = (Get-Date -Format 'HH:mm:ss') }
        $profile = ([string]$item.Profile).Trim()
        $sender = ([string]$item.Sender).Trim()
        $text = ([string]$item.Text).Trim()
        if ([string]::IsNullOrWhiteSpace($profile)) { $profile = 'MAX' }
        if ([string]::IsNullOrWhiteSpace($sender)) { $sender = 'Сообщение' }
        if ([string]::IsNullOrWhiteSpace($text)) { continue }
        $line = "$time | $profile | ${sender}: $text"
        if ($line.Length -gt 220) {
            $line = $line.Substring(0, 217) + '...'
        }
        $lines.Add($line)
    }

    if ($lines.Count -eq 0) {
        $script:OneByOneStopSignal.HistoryText = 'Пока новых сообщений MAX нет'
    }
    else {
        $script:OneByOneStopSignal.HistoryText = ($lines.ToArray() -join "`r`n")
    }
}

function Add-OneByOneRecentMaxMessage {
    param(
        [string]$Profile,
        [string]$Sender,
        [string]$Text
    )

    if ([string]::IsNullOrWhiteSpace($Text)) { return $false }
    if (-not $script:OneByOneRecentMaxMessages) {
        $script:OneByOneRecentMaxMessages = New-Object System.Collections.Generic.List[object]
    }
    if ($null -eq $script:OneByOneRecentMaxMessageKeys) {
        $script:OneByOneRecentMaxMessageKeys = @{}
    }

    $profileText = ([string]$Profile).Trim()
    $senderText = ([string]$Sender).Trim()
    $messageText = (([string]$Text) -replace '\s+', ' ').Trim()
    if ([string]::IsNullOrWhiteSpace($messageText)) { return $false }
    if ($messageText.Length -gt 260) {
        $messageText = $messageText.Substring(0, 260) + '...'
    }
    if ([string]::IsNullOrWhiteSpace($profileText)) { $profileText = 'MAX' }
    if ([string]::IsNullOrWhiteSpace($senderText)) { $senderText = 'Сообщение' }

    $key = ("$profileText|$senderText|$messageText").ToLowerInvariant()
    if ($script:OneByOneRecentMaxMessageKeys.ContainsKey($key)) { return $false }

    $script:OneByOneRecentMaxMessageKeys[$key] = $true
    $script:OneByOneRecentMaxMessages.Add([pscustomobject]@{
        At = Get-Date
        Profile = $profileText
        Sender = $senderText
        Text = $messageText
    })

    while ($script:OneByOneRecentMaxMessages.Count -gt ([Math]::Max(5, [int]$script:OneByOneVisibleMaxMessageCount))) {
        $script:OneByOneRecentMaxMessages.RemoveAt(0)
    }
    if ($script:OneByOneRecentMaxMessages.Count -gt 0) {
        $newKeys = @{}
        for ($i = 0; $i -lt $script:OneByOneRecentMaxMessages.Count; $i++) {
            $item = $script:OneByOneRecentMaxMessages[$i]
            $newKeys[("$($item.Profile)|$($item.Sender)|$($item.Text)").ToLowerInvariant()] = $true
        }
        $script:OneByOneRecentMaxMessageKeys = $newKeys
    }

    Update-OneByOneRecentMaxMessagesText
    return $true
}

function Get-OneByOneNotificationKey {
    param(
        [string]$Profile,
        [string]$Sender,
        [string]$Text
    )

    $profileText = (([string]$Profile) -replace '\s+', ' ').Trim().ToLowerInvariant()
    $senderText = (([string]$Sender) -replace '\s+', ' ').Trim().ToLowerInvariant()
    $messageText = (([string]$Text) -replace '\s+', ' ').Trim().ToLowerInvariant()
    return "$profileText|$senderText|$messageText"
}

function Get-MaxNotificationTextFromTitle {
    param([string]$Title)

    $text = ([string]$Title).Trim()
    if ([string]::IsNullOrWhiteSpace($text)) { return "" }

    $count = ""
    $match = [regex]::Match($text, '[\(\[]\s*(\d{1,3})\s*[\)\]]|^\s*(\d{1,3})\s+|\s+(\d{1,3})\s*$')
    if ($match.Success) {
        foreach ($groupIndex in 1..3) {
            if ($match.Groups[$groupIndex].Success) {
                $count = $match.Groups[$groupIndex].Value
                break
            }
        }
    }

    if (-not [string]::IsNullOrWhiteSpace($count)) {
        return "Непрочитанных: $count"
    }
    if ($text -match '[•●]' -or $text -match '(?i)\bunread\b|\bnew messages?\b|непроч|новые сообщения') {
        return 'Есть уведомление MAX'
    }
    return ""
}

function Set-OneByOneStopInfo {
    param(
        [string]$Status,
        [int]$Index = 0,
        [int]$Total = 0,
        [string]$ContactName = "",
        [string]$Profile = "",
        [bool]$AddLog = $true
    )

    if (-not $script:OneByOneStopSignal) { return }

    if (-not [string]::IsNullOrWhiteSpace($Status)) {
        $script:OneByOneStopSignal.WindowStatus = $Status
    }
    if ($Index -gt 0) { $script:OneByOneStopSignal.CurrentIndex = $Index }
    if ($Total -gt 0) { $script:OneByOneStopSignal.TotalCount = $Total }
    if (-not [string]::IsNullOrWhiteSpace($ContactName)) { $script:OneByOneStopSignal.CurrentContact = $ContactName }
    if (-not [string]::IsNullOrWhiteSpace($Profile)) { $script:OneByOneStopSignal.CurrentProfile = $Profile }
    # HistoryText is reserved for MAX notifications, not program actions.
}

function Set-MaxitochkaProgressStatus {
    param(
        [string]$Text,
        [int]$Index = 0,
        [int]$Total = 0,
        [string]$ContactName = "",
        [string]$Profile = "",
        [bool]$AddLog = $true
    )

    if ($maxitochkaStatusLabel) {
        $maxitochkaStatusLabel.Text = $Text
    }
    Set-OneByOneStopInfo -Status $Text -Index $Index -Total $Total -ContactName $ContactName -Profile $Profile -AddLog $AddLog
    try { Invoke-AnswerWindowMaintenance } catch {}
}

function Test-OneByOneStopRequested {
    if ($script:OneByOneStopSignal -and [bool]$script:OneByOneStopSignal.ScanRequested) {
        $script:OneByOneStopSignal.ScanRequested = $false
        try {
            [void](Update-OneByOneRecentMaxMessages -IntervalSeconds ([Math]::Max(1, [int]$script:OneByOneNotificationScanIntervalSeconds)))
        }
        catch {
        }
    }

    if ($script:OneByOneStopSignal -and [bool]$script:OneByOneStopSignal.Requested) {
        if (-not $script:OneByOneCancelRequested) {
            $script:OneByOneCancelRequested = $true
            Update-OneByOneButtonState
            if ($maxitochkaStatusLabel) {
                $maxitochkaStatusLabel.Text = 'Стоп принят: доделываю текущего человека и остановлюсь.'
            }
        }
    }

    return [bool]$script:OneByOneCancelRequested
}

function Update-OneByOneButtonState {
    $palette = if ($script:CurrentThemePalette) { $script:CurrentThemePalette } else { Get-AppThemePalette $script:UiTheme }
    $wallpaperEnabled = Test-AppWallpaperEnabled

    if ($autoOneByOneButton) {
        $autoOneByOneButton.Text = 'Старт'
        $autoOneByOneButton.Enabled = -not [bool]$script:OneByOneRunning
        $autoOneByOneButton.FlatAppearance.BorderSize = 0
        $autoOneByOneButton.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 9.5)
        Set-ControlBackColorSafe -Control $autoOneByOneButton -Color $(if ($wallpaperEnabled) { Convert-HtmlColorWithAlpha $palette.Accent 218 } else { Convert-HtmlColor $palette.Accent }) -FallbackColor (Convert-HtmlColor $palette.Accent)
        $autoOneByOneButton.ForeColor = Convert-HtmlColor $(if ($palette.AccentText) { $palette.AccentText } else { $palette.Text })
    }

    if ($cancelOneByOneButton) {
        $cancelOneByOneButton.Text = if ($script:OneByOneCancelRequested) { 'Остановка...' } else { 'Стоп' }
        $cancelOneByOneButton.Enabled = [bool]$script:OneByOneRunning -and -not [bool]$script:OneByOneCancelRequested
        $cancelOneByOneButton.FlatAppearance.BorderSize = 0
        $cancelOneByOneButton.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 9.5)
        Set-ControlBackColorSafe -Control $cancelOneByOneButton -Color $(if ($wallpaperEnabled) { Convert-HtmlColorWithAlpha $palette.Danger 190 } else { Convert-HtmlColor $palette.Danger }) -FallbackColor (Convert-HtmlColor $palette.Danger)
        $cancelOneByOneButton.ForeColor = Convert-HtmlColor $(if ($palette.AccentText) { $palette.AccentText } else { $palette.Text })
    }
}

function Request-OneByOneStop {
    if (-not $script:OneByOneRunning -or (Test-OneByOneStopRequested)) { return }

    $script:OneByOneCancelRequested = $true
    if ($script:OneByOneStopSignal) {
        $script:OneByOneStopSignal.Requested = $true
        $script:OneByOneStopSignal.Paused = $false
        Set-OneByOneStopInfo -Status 'Стоп принят: доделываю текущего человека'
    }
    Update-OneByOneButtonState
    if ($maxitochkaStatusLabel) {
        $maxitochkaStatusLabel.Text = 'Стоп принят: доделываю текущего человека и остановлюсь.'
    }
    [System.Windows.Forms.Application]::DoEvents()
}

function Request-OneByOnePause {
    if (-not $script:OneByOneRunning -or (Test-OneByOneStopRequested)) { return }

    if ($script:OneByOneStopSignal) {
        $script:OneByOneStopSignal.Paused = $true
        Set-OneByOneStopInfo -Status 'Пауза принята: остановлюсь на ближайшем безопасном месте'
    }
    if ($maxitochkaStatusLabel) {
        $maxitochkaStatusLabel.Text = 'Пауза принята: остановлюсь на ближайшем безопасном месте.'
    }
    [System.Windows.Forms.Application]::DoEvents()
}

function Request-OneByOneResume {
    if (-not $script:OneByOneRunning) { return }
    if ($script:OneByOneStopSignal) {
        $script:OneByOneStopSignal.Paused = $false
        Set-OneByOneStopInfo -Status 'Продолжаю работу'
    }
    if ($maxitochkaStatusLabel) {
        $maxitochkaStatusLabel.Text = 'Продолжаю работу.'
    }
    [System.Windows.Forms.Application]::DoEvents()
}

function Test-OneByOnePaused {
    return [bool]($script:OneByOneStopSignal -and [bool]$script:OneByOneStopSignal.Paused -and -not [bool]$script:OneByOneStopSignal.Requested)
}

function Wait-OneByOneIfPaused {
    param([string]$Status = 'Пауза')

    if (-not (Test-OneByOnePaused)) { return $false }

    Set-OneByOneStopInfo -Status $Status
    if ($maxitochkaStatusLabel) {
        $maxitochkaStatusLabel.Text = $Status
    }
    while ((Test-OneByOnePaused) -and -not (Test-OneByOneStopRequested)) {
        try { [void](Update-OneByOneRecentMaxMessages -IntervalSeconds ([Math]::Max(1, [int]$script:OneByOneNotificationScanIntervalSeconds))) } catch {}
        [System.Windows.Forms.Application]::DoEvents()
        Start-Sleep -Milliseconds 250
    }
    if (Test-OneByOneStopRequested) { return $true }

    Set-OneByOneStopInfo -Status 'Продолжаю работу'
    if ($maxitochkaStatusLabel) {
        $maxitochkaStatusLabel.Text = 'Продолжаю работу.'
    }
    [System.Windows.Forms.Application]::DoEvents()
    return $false
}

function Show-OneByOneStopWindow {
    if ($NoGui) { return }
    if ($script:OneByOneStopAsync -and $script:OneByOneStopAsync.IsCompleted) {
        Close-OneByOneStopWindow
    }
    if ($script:OneByOneStopPowerShell -or $script:OneByOneStopRunspace) {
        if ($script:OneByOneStopSignal) { $script:OneByOneStopSignal.ScanRequested = $true }
        return
    }

    if (-not $script:OneByOneStopSignal) {
        $script:OneByOneStopSignal = [hashtable]::Synchronized(@{ Requested = $false; Paused = $false; Close = $false; ScanRequested = $false; OpenRecordId = ""; WindowStatus = "" })
    }
    $script:OneByOneStopSignal.Close = $false
    $script:OneByOneStopSignal.ScanRequested = $true

    $runspace = [runspacefactory]::CreateRunspace()
    $runspace.ApartmentState = 'STA'
    $runspace.ThreadOptions = 'ReuseThread'
    $runspace.Open()

    $ps = [powershell]::Create()
    $ps.Runspace = $runspace
    [void]$ps.AddScript({
        param($Signal, $RepliesPath)

        Add-Type -AssemblyName System.Windows.Forms
        Add-Type -AssemblyName System.Drawing

        [System.Windows.Forms.Application]::EnableVisualStyles()

        function Get-ReplyItems {
            if ([string]::IsNullOrWhiteSpace($RepliesPath) -or -not (Test-Path -LiteralPath $RepliesPath)) { return @() }
            try {
                $raw = Get-Content -Raw -Encoding UTF8 -LiteralPath $RepliesPath
                if ([string]::IsNullOrWhiteSpace($raw)) { return @() }
                $parsed = $raw | ConvertFrom-Json
                $items = if ($parsed -is [System.Array]) { $parsed } else { @($parsed) }
                return @($items | Where-Object {
                    [string]$_.replyStatus -eq 'есть ответ' -and -not [string]::IsNullOrWhiteSpace([string]$_.lastReplyText)
                } | Sort-Object lastCheckedAt, createdAt -Descending)
            }
            catch {
                return @()
            }
        }

        function Set-ListItems {
            param($ListView, $DetailsBox, $CountLabel)

            $selectedId = ""
            if ($ListView.SelectedItems.Count -gt 0) {
                $selectedId = [string]$ListView.SelectedItems[0].Tag
            }

            $items = @(Get-ReplyItems)
            $ListView.BeginUpdate()
            try {
                $ListView.Items.Clear()
                foreach ($record in $items) {
                    $maxName = if ([string]::IsNullOrWhiteSpace([string]$record.profile)) { 'MAX' } else { [string]$record.profile }
                    $person = if ([string]::IsNullOrWhiteSpace([string]$record.contactName)) { [string]$record.groupName } else { [string]$record.contactName }
                    $reply = [string]$record.lastReplyText
                    $row = New-Object System.Windows.Forms.ListViewItem($maxName)
                    [void]$row.SubItems.Add($person)
                    [void]$row.SubItems.Add($reply)
                    $row.Tag = [string]$record.id
                    $row.ToolTipText = $reply
                    [void]$ListView.Items.Add($row)
                    if (-not [string]::IsNullOrWhiteSpace($selectedId) -and $selectedId -eq [string]$record.id) {
                        $row.Selected = $true
                    }
                }
            }
            finally {
                $ListView.EndUpdate()
            }

            $CountLabel.Text = "Ответов: $($items.Count)"
            if ($ListView.SelectedItems.Count -eq 0 -and $items.Count -gt 0) {
                $ListView.Items[0].Selected = $true
            }
            if ($ListView.SelectedItems.Count -gt 0) {
                $id = [string]$ListView.SelectedItems[0].Tag
                $record = @($items | Where-Object { [string]$_.id -eq $id } | Select-Object -First 1)
                if ($record.Count -gt 0) {
                    $DetailsBox.Text = "MAX: $($record[0].profile)`r`nКто: $($record[0].contactName)`r`n`r`n$($record[0].lastReplyText)"
                }
            }
            elseif ($items.Count -eq 0) {
                $DetailsBox.Text = "Ответов пока нет."
            }
        }

        $form = New-Object System.Windows.Forms.Form
        $form.Text = 'Стоп и ответы'
        $form.StartPosition = 'Manual'
        $form.FormBorderStyle = 'SizableToolWindow'
        $form.TopMost = $true
        $form.ShowInTaskbar = $false
        $form.MinimumSize = New-Object System.Drawing.Size(560, 400)
        $form.Size = New-Object System.Drawing.Size(720, 540)
        $form.BackColor = [System.Drawing.Color]::FromArgb(22, 23, 30)
        try { $form.Opacity = 0.97 } catch {}
        $screen = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
        $form.Location = New-Object System.Drawing.Point -ArgumentList ([int]($screen.Right - $form.Width - 24)), ([int]($screen.Top + 70))

        $layout = New-Object System.Windows.Forms.TableLayoutPanel
        $layout.Dock = 'Fill'
        $layout.ColumnCount = 1
        $layout.RowCount = 6
        $layout.Padding = New-Object System.Windows.Forms.Padding(10)
        $layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 36))) | Out-Null
        $layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 48))) | Out-Null
        $layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 28))) | Out-Null
        $layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 62))) | Out-Null
        $layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 38))) | Out-Null
        $layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 42))) | Out-Null
        $form.Controls.Add($layout)

        $header = New-Object System.Windows.Forms.TableLayoutPanel
        $header.Dock = 'Fill'
        $header.ColumnCount = 2
        $header.RowCount = 1
        $header.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
        $header.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 120))) | Out-Null
        $layout.Controls.Add($header, 0, 0)

        $title = New-Object System.Windows.Forms.Label
        $title.Text = 'Ответы MAX'
        $title.Dock = 'Fill'
        $title.TextAlign = 'MiddleLeft'
        $title.ForeColor = [System.Drawing.Color]::White
        $title.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 12)
        $header.Controls.Add($title, 0, 0)

        $hint = New-Object System.Windows.Forms.Label
        $hint.Text = 'двойной клик - чат'
        $hint.Dock = 'Fill'
        $hint.TextAlign = 'MiddleRight'
        $hint.ForeColor = [System.Drawing.Color]::FromArgb(155, 160, 180)
        $hint.Font = New-Object System.Drawing.Font('Segoe UI', 8)
        $header.Controls.Add($hint, 1, 0)

        $stopPanel = New-Object System.Windows.Forms.TableLayoutPanel
        $stopPanel.Dock = 'Fill'
        $stopPanel.ColumnCount = 2
        $stopPanel.RowCount = 1
        $stopPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 156))) | Out-Null
        $stopPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
        $stopPanel.BackColor = [System.Drawing.Color]::FromArgb(28, 29, 38)
        $stopPanel.Padding = New-Object System.Windows.Forms.Padding(8, 6, 8, 6)
        $layout.Controls.Add($stopPanel, 0, 1)

        $button = New-Object System.Windows.Forms.Button
        $button.Text = 'СТОП'
        $button.Dock = 'Fill'
        $button.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 11)
        $button.BackColor = [System.Drawing.Color]::FromArgb(64, 42, 50)
        $button.ForeColor = [System.Drawing.Color]::White
        $button.FlatStyle = 'Flat'
        $button.FlatAppearance.BorderSize = 1
        $button.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(165, 92, 105)
        $stopPanel.Controls.Add($button, 0, 0)

        $stopHint = New-Object System.Windows.Forms.Label
        $stopHint.Text = 'остановка после текущего человека'
        $stopHint.Dock = 'Fill'
        $stopHint.TextAlign = 'MiddleLeft'
        $stopHint.Padding = New-Object System.Windows.Forms.Padding(14, 0, 0, 0)
        $stopHint.ForeColor = [System.Drawing.Color]::FromArgb(170, 176, 194)
        $stopHint.Font = New-Object System.Drawing.Font('Segoe UI', 9)
        $stopPanel.Controls.Add($stopHint, 1, 0)

        $label = New-Object System.Windows.Forms.Label
        $label.Text = 'Остановит после текущего человека'
        $label.Dock = 'Fill'
        $label.TextAlign = 'MiddleLeft'
        $label.ForeColor = [System.Drawing.Color]::FromArgb(215, 218, 230)
        $label.Font = New-Object System.Drawing.Font('Segoe UI', 9)
        $layout.Controls.Add($label, 0, 2)

        $list = New-Object System.Windows.Forms.ListView
        $list.Dock = 'Fill'
        $list.View = 'Details'
        $list.FullRowSelect = $true
        $list.HideSelection = $false
        $list.GridLines = $false
        $list.BorderStyle = 'FixedSingle'
        $list.BackColor = [System.Drawing.Color]::FromArgb(17, 18, 24)
        $list.ForeColor = [System.Drawing.Color]::White
        $list.Font = New-Object System.Drawing.Font('Segoe UI', 9)
        [void]$list.Columns.Add('MAX', 96)
        [void]$list.Columns.Add('Кто', 170)
        [void]$list.Columns.Add('Ответ', 360)
        $layout.Controls.Add($list, 0, 3)
        $resizeListColumns = {
            try {
                $list.Columns[0].Width = 104
                $list.Columns[1].Width = [Math]::Max(170, [int]($list.ClientSize.Width * 0.30))
                $list.Columns[2].Width = [Math]::Max(220, $list.ClientSize.Width - $list.Columns[0].Width - $list.Columns[1].Width - 8)
            }
            catch {
            }
        }
        $list.Add_SizeChanged($resizeListColumns)

        $details = New-Object System.Windows.Forms.TextBox
        $details.Dock = 'Fill'
        $details.Multiline = $true
        $details.ScrollBars = 'Vertical'
        $details.ReadOnly = $true
        $details.BackColor = [System.Drawing.Color]::FromArgb(17, 18, 24)
        $details.ForeColor = [System.Drawing.Color]::White
        $details.BorderStyle = 'FixedSingle'
        $details.Font = New-Object System.Drawing.Font('Segoe UI', 9)
        $layout.Controls.Add($details, 0, 4)

        $bottom = New-Object System.Windows.Forms.TableLayoutPanel
        $bottom.Dock = 'Fill'
        $bottom.ColumnCount = 3
        $bottom.RowCount = 1
        $bottom.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 130))) | Out-Null
        $bottom.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
        $bottom.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 130))) | Out-Null
        $layout.Controls.Add($bottom, 0, 5)

        $refresh = New-Object System.Windows.Forms.Button
        $refresh.Text = 'Обновить'
        $refresh.Dock = 'Fill'
        $refresh.FlatStyle = 'Flat'
        $refresh.BackColor = [System.Drawing.Color]::FromArgb(42, 45, 58)
        $refresh.ForeColor = [System.Drawing.Color]::White
        $refresh.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(76, 82, 104)
        $bottom.Controls.Add($refresh, 0, 0)

        $countLabel = New-Object System.Windows.Forms.Label
        $countLabel.Text = 'Ответов: 0'
        $countLabel.Dock = 'Fill'
        $countLabel.TextAlign = 'MiddleLeft'
        $countLabel.ForeColor = [System.Drawing.Color]::Gainsboro
        $bottom.Controls.Add($countLabel, 1, 0)

        $open = New-Object System.Windows.Forms.Button
        $open.Text = 'В чат'
        $open.Dock = 'Fill'
        $open.FlatStyle = 'Flat'
        $open.BackColor = [System.Drawing.Color]::FromArgb(136, 93, 214)
        $open.ForeColor = [System.Drawing.Color]::White
        $open.FlatAppearance.BorderSize = 0
        $bottom.Controls.Add($open, 2, 0)

        $stopAction = {
            $Signal.Requested = $true
            $button.Text = 'ОСТАНОВКА...'
            $button.Enabled = $false
            $label.Text = 'Сигнал принят'
        }
        $openAction = {
            if ($list.SelectedItems.Count -gt 0) {
                $Signal.OpenRecordId = [string]$list.SelectedItems[0].Tag
                $label.Text = 'Открываю выбранный чат...'
            }
        }
        $button.Add_MouseDown($stopAction)
        $button.Add_Click($stopAction)
        $refresh.Add_Click({
            $Signal.ScanRequested = $true
            $label.Text = 'Запрошено обновление ответов...'
        })
        $open.Add_Click($openAction)
        $list.Add_DoubleClick($openAction)
        $list.Add_SelectedIndexChanged({
            if ($list.SelectedItems.Count -gt 0) {
                $items = @(Get-ReplyItems)
                $id = [string]$list.SelectedItems[0].Tag
                $record = @($items | Where-Object { [string]$_.id -eq $id } | Select-Object -First 1)
                if ($record.Count -gt 0) {
                    $details.Text = "MAX: $($record[0].profile)`r`nКто: $($record[0].contactName)`r`n`r`n$($record[0].lastReplyText)"
                }
            }
        })
        $form.Add_KeyDown({
            param($sender, $eventArgs)
            if ($eventArgs.KeyCode -eq [System.Windows.Forms.Keys]::Escape) {
                & $stopAction
                $eventArgs.Handled = $true
            }
        })
        $form.KeyPreview = $true

        $timer = New-Object System.Windows.Forms.Timer
        $timer.Interval = 500
        $timer.Add_Tick({
            try {
                if ([bool]$Signal.Close) {
                    $timer.Stop()
                    $form.Close()
                    return
                }
                if ([bool]$Signal.Requested) {
                    $button.Text = 'ОСТАНОВКА...'
                    $button.Enabled = $false
                    $label.Text = 'Сигнал принят'
                }
                else {
                    if (-not $button.Enabled) {
                        $button.Text = 'СТОП'
                        $button.Enabled = $true
                    }
                    if (-not [string]::IsNullOrWhiteSpace([string]$Signal.WindowStatus)) {
                        $label.Text = [string]$Signal.WindowStatus
                    }
                }
                Set-ListItems -ListView $list -DetailsBox $details -CountLabel $countLabel
            }
            catch {
            }
        })
        $timer.Start()
        Set-ListItems -ListView $list -DetailsBox $details -CountLabel $countLabel
        & $resizeListColumns
        $form.Add_Shown({
            try {
                $darkMode = 1
                [MaxContactWin32]::DwmSetWindowAttribute($form.Handle, 20, [ref]$darkMode, 4) | Out-Null
            }
            catch {
            }
        })

        [void]$form.ShowDialog()
        $timer.Dispose()
        $form.Dispose()
    }).AddArgument($script:OneByOneStopSignal).AddArgument($script:RepliesPath)

    $script:OneByOneStopPowerShell = $ps
    $script:OneByOneStopRunspace = $runspace
    $script:OneByOneStopAsync = $ps.BeginInvoke()
}

function Close-OneByOneStopWindow {
    if ($script:OneByOneStopSignal) {
        $script:OneByOneStopSignal.Close = $true
    }

    if ($script:OneByOneStopPowerShell) {
        try {
            if ($script:OneByOneStopAsync) {
                [void]$script:OneByOneStopPowerShell.EndInvoke($script:OneByOneStopAsync)
            }
        }
        catch {
        }
        try { $script:OneByOneStopPowerShell.Dispose() } catch {}
    }
    if ($script:OneByOneStopRunspace) {
        try { $script:OneByOneStopRunspace.Close() } catch {}
        try { $script:OneByOneStopRunspace.Dispose() } catch {}
    }

    $script:OneByOneStopPowerShell = $null
    $script:OneByOneStopRunspace = $null
    $script:OneByOneStopAsync = $null
}

function Show-OneByOneStopWindow {
    if ($NoGui) { return }
    if (($script:OneByOneStopSignal -and [bool]$script:OneByOneStopSignal.Close) -or ($script:OneByOneStopAsync -and $script:OneByOneStopAsync.IsCompleted)) {
        Close-OneByOneStopWindow
    }
    if ($script:OneByOneStopPowerShell -or $script:OneByOneStopRunspace) {
        if ($script:OneByOneStopSignal) {
            $script:OneByOneStopSignal.NotificationsEnabled = [bool]$script:NotificationWindowEnabled
        }
        return
    }

    if (-not $script:OneByOneStopSignal) {
        $script:OneByOneStopSignal = [hashtable]::Synchronized(@{ Requested = $false; Paused = $false; Close = $false; ScanRequested = $false; OpenRecordId = ""; WindowStatus = ""; CurrentIndex = 0; TotalCount = 0; CurrentContact = ""; CurrentProfile = ""; HistoryText = ""; NotificationsEnabled = $true })
    }
    $script:OneByOneStopSignal.Close = $false
    $script:OneByOneStopSignal.NotificationsEnabled = [bool]$script:NotificationWindowEnabled
    $palette = Get-AppThemePalette $script:UiTheme
    $useDarkFrame = ($script:UiTheme -in @('Карбон', 'Темная', 'Коричневая', 'Дота', 'Раст', 'Радуга', 'COURAGE'))

    $runspace = [runspacefactory]::CreateRunspace()
    $runspace.ApartmentState = 'STA'
    $runspace.ThreadOptions = 'ReuseThread'
    $runspace.Open()

    $ps = [powershell]::Create()
    $ps.Runspace = $runspace
    $mainWindowHandle = if ($form) { $form.Handle } else { [IntPtr]::Zero }
    [void]$ps.AddScript({
        param($Signal, $Palette, $UseDarkFrame, [IntPtr]$MainWindowHandle)

        Add-Type -AssemblyName System.Windows.Forms
        Add-Type -AssemblyName System.Drawing
        [System.Windows.Forms.Application]::EnableVisualStyles()

        function Convert-ThemeColor {
            param([string]$Color, [System.Drawing.Color]$Fallback)
            try {
                if ([string]::IsNullOrWhiteSpace($Color)) { return $Fallback }
                return [System.Drawing.ColorTranslator]::FromHtml($Color)
            }
            catch {
                return $Fallback
            }
        }

        $formColor = Convert-ThemeColor ([string]$Palette.Form) ([System.Drawing.Color]::FromArgb(18, 18, 18))
        $panelColor = Convert-ThemeColor ([string]$Palette.Panel) ([System.Drawing.Color]::FromArgb(42, 42, 42))
        $inputColor = Convert-ThemeColor ([string]$Palette.Input) ([System.Drawing.Color]::FromArgb(24, 24, 24))
        $textColor = Convert-ThemeColor ([string]$Palette.Text) ([System.Drawing.Color]::White)
        $mutedColor = Convert-ThemeColor ([string]$Palette.Muted) ([System.Drawing.Color]::Gainsboro)
        $buttonTextColor = [System.Drawing.Color]::FromArgb(10, 12, 10)
        $startColor = [System.Drawing.Color]::FromArgb(48, 142, 86)
        $startHoverColor = [System.Drawing.Color]::FromArgb(60, 160, 101)
        $startDownColor = [System.Drawing.Color]::FromArgb(40, 122, 73)
        $pauseColor = [System.Drawing.Color]::FromArgb(178, 137, 48)
        $pauseHoverColor = [System.Drawing.Color]::FromArgb(196, 153, 60)
        $pauseDownColor = [System.Drawing.Color]::FromArgb(150, 114, 39)
        $stopColor = [System.Drawing.Color]::FromArgb(190, 174, 131)
        $stopHoverColor = [System.Drawing.Color]::FromArgb(207, 191, 147)
        $stopDownColor = [System.Drawing.Color]::FromArgb(166, 151, 112)

        function Set-CommandButtonStyle {
            param(
                [System.Windows.Forms.Button]$Target,
                [System.Drawing.Color]$Back,
                [System.Drawing.Color]$Hover,
                [System.Drawing.Color]$Down
            )

            if ($null -eq $Target) { return }
            $Target.BackColor = $Back
            $Target.ForeColor = $buttonTextColor
            $Target.FlatStyle = 'Flat'
            $Target.UseVisualStyleBackColor = $false
            $Target.FlatAppearance.BorderSize = 0
            $Target.FlatAppearance.MouseOverBackColor = $Hover
            $Target.FlatAppearance.MouseDownBackColor = $Down
            $Target.Cursor = [System.Windows.Forms.Cursors]::Hand
        }

        $form = New-Object System.Windows.Forms.Form
        $form.Text = 'Управление'
        $form.StartPosition = 'Manual'
        $form.FormBorderStyle = 'SizableToolWindow'
        $form.TopMost = $true
        $form.ShowInTaskbar = $false
        $form.MinimumSize = New-Object System.Drawing.Size(560, 310)
        $form.Size = New-Object System.Drawing.Size(640, 340)
        $form.BackColor = $formColor
        $form.ForeColor = $textColor
        try {
            $screen = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
            $form.Location = New-Object System.Drawing.Point -ArgumentList ([int]($screen.Right - $form.Width - 24)), ([int]($screen.Top + 70))
        }
        catch {
            $form.StartPosition = 'CenterScreen'
        }

        $layout = New-Object System.Windows.Forms.TableLayoutPanel
        $layout.Dock = 'Fill'
        $layout.ColumnCount = 1
        $layout.RowCount = 5
        $layout.Padding = New-Object System.Windows.Forms.Padding(12)
        $layout.BackColor = $formColor
        $layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 62))) | Out-Null
        $layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 30))) | Out-Null
        $layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 60))) | Out-Null
        $layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 24))) | Out-Null
        $layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
        $form.Controls.Add($layout)

        $buttonPanel = New-Object System.Windows.Forms.TableLayoutPanel
        $buttonPanel.Dock = 'Fill'
        $buttonPanel.ColumnCount = 3
        $buttonPanel.RowCount = 1
        $buttonPanel.BackColor = $formColor
        $buttonPanel.Margin = New-Object System.Windows.Forms.Padding(0)
        $buttonPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 34))) | Out-Null
        $buttonPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 33))) | Out-Null
        $buttonPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 33))) | Out-Null
        $layout.Controls.Add($buttonPanel, 0, 0)

        $startButton = New-Object System.Windows.Forms.Button
        $startButton.Text = 'СТАРТ'
        $startButton.Dock = 'Fill'
        $startButton.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 11)
        $startButton.Margin = New-Object System.Windows.Forms.Padding(0, 0, 6, 0)
        Set-CommandButtonStyle -Target $startButton -Back $startColor -Hover $startHoverColor -Down $startDownColor
        $buttonPanel.Controls.Add($startButton, 0, 0)

        $pauseButton = New-Object System.Windows.Forms.Button
        $pauseButton.Text = 'ПАУЗА'
        $pauseButton.Dock = 'Fill'
        $pauseButton.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 11)
        $pauseButton.Margin = New-Object System.Windows.Forms.Padding(0, 0, 6, 0)
        Set-CommandButtonStyle -Target $pauseButton -Back $pauseColor -Hover $pauseHoverColor -Down $pauseDownColor
        $buttonPanel.Controls.Add($pauseButton, 1, 0)

        $button = New-Object System.Windows.Forms.Button
        $button.Text = 'СТОП'
        $button.Dock = 'Fill'
        $button.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 11)
        $button.Margin = New-Object System.Windows.Forms.Padding(0)
        Set-CommandButtonStyle -Target $button -Back $stopColor -Hover $stopHoverColor -Down $stopDownColor
        $buttonPanel.Controls.Add($button, 2, 0)

        $label = New-Object System.Windows.Forms.Label
        $label.Text = 'Остановит после текущего человека'
        $label.Dock = 'Fill'
        $label.TextAlign = 'MiddleLeft'
        $label.ForeColor = $textColor
        $label.BackColor = $formColor
        $label.Font = New-Object System.Drawing.Font('Segoe UI', 9)
        $layout.Controls.Add($label, 0, 1)

        $current = New-Object System.Windows.Forms.Label
        $current.Text = 'Человек: -'
        $current.Dock = 'Fill'
        $current.TextAlign = 'MiddleLeft'
        $current.ForeColor = $textColor
        $current.BackColor = $panelColor
        $current.Padding = New-Object System.Windows.Forms.Padding(10, 0, 10, 0)
        $current.Font = New-Object System.Drawing.Font('Segoe UI', 9)
        $layout.Controls.Add($current, 0, 2)

        $historyTitle = New-Object System.Windows.Forms.Label
        $historyTitle.Text = 'Последние 5 сообщений MAX'
        $historyTitle.Dock = 'Fill'
        $historyTitle.TextAlign = 'MiddleLeft'
        $historyTitle.ForeColor = $mutedColor
        $historyTitle.BackColor = $formColor
        $historyTitle.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 8.5)
        $layout.Controls.Add($historyTitle, 0, 3)

        $status = New-Object System.Windows.Forms.ListBox
        $status.Dock = 'Fill'
        $status.BorderStyle = 'FixedSingle'
        $status.BackColor = $inputColor
        $status.ForeColor = $textColor
        $status.Font = New-Object System.Drawing.Font('Segoe UI', 8.75)
        $status.HorizontalScrollbar = $false
        $status.IntegralHeight = $false
        $layout.Controls.Add($status, 0, 4)

        $script:StopWindowNotificationsVisible = $null
        $applyNotificationsVisibility = {
            $visible = [bool]$Signal.NotificationsEnabled
            if ($null -ne $script:StopWindowNotificationsVisible -and [bool]$script:StopWindowNotificationsVisible -eq $visible) { return }
            $script:StopWindowNotificationsVisible = $visible

            $historyTitle.Visible = $visible
            $status.Visible = $visible
            if ($visible) {
                $layout.RowStyles[3].SizeType = [System.Windows.Forms.SizeType]::Absolute
                $layout.RowStyles[3].Height = 24
                $layout.RowStyles[4].SizeType = [System.Windows.Forms.SizeType]::Percent
                $layout.RowStyles[4].Height = 100
                $form.MinimumSize = New-Object System.Drawing.Size(560, 310)
                if ($form.Height -lt 310) {
                    $form.Size = New-Object System.Drawing.Size([Math]::Max(640, $form.Width), 340)
                }
            }
            else {
                $layout.RowStyles[3].SizeType = [System.Windows.Forms.SizeType]::Absolute
                $layout.RowStyles[3].Height = 0
                $layout.RowStyles[4].SizeType = [System.Windows.Forms.SizeType]::Absolute
                $layout.RowStyles[4].Height = 0
                $form.MinimumSize = New-Object System.Drawing.Size(420, 188)
                if ($form.Height -gt 230) {
                    $form.Size = New-Object System.Drawing.Size([Math]::Max(500, $form.Width), 210)
                }
            }
            $layout.PerformLayout()
        }
        & $applyNotificationsVisibility

        $stopAction = {
            if ([bool]$Signal.Requested) { return }
            $Signal.Requested = $true
            $Signal.Paused = $false
            $button.Text = 'ОСТАНОВКА...'
            $label.Text = 'Сигнал принят'
        }
        $pauseAction = {
            if ([bool]$Signal.Requested -or [bool]$Signal.Paused) { return }
            $Signal.Paused = $true
            $pauseButton.Text = 'ПАУЗА...'
            $label.Text = 'Пауза: жду безопасного места'
        }
        $startAction = {
            if ([bool]$Signal.Requested -or -not [bool]$Signal.Paused) { return }
            $Signal.Paused = $false
            $pauseButton.Text = 'ПАУЗА'
            $label.Text = 'Работа продолжается'
        }
        $button.Add_MouseDown($stopAction)
        $button.Add_Click($stopAction)
        $pauseButton.Add_MouseDown($pauseAction)
        $pauseButton.Add_Click($pauseAction)
        $startButton.Add_MouseDown($startAction)
        $startButton.Add_Click($startAction)
        $form.Add_KeyDown({
            param($sender, $eventArgs)
            if ($eventArgs.KeyCode -eq [System.Windows.Forms.Keys]::Escape) {
                & $stopAction
                $eventArgs.Handled = $true
            }
        })
        $form.KeyPreview = $true
        $form.Add_FormClosed({
            try {
                $Signal.Close = $true
                if ($MainWindowHandle -ne [IntPtr]::Zero -and ('MaxContactWin32' -as [type])) {
                    [MaxContactWin32]::ShowWindowAsync($MainWindowHandle, 9) | Out-Null
                    [MaxContactWin32]::SetForegroundWindow($MainWindowHandle) | Out-Null
                }
            }
            catch {
            }
        })

        $timer = New-Object System.Windows.Forms.Timer
        $timer.Interval = 500
        $timer.Add_Tick({
            try {
                if ([bool]$Signal.Close) {
                    $timer.Stop()
                    $form.Close()
                    return
                }
                if ([bool]$Signal.Requested) {
                    $button.Text = 'ОСТАНОВКА...'
                    $label.Text = 'Сигнал принят'
                }
                elseif ([bool]$Signal.Paused) {
                    $button.Text = 'СТОП'
                    $pauseButton.Text = 'ПАУЗА...'
                    $label.Text = 'Пауза: нажми СТАРТ для продолжения'
                }
                else {
                    $button.Text = 'СТОП'
                    $pauseButton.Text = 'ПАУЗА'
                    $label.Text = 'Остановит после текущего человека'
                }
                & $applyNotificationsVisibility
                if (-not [string]::IsNullOrWhiteSpace([string]$Signal.WindowStatus)) {
                    $index = 0
                    $total = 0
                    try { $index = [int]$Signal.CurrentIndex } catch {}
                    try { $total = [int]$Signal.TotalCount } catch {}
                    $profile = [string]$Signal.CurrentProfile
                    $contact = [string]$Signal.CurrentContact
                    $position = if ($index -gt 0 -and $total -gt 0) { "$index/$total" } elseif ($index -gt 0) { [string]$index } else { "-" }
                    if ([string]::IsNullOrWhiteSpace($profile)) { $profile = '-' }
                    if ([string]::IsNullOrWhiteSpace($contact)) { $contact = '-' }
                    $current.Text = "Сейчас: $position | MAX: $profile`r`nЧеловек: $contact"
                }
                if ([bool]$Signal.NotificationsEnabled) {
                    $Signal.ScanRequested = $true
                    $history = [string]$Signal.HistoryText
                    if ([string]::IsNullOrWhiteSpace($history)) {
                        $history = 'Пока новых сообщений MAX нет'
                    }
                    $incomingLines = @([System.Text.RegularExpressions.Regex]::Split($history, '\r\n|\n|\r') | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) })
                    if ($incomingLines.Count -eq 0) {
                        $incomingLines = @('Пока новых сообщений MAX нет')
                    }
                    $currentLines = New-Object System.Collections.Generic.List[string]
                    foreach ($item in $status.Items) {
                        $currentLines.Add([string]$item) | Out-Null
                    }
                    $currentText = ($currentLines.ToArray() -join "`n")
                    $incomingText = ($incomingLines -join "`n")
                    if ($currentText -ne $incomingText) {
                        $status.BeginUpdate()
                        try {
                            $status.Items.Clear()
                            foreach ($line in $incomingLines) {
                                [void]$status.Items.Add([string]$line)
                            }
                            $status.ClearSelected()
                        }
                        finally {
                            $status.EndUpdate()
                        }
                    }
                }
            }
            catch {
            }
        })
        $timer.Start()

        $form.Add_Shown({
            try {
                if ($UseDarkFrame -and ('MaxContactWin32' -as [type])) {
                    $darkMode = 1
                    [MaxContactWin32]::DwmSetWindowAttribute($form.Handle, 20, [ref]$darkMode, 4) | Out-Null
                }
            }
            catch {
            }
        })

        [void]$form.ShowDialog()
        $timer.Dispose()
        $form.Dispose()
    }).AddArgument($script:OneByOneStopSignal).AddArgument($palette).AddArgument($useDarkFrame).AddArgument($mainWindowHandle)

    $script:OneByOneStopPowerShell = $ps
    $script:OneByOneStopRunspace = $runspace
    $script:OneByOneStopAsync = $ps.BeginInvoke()
}

function Process-AnswerWindowRequests {
    return
}

function Invoke-AnswerWindowMaintenance {
    if ($script:OneByOneStopSignal -and [bool]$script:OneByOneStopSignal.Close -and ($script:OneByOneStopPowerShell -or $script:OneByOneStopRunspace)) {
        try { Close-OneByOneStopWindow } catch {}
        try {
            if ($form -and $form.WindowState -eq 'Minimized') {
                Restore-AppWindow
            }
        }
        catch {
        }
        return
    }

    if ($script:OneByOneStopAsync -and $script:OneByOneStopAsync.IsCompleted) {
        try { Close-OneByOneStopWindow } catch {}
    }
}

function Get-CurrentMessageTemplate {
    if ($script:MessageTemplates.Count -gt 0) {
        $index = $script:MessageTemplateIndex % $script:MessageTemplates.Count
        return [string]$script:MessageTemplates[$index]
    }
    return [string]$messageBox.Text
}

function Advance-MessageTemplate {
    if ($script:MessageTemplates.Count -le 0) { return }

    $script:MessageTemplateIndex = ($script:MessageTemplateIndex + 1) % $script:MessageTemplates.Count
    if ($messageBox) {
        $messageBox.Text = [string]$script:MessageTemplates[$script:MessageTemplateIndex]
    }
    Save-ProcessingState
    Refresh-MessageTemplatesStatus
}

function Take-MessageTemplateForSend {
    $template = Get-CurrentMessageTemplate
    if ($script:MessageTemplates.Count -gt 0) {
        Advance-MessageTemplate
    }
    return $template
}

function Wait-Cancellable {
    param([int]$Milliseconds)

    if ($Milliseconds -le 0) { return }

    $deadline = [DateTime]::UtcNow.AddMilliseconds($Milliseconds)
    while (-not (Test-OneByOneStopRequested)) {
        $remaining = [int]($deadline - [DateTime]::UtcNow).TotalMilliseconds
        if ($remaining -le 0) { break }
        if (Wait-OneByOneIfPaused -Status 'Пауза: продолжу после нажатия СТАРТ') { break }
        Process-AnswerWindowRequests
        Invoke-AnswerWindowMaintenance
        try {
            if ($script:OneByOneRunning) {
                [void](Update-OneByOneRecentMaxMessages -IntervalSeconds ([Math]::Max(1, [int]$script:OneByOneNotificationScanIntervalSeconds)))
            }
        }
        catch {
        }
        [System.Windows.Forms.Application]::DoEvents()
        Start-Sleep -Milliseconds ([Math]::Min(250, $remaining))
    }
}

function Wait-ProcessWithUi {
    param(
        [System.Diagnostics.Process]$Process,
        [int]$PollMs = 100
    )

    if ($null -eq $Process) { return }
    while (-not $Process.HasExited) {
        [void](Test-OneByOneStopRequested)
        [void](Wait-OneByOneIfPaused -Status 'Пауза: продолжу после нажатия СТАРТ')
        [System.Windows.Forms.Application]::DoEvents()
        Start-Sleep -Milliseconds ([Math]::Max(25, $PollMs))
    }
}

function Find-DateInText {
    param([string]$Text)

    return [regex]::Match($Text, '(?<!\d)(\d{1,2}[./]\d{1,2}[./]\d{4}|\d{4}-\d{2}-\d{2})(?!\d)')
}

function Find-PhoneMatches {
    param([string]$Text)

    return [regex]::Matches($Text, '(?<!\d)(\+?\d[\d\s\-\(\)]{8,}\d)(?!\d)')
}

function New-ContactRecord {
    param(
        [int]$Line,
        [string]$FullName,
        [string]$Phone,
        [string]$BirthDate,
        [string]$MaxUserId,
        [string]$Raw
    )

    $normalizedPhone = Normalize-Phone $Phone
    $normalizedBirthDate = Convert-Date $BirthDate
    $status = "OK"

    if ([string]::IsNullOrWhiteSpace($FullName)) { $status = "Нет ФИО" }
    elseif ([string]::IsNullOrWhiteSpace($normalizedPhone)) { $status = "Нет номера" }
    elseif (($normalizedPhone -replace '\D', '').Length -lt 10) { $status = "Проверь номер" }

    return [pscustomobject]@{
        Line = $Line
        FullName = $FullName.Trim()
        Phone = $normalizedPhone
        BirthDate = $normalizedBirthDate
        MaxUserId = $MaxUserId
        Status = $status
        Raw = $Raw
    }
}

function Parse-ContactBlock {
    param(
        [array]$BlockLines,
        [array]$BlockLineNumbers
    )

    $contacts = New-Object System.Collections.Generic.List[object]
    $fullName = ""
    $birthDate = ""
    $phones = New-Object System.Collections.Generic.List[object]

    for ($i = 0; $i -lt $BlockLines.Count; $i++) {
        $line = ([string]$BlockLines[$i]).Trim()
        $lineNumber = [int]$BlockLineNumbers[$i]
        if ([string]::IsNullOrWhiteSpace($line) -or $line.StartsWith('#')) { continue }

        $dateMatch = Find-DateInText $line
        $phoneMatches = Find-PhoneMatches $line

        if ($dateMatch.Success) {
            $birthDate = $dateMatch.Value.Trim()
        }

        if ($phoneMatches.Count -gt 0) {
            foreach ($phoneMatch in $phoneMatches) {
                $phones.Add([pscustomobject]@{
                    Line = $lineNumber
                    Phone = $phoneMatch.Value.Trim()
                    Raw = $line
                })
            }
            continue
        }

        if (-not $dateMatch.Success) {
            if ([string]::IsNullOrWhiteSpace($fullName)) {
                $fullName = $line
            }
            else {
                $fullName = "$fullName $line"
            }
        }
    }

    if ($phones.Count -eq 0) {
        $lineNumber = if ($BlockLineNumbers.Count -gt 0) { [int]$BlockLineNumbers[0] } else { 0 }
        $raw = ($BlockLines -join ' ')
        $contacts.Add((New-ContactRecord -Line $lineNumber -FullName $fullName -Phone "" -BirthDate $birthDate -MaxUserId "" -Raw $raw))
        return $contacts
    }

    foreach ($phone in $phones) {
        $contacts.Add((New-ContactRecord -Line $phone.Line -FullName $fullName -Phone $phone.Phone -BirthDate $birthDate -MaxUserId "" -Raw $phone.Raw))
    }

    return $contacts
}

function Parse-BlockContactsFile {
    param([array]$Lines)

    $contacts = New-Object System.Collections.Generic.List[object]
    $blockLines = @()
    $blockLineNumbers = @()

    for ($i = 0; $i -lt $Lines.Count; $i++) {
        $line = [string]$Lines[$i]
        $trimmed = $line.Trim()
        if ($trimmed -match '^-{3,}$') {
            if ($blockLines.Count -gt 0) {
                foreach ($contact in (Parse-ContactBlock -BlockLines $blockLines -BlockLineNumbers $blockLineNumbers)) {
                    $contacts.Add($contact)
                }
                $blockLines = @()
                $blockLineNumbers = @()
            }
            continue
        }

        if (-not [string]::IsNullOrWhiteSpace($trimmed)) {
            $blockLines += $line
            $blockLineNumbers += ($i + 1)
        }
    }

    if ($blockLines.Count -gt 0) {
        foreach ($contact in (Parse-ContactBlock -BlockLines $blockLines -BlockLineNumbers $blockLineNumbers)) {
            $contacts.Add($contact)
        }
    }

    return $contacts
}

function Parse-ContactsFile {
    param([string]$Path)

    $contacts = New-Object System.Collections.Generic.List[object]
    $lines = Get-Content -LiteralPath $Path -Encoding UTF8
    if (@($lines | Where-Object { ([string]$_).Trim() -match '^-{3,}$' }).Count -gt 0) {
        return Parse-BlockContactsFile -Lines $lines
    }

    $lineNumber = 0

    foreach ($rawLine in $lines) {
        $lineNumber++
        $line = $rawLine.Trim()
        if ([string]::IsNullOrWhiteSpace($line) -or $line.StartsWith('#')) { continue }

        $columns = @()
        if ($line -match ';') {
            $columns = @($line -split ';' | ForEach-Object { $_.Trim() })
        }
        elseif ($line -match "`t") {
            $columns = @($line -split "`t" | ForEach-Object { $_.Trim() })
        }
        elseif ($line -match ',') {
            $columns = @($line -split ',' | ForEach-Object { $_.Trim() })
        }

        $fullName = ""
        $phone = ""
        $birthDate = ""
        $maxUserId = ""

        if ($columns.Count -ge 2) {
            $fullName = $columns[0]
            $phone = $columns[1]
            $phoneMatch = (Find-PhoneMatches $phone | Select-Object -First 1)
            if ($phoneMatch -and $phoneMatch.Success) { $phone = $phoneMatch.Value.Trim() }
            if ($columns.Count -ge 3) { $birthDate = $columns[2] }
            if ($columns.Count -ge 4) { $maxUserId = $columns[3] }
        }
        else {
            $lineForScan = $line
            $dateMatch = Find-DateInText $lineForScan
            if ($dateMatch.Success) {
                $birthDate = $dateMatch.Value.Trim()
                $lineForScan = ($lineForScan.Remove($dateMatch.Index, $dateMatch.Length)).Trim()
            }

            $phoneMatch = (Find-PhoneMatches $lineForScan | Select-Object -First 1)
            if ($phoneMatch.Success) {
                $phone = $phoneMatch.Value.Trim()
                $fullName = ($lineForScan.Remove($phoneMatch.Index, $phoneMatch.Length)).Trim()
            }
            else {
                $fullName = $lineForScan
            }
        }

        $contacts.Add((New-ContactRecord -Line $lineNumber -FullName $fullName -Phone $phone -BirthDate $birthDate -MaxUserId $maxUserId -Raw $rawLine))
    }

    return $contacts
}

function Refresh-Grid {
    if (-not $grid) { return }

    $grid.SuspendLayout()
    try {
        $grid.Rows.Clear()
        foreach ($contact in $script:Contacts) {
            [void]$grid.Rows.Add(
                $contact.Line,
                $contact.FullName,
                $contact.Phone,
                $contact.BirthDate,
                $contact.MaxUserId,
                $contact.Status
            )
        }
        $grid.ClearSelection()
    }
    finally {
        $grid.ResumeLayout()
    }

    $okCount = @($script:Contacts | Where-Object { $_.Status -eq 'OK' }).Count
    $badCount = $script:Contacts.Count - $okCount
    $statsLabel.Text = "Контактов: $($script:Contacts.Count) | OK: $okCount | Проверить: $badCount"
    Refresh-OneByOneStatus
}

function Get-ValidContacts {
    return @($script:Contacts | Where-Object { $_.Status -eq 'OK' })
}

function Export-VCard {
    param([string]$Path, [string]$GroupName)

    $builder = New-Object System.Text.StringBuilder
    foreach ($contact in Get-ValidContacts) {
        $nameParts = Split-Name $contact.FullName
        $last = Escape-VCard $nameParts[0]
        $first = Escape-VCard $nameParts[1]
        $middle = Escape-VCard $nameParts[2]
        $fn = Escape-VCard $contact.FullName
        $phone = ($contact.Phone -replace '\s', '')

        [void]$builder.AppendLine('BEGIN:VCARD')
        [void]$builder.AppendLine('VERSION:3.0')
        [void]$builder.AppendLine("N:$last;$first;$middle;;")
        [void]$builder.AppendLine("FN:$fn")
        [void]$builder.AppendLine("TEL;TYPE=CELL:$phone")
        if (-not [string]::IsNullOrWhiteSpace($contact.BirthDate)) {
            [void]$builder.AppendLine("BDAY:$($contact.BirthDate)")
        }
        if (-not [string]::IsNullOrWhiteSpace($GroupName)) {
            [void]$builder.AppendLine("CATEGORIES:$(Escape-VCard $GroupName)")
        }
        [void]$builder.AppendLine('END:VCARD')
    }

    Set-Content -LiteralPath $Path -Value $builder.ToString() -Encoding UTF8
}

function Export-CsvFile {
    param([string]$Path)
    Get-ValidContacts |
        Select-Object FullName, Phone, BirthDate, MaxUserId, Status |
        Export-Csv -LiteralPath $Path -NoTypeInformation -Encoding UTF8
}

function Export-Messages {
    param([string]$Path, [string]$Template, [string]$GroupName)

    $builder = New-Object System.Text.StringBuilder
    foreach ($contact in Get-ValidContacts) {
        [void]$builder.AppendLine("[$($contact.FullName) | $($contact.Phone)]")
        [void]$builder.AppendLine((Apply-Template $Template $contact $GroupName))
        [void]$builder.AppendLine("")
    }
    Set-Content -LiteralPath $Path -Value $builder.ToString() -Encoding UTF8
}

function Export-MaxPayloads {
    param([string]$Path, [string]$Template, [string]$GroupName, [string]$ChatId)

    $payloads = New-Object System.Collections.Generic.List[object]
    foreach ($contact in Get-ValidContacts) {
        $item = [ordered]@{
            note = "MAX API принимает user_id/chat_id, а не телефон. Для отправки по человеку заполните MaxUserId."
            fullName = $contact.FullName
            phone = $contact.Phone
            birthDate = $contact.BirthDate
            maxUserId = $contact.MaxUserId
            chatId = $ChatId
            message = @{
                text = Apply-Template $Template $contact $GroupName
                notify = $true
                format = $null
            }
        }
        $payloads.Add([pscustomobject]$item)
    }

    $payloads | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $Path -Encoding UTF8
}

function Get-DefaultMaxitochkaPath {
    $desktopPath = [Environment]::GetFolderPath('Desktop')
    $candidates = New-Object System.Collections.Generic.List[string]
    foreach ($path in @(
        (Join-Path $desktopPath '3\Maxitochka'),
        (Join-Path $desktopPath 'Maxitochka'),
        (Join-Path $desktopPath '1\Maxitochka'),
        'C:\Users\Лепа\Desktop\3\Maxitochka',
        'C:\Users\Лепа\Desktop\Maxitochka',
        'C:\Users\Лепа\Desktop\1\Maxitochka',
        (Join-Path $script:AppRoot 'Maxitochka')
    )) {
        if (-not [string]::IsNullOrWhiteSpace($path) -and -not $candidates.Contains($path)) {
            $candidates.Add($path) | Out-Null
        }
    }
    try {
        foreach ($dir in @(Get-ChildItem -LiteralPath $desktopPath -Directory -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)) {
            $path = Join-Path $dir.FullName 'Maxitochka'
            if ((Test-Path -LiteralPath $path) -and -not $candidates.Contains($path)) {
                $candidates.Add($path) | Out-Null
            }
        }
    }
    catch {
    }
    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath $candidate) { return $candidate }
    }
    return ""
}

function Get-MaxitochkaProfilesPaths {
    param([string]$RootPath)

    $paths = New-Object System.Collections.Generic.List[string]
    if ([string]::IsNullOrWhiteSpace($RootPath)) { return $paths.ToArray() }
    $candidates = @(
        (Join-Path $RootPath 'DotLauncher.exe_extracted\profiles'),
        (Join-Path $RootPath 'profiles'),
        (Join-Path $RootPath 'DotLauncher.exe_extracted\sessions'),
        (Join-Path $RootPath 'sessions')
    )
    foreach ($candidate in $candidates) {
        if ((Test-Path -LiteralPath $candidate) -and -not $paths.Contains($candidate)) {
            $paths.Add($candidate) | Out-Null
        }
    }
    return $paths.ToArray()
}

function Get-MaxitochkaProfilesPath {
    param([string]$RootPath)

    $paths = @(Get-MaxitochkaProfilesPaths $RootPath)
    if ($paths.Count -gt 0) { return [string]$paths[0] }
    return ""
}

function Get-MaxitochkaExtractedPath {
    param([string]$RootPath)

    if ([string]::IsNullOrWhiteSpace($RootPath)) { return "" }
    $candidates = @(
        (Join-Path $RootPath 'DotLauncher.exe_extracted'),
        $RootPath
    )
    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath $candidate) { return $candidate }
    }
    return ""
}

function Get-ListeningLocalPorts {
    try {
        return @(
            Get-NetTCPConnection -State Listen -ErrorAction Stop |
                Where-Object { $_.LocalAddress -in @('127.0.0.1', '0.0.0.0', '::1', '::') } |
                Select-Object -ExpandProperty LocalPort -Unique
        )
    }
    catch {
        return @()
    }
}

function Get-MaxitochkaRegistrySessions {
    $items = New-Object System.Collections.Generic.List[object]
    try {
        $appData = [Environment]::GetFolderPath('ApplicationData')
        if ([string]::IsNullOrWhiteSpace($appData)) { return $items.ToArray() }
        $settingsPath = Join-Path $appData 'Maxitochka\settings.json'
        if (-not (Test-Path -LiteralPath $settingsPath)) { return $items.ToArray() }

        $settings = Get-Content -Raw -Encoding UTF8 -LiteralPath $settingsPath -ErrorAction Stop | ConvertFrom-Json
        if ($null -eq $settings.browser_sessions) { return $items.ToArray() }

        foreach ($property in @($settings.browser_sessions.PSObject.Properties)) {
            $entry = $property.Value
            $port = 0
            if ($null -eq $entry -or -not [int]::TryParse([string]$entry.port, [ref]$port) -or $port -le 0) { continue }

            $fname = [string]$property.Name
            $profile = [IO.Path]::GetFileNameWithoutExtension($fname)
            $profileDir = [string]$entry.profile_dir
            $portFile = ""
            if (-not [string]::IsNullOrWhiteSpace($profileDir)) {
                try {
                    $leaf = Split-Path -LiteralPath $profileDir -Leaf
                    if (-not [string]::IsNullOrWhiteSpace($leaf)) { $profile = $leaf }
                    $portFile = Join-Path $profileDir 'DevToolsActivePort'
                }
                catch {
                    $portFile = ""
                }
            }
            if ([string]::IsNullOrWhiteSpace($portFile)) {
                $portFile = "registry:$fname"
            }

            $items.Add([pscustomobject]@{
                Profile = $profile
                Port = $port
                PortFile = $portFile
            }) | Out-Null
        }
    }
    catch {
    }
    return $items.ToArray()
}

function Get-MaxitochkaProcessDebugSessions {
    param([string]$RootPath)

    $items = New-Object System.Collections.Generic.List[object]
    try {
        $processes = @(Get-CimInstance Win32_Process -ErrorAction Stop | Where-Object {
            ([string]$_.Name) -match 'chrome|Maxitochka|chromedriver' -or
            ([string]$_.CommandLine) -match 'remote-debugging-port|web[.]max[.]ru|Maxitochka'
        })
        foreach ($process in $processes) {
            $commandLine = [string]$process.CommandLine
            if ([string]::IsNullOrWhiteSpace($commandLine)) { continue }
            if ($commandLine -notmatch '--remote-debugging-port(?:=|\s+)(\d+)') { continue }

            $port = 0
            if (-not [int]::TryParse($matches[1], [ref]$port) -or $port -le 0) { continue }

            $profileDir = ""
            if ($commandLine -match '--user-data-dir=(?:"([^"]+)"|([^\s]+))') {
                $profileDir = if ($matches[1]) { [string]$matches[1] } else { [string]$matches[2] }
            }

            $profile = "CDP $port"
            if (-not [string]::IsNullOrWhiteSpace($profileDir)) {
                try {
                    $leaf = Split-Path -LiteralPath $profileDir -Leaf
                    if (-not [string]::IsNullOrWhiteSpace($leaf)) { $profile = $leaf }
                }
                catch {
                }
            }

            $rootMatches = $true
            if (-not [string]::IsNullOrWhiteSpace($RootPath) -and -not [string]::IsNullOrWhiteSpace($profileDir)) {
                try {
                    $rootFull = [IO.Path]::GetFullPath($RootPath).TrimEnd('\')
                    $profileFull = [IO.Path]::GetFullPath($profileDir)
                    $rootMatches = $profileFull.StartsWith($rootFull, [StringComparison]::OrdinalIgnoreCase)
                }
                catch {
                    $rootMatches = $true
                }
            }

            $portFile = if (-not [string]::IsNullOrWhiteSpace($profileDir)) {
                Join-Path $profileDir 'DevToolsActivePort'
            }
            else {
                "process:$($process.ProcessId)"
            }

            $items.Add([pscustomobject]@{
                Profile = $profile
                Port = $port
                PortFile = $portFile
                RootMatches = [bool]$rootMatches
            }) | Out-Null
        }
    }
    catch {
    }
    return $items.ToArray()
}

function Add-MaxitochkaSessionFromPort {
    param(
        [System.Collections.Generic.List[object]]$Sessions,
        [hashtable]$SeenPorts,
        [string]$ProfileName,
        [int]$Port,
        [string]$PortFile,
        [array]$ListeningPorts
    )

    if ($Port -le 0 -or $SeenPorts.ContainsKey([string]$Port)) { return }

    $status = 'Порт не активен'
    $title = ''
    $url = ''
    if ($ListeningPorts.Count -eq 0 -or $ListeningPorts -contains $Port) {
        try {
            $tabs = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/json/list" -TimeoutSec 1 -ErrorAction Stop
            $maxTab = $null
            foreach ($tab in $tabs) {
                if ($tab.type -eq 'page' -and ([string]$tab.url) -match '^https?://web[.]max[.]ru') {
                    $maxTab = $tab
                    break
                }
            }
            if ($null -ne $maxTab) {
                $status = 'MAX открыт'
                $title = [string]$maxTab.title
                $url = [string]$maxTab.url
                if ($ProfileName -match '^CDP\s+\d+$' -and $title -match '^MX[·|][^·|]+[·|](.+)$') {
                    $parsedProfile = ([string]$matches[1]).Trim()
                    if (-not [string]::IsNullOrWhiteSpace($parsedProfile)) {
                        $ProfileName = $parsedProfile
                    }
                }
            }
            else {
                $status = 'Браузер открыт'
                if ($tabs.Count -gt 0) {
                    $title = [string]$tabs[0].title
                    $url = [string]$tabs[0].url
                }
            }
        }
        catch {
            $status = 'Порт не отвечает'
        }
    }

    if ($status -ne 'Порт не активен') {
        $Sessions.Add([pscustomobject]@{
            Profile = $ProfileName
            Port = $Port
            Status = $status
            Title = $title
            Url = $url
            PortFile = $PortFile
        }) | Out-Null
        $SeenPorts[[string]$Port] = $true
    }
}

function Get-MaxitochkaOpenSessions {
    param([string]$RootPath)

    $sessions = New-Object System.Collections.Generic.List[object]
    $seenPorts = @{}
    $listeningPorts = @(Get-ListeningLocalPorts)

    foreach ($record in @(Get-MaxitochkaRegistrySessions)) {
        Add-MaxitochkaSessionFromPort -Sessions $sessions -SeenPorts $seenPorts -ProfileName ([string]$record.Profile) -Port ([int]$record.Port) -PortFile ([string]$record.PortFile) -ListeningPorts $listeningPorts
    }

    foreach ($record in @(Get-MaxitochkaProcessDebugSessions $RootPath)) {
        Add-MaxitochkaSessionFromPort -Sessions $sessions -SeenPorts $seenPorts -ProfileName ([string]$record.Profile) -Port ([int]$record.Port) -PortFile ([string]$record.PortFile) -ListeningPorts $listeningPorts
        [System.Windows.Forms.Application]::DoEvents()
    }

    $profilesPaths = @(Get-MaxitochkaProfilesPaths $RootPath)
    foreach ($profilesPath in $profilesPaths) {
        $portFiles = @(Get-ChildItem -LiteralPath $profilesPath -Recurse -File -Filter DevToolsActivePort -Force -ErrorAction SilentlyContinue)
        foreach ($portFile in $portFiles) {
            $content = @(Get-Content -LiteralPath $portFile.FullName -ErrorAction SilentlyContinue)
            if ($content.Count -lt 1) { continue }

            $port = 0
            if (-not [int]::TryParse([string]$content[0], [ref]$port)) { continue }
            $profileName = Split-Path $portFile.DirectoryName -Leaf
            Add-MaxitochkaSessionFromPort -Sessions $sessions -SeenPorts $seenPorts -ProfileName $profileName -Port $port -PortFile $portFile.FullName -ListeningPorts $listeningPorts
            [System.Windows.Forms.Application]::DoEvents()
        }
    }

    if ($listeningPorts.Count -gt 0) {
        foreach ($port in @($listeningPorts | Where-Object { $_ -ge 19222 -and $_ -le 19999 } | Sort-Object)) {
            Add-MaxitochkaSessionFromPort -Sessions $sessions -SeenPorts $seenPorts -ProfileName ("CDP $port") -Port ([int]$port) -PortFile "probe:$port" -ListeningPorts $listeningPorts
            [System.Windows.Forms.Application]::DoEvents()
        }
    }

    return $sessions
}

function Get-MaxitochkaSessionKey {
    param($Session)

    if ($null -eq $Session) { return "" }
    return "{0}|{1}|{2}" -f ([string]$Session.Profile), ([string]$Session.Port), ([string]$Session.PortFile)
}

function Get-MaxitochkaRowSession {
    param($Row)

    if ($null -eq $Row -or $Row.IsNewRow) { return $null }

    $key = ""
    if ($maxitochkaGrid -and $maxitochkaGrid.Columns.Contains('MxKey')) {
        $key = [string]$Row.Cells['MxKey'].Value
    }

    $profile = [string]$Row.Cells['MxProfile'].Value
    $port = [string]$Row.Cells['MxPort'].Value

    $matches = @($script:MaxitochkaSessions | Where-Object {
        if (-not [string]::IsNullOrWhiteSpace($key)) {
            (Get-MaxitochkaSessionKey $_) -eq $key
        }
        else {
            $_.Profile -eq $profile -and [string]$_.Port -eq $port
        }
    })

    return ($matches | Select-Object -First 1)
}

function Test-MaxitochkaRowChecked {
    param($Row)

    if ($null -eq $Row -or $Row.IsNewRow) { return $false }
    if (-not $maxitochkaGrid -or -not $maxitochkaGrid.Columns.Contains('MxUse')) { return $false }

    $value = $Row.Cells['MxUse'].Value
    if ($null -eq $value) { return $false }

    try {
        return [bool]$value
    }
    catch {
        return $false
    }
}

function Get-CheckedMaxitochkaSessions {
    $sessions = New-Object System.Collections.Generic.List[object]
    $seen = @{}

    if (-not $maxitochkaGrid -or -not $maxitochkaGrid.Columns.Contains('MxUse')) {
        return @()
    }

    foreach ($row in $maxitochkaGrid.Rows) {
        if (-not (Test-MaxitochkaRowChecked $row)) { continue }

        $session = Get-MaxitochkaRowSession $row
        if (-not $session -or $session.Status -ne 'MAX открыт') { continue }

        $key = Get-MaxitochkaSessionKey $session
        if ($seen.ContainsKey($key)) { continue }

        $seen[$key] = $true
        $sessions.Add($session)
    }

    return $sessions.ToArray()
}

function Refresh-MaxitochkaStatus {
    if (-not $maxitochkaStatusLabel) { return }

    $openCount = @($script:MaxitochkaSessions | Where-Object { $_.Status -eq 'MAX открыт' }).Count
    $checkedCount = @(Get-CheckedMaxitochkaSessions).Count
    $maxitochkaStatusLabel.Text = "Открытых MAX: $openCount | Выбрано: $checkedCount | Найдено браузеров: $($script:MaxitochkaSessions.Count)"
}

function Refresh-MaxitochkaGrid {
    if (-not $maxitochkaGrid) { return }

    $maxitochkaGrid.SuspendLayout()
    try {
        $maxitochkaGrid.Rows.Clear()
        foreach ($session in $script:MaxitochkaSessions) {
            $rowIndex = $maxitochkaGrid.Rows.Add(
                [bool]($session.Status -eq 'MAX открыт'),
                $session.Profile,
                $session.Port,
                $session.Status,
                $session.Title,
                $session.Url,
                (Get-MaxitochkaSessionKey $session)
            )
            if ($session.Status -ne 'MAX открыт' -and $maxitochkaGrid.Columns.Contains('MxUse')) {
                $maxitochkaGrid.Rows[$rowIndex].Cells['MxUse'].ReadOnly = $true
            }
        }
        $maxitochkaGrid.ClearSelection()
    }
    finally {
        $maxitochkaGrid.ResumeLayout()
    }

    Refresh-MaxitochkaStatus
}

function Export-MaxitochkaJob {
    param([string]$Path, [string]$Template, [string]$GroupName)

    $sessions = @(Get-SelectedMaxitochkaSessions)

    $job = [ordered]@{
        createdAt = (Get-Date).ToString('s')
        groupName = $GroupName
        note = 'Файл-задание для связки с открытыми окнами Maxitochka. Выполнение действий внутри MAX требует отдельной UI/CDP-автоматизации по живому окну.'
        sessions = @($sessions | Select-Object Profile, Port, Status, Title, Url)
        contacts = @(
            Get-ValidContacts | ForEach-Object {
                [ordered]@{
                    fullName = $_.FullName
                    phone = $_.Phone
                    birthDate = $_.BirthDate
                    message = Apply-Template $Template $_ $GroupName
                }
            }
        )
    }

    $job | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $Path -Encoding UTF8
}

function Get-MaxitochkaPageTarget {
    param([int]$Port)

    try {
        $targets = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/json/list" -TimeoutSec 2 -ErrorAction Stop
        foreach ($target in $targets) {
            if ($target.type -eq 'page' -and ([string]$target.url) -match '^https?://web[.]max[.]ru/?') {
                return $target
            }
        }
        return $null
    }
    catch {
        return $null
    }
}

function Wait-TaskWithUi {
    param(
        [Threading.Tasks.Task]$Task,
        [int]$TimeoutMs = 0,
        [string]$Action = 'операция MAX'
    )

    $watch = [Diagnostics.Stopwatch]::StartNew()

    while (-not $Task.Wait(100)) {
        [void](Test-OneByOneStopRequested)
        [System.Windows.Forms.Application]::DoEvents()
        if ($TimeoutMs -gt 0 -and $watch.ElapsedMilliseconds -gt $TimeoutMs) {
            throw "MAX не ответил вовремя: $Action"
        }
    }

    return $Task.GetAwaiter().GetResult()
}

function Invoke-MaxitochkaScript {
    param(
        $Session,
        [string]$Expression,
        [int]$TimeoutMs = 30000
    )

    $page = Get-MaxitochkaPageTarget ([int]$Session.Port)
    if (-not $page -or [string]::IsNullOrWhiteSpace($page.webSocketDebuggerUrl)) {
        throw "MAX-страница профиля $($Session.Profile) не отвечает."
    }

    $previousDevToolsBusy = [bool]$script:MaxitochkaDevToolsBusy
    $script:MaxitochkaDevToolsBusy = $true
    $ws = [System.Net.WebSockets.ClientWebSocket]::new()
    $cts = [Threading.CancellationTokenSource]::new($TimeoutMs)
    try {
        $connectTask = $ws.ConnectAsync([Uri]$page.webSocketDebuggerUrl, $cts.Token)
        Wait-TaskWithUi -Task $connectTask -TimeoutMs ([Math]::Min([Math]::Max(3000, $TimeoutMs), 8000)) -Action "подключение к $($Session.Profile)" | Out-Null
        $payload = @{
            id = 1
            method = 'Runtime.evaluate'
            params = @{
                expression = $Expression
                returnByValue = $true
                awaitPromise = $true
            }
        } | ConvertTo-Json -Depth 30 -Compress

        $bytes = [Text.Encoding]::UTF8.GetBytes($payload)
        $sendTask = $ws.SendAsync(
            [ArraySegment[byte]]::new($bytes),
            [System.Net.WebSockets.WebSocketMessageType]::Text,
            $true,
            $cts.Token
        )
        Wait-TaskWithUi -Task $sendTask -TimeoutMs ([Math]::Min([Math]::Max(3000, $TimeoutMs), 8000)) -Action "отправка команды в $($Session.Profile)" | Out-Null

        $buffer = New-Object byte[] 1048576
        $builder = New-Object System.Text.StringBuilder
        while ($true) {
            $receiveTask = $ws.ReceiveAsync([ArraySegment[byte]]::new($buffer), $cts.Token)
            $result = Wait-TaskWithUi -Task $receiveTask -TimeoutMs ([Math]::Max(1000, $TimeoutMs + 1500)) -Action "ответ от $($Session.Profile)"
            [void]$builder.Append([Text.Encoding]::UTF8.GetString($buffer, 0, $result.Count))
            if (-not $result.EndOfMessage) { continue }

            $messageText = $builder.ToString()
            $builder.Clear() | Out-Null
            $message = $messageText | ConvertFrom-Json
            if ($message.id -ne 1) { continue }

            if ($message.error) {
                throw ($message.error | ConvertTo-Json -Compress)
            }
            if ($message.result.exceptionDetails) {
                throw ($message.result.exceptionDetails.text)
            }
            return $message.result.result.value
        }
    }
    finally {
        if ($ws.State -eq [System.Net.WebSockets.WebSocketState]::Open) {
            $closeCts = [Threading.CancellationTokenSource]::new(1200)
            try {
                $closeTask = $ws.CloseAsync(
                    [System.Net.WebSockets.WebSocketCloseStatus]::NormalClosure,
                    'done',
                    $closeCts.Token
                )
                Wait-TaskWithUi -Task $closeTask -TimeoutMs 1500 -Action "закрытие соединения $($Session.Profile)" | Out-Null
            }
            catch {
                try { $ws.Abort() } catch {}
            }
            finally {
                $closeCts.Dispose()
            }
        }
        $ws.Dispose()
        $cts.Dispose()
        $script:MaxitochkaDevToolsBusy = $previousDevToolsBusy
    }
}

function Invoke-MaxitochkaBringToFront {
    param(
        $Session,
        [int]$TimeoutMs = 6000
    )

    $page = Get-MaxitochkaPageTarget ([int]$Session.Port)
    if (-not $page -or [string]::IsNullOrWhiteSpace($page.webSocketDebuggerUrl)) {
        throw "MAX-страница профиля $($Session.Profile) не отвечает."
    }

    $ws = [System.Net.WebSockets.ClientWebSocket]::new()
    $cts = [Threading.CancellationTokenSource]::new($TimeoutMs)
    try {
        $connectTask = $ws.ConnectAsync([Uri]$page.webSocketDebuggerUrl, $cts.Token)
        Wait-TaskWithUi -Task $connectTask -TimeoutMs ([Math]::Min([Math]::Max(3000, $TimeoutMs), 8000)) -Action "подключение к $($Session.Profile)" | Out-Null

        $payload = @{
            id = 1
            method = 'Page.bringToFront'
        } | ConvertTo-Json -Depth 10 -Compress

        $bytes = [Text.Encoding]::UTF8.GetBytes($payload)
        $sendTask = $ws.SendAsync(
            [ArraySegment[byte]]::new($bytes),
            [System.Net.WebSockets.WebSocketMessageType]::Text,
            $true,
            $cts.Token
        )
        Wait-TaskWithUi -Task $sendTask -TimeoutMs ([Math]::Min([Math]::Max(3000, $TimeoutMs), 8000)) -Action "активация вкладки $($Session.Profile)" | Out-Null

        $buffer = New-Object byte[] 65536
        $builder = New-Object System.Text.StringBuilder
        while ($true) {
            $receiveTask = $ws.ReceiveAsync([ArraySegment[byte]]::new($buffer), $cts.Token)
            $result = Wait-TaskWithUi -Task $receiveTask -TimeoutMs ([Math]::Max(1000, $TimeoutMs + 1500)) -Action "ответ активации $($Session.Profile)"
            [void]$builder.Append([Text.Encoding]::UTF8.GetString($buffer, 0, $result.Count))
            if (-not $result.EndOfMessage) { continue }

            $messageText = $builder.ToString()
            $builder.Clear() | Out-Null
            $message = $messageText | ConvertFrom-Json
            if ($message.id -ne 1) { continue }

            if ($message.error) {
                throw ($message.error | ConvertTo-Json -Compress)
            }
            return $true
        }
    }
    finally {
        if ($ws.State -eq [System.Net.WebSockets.WebSocketState]::Open) {
            $closeCts = [Threading.CancellationTokenSource]::new(1200)
            try {
                $closeTask = $ws.CloseAsync(
                    [System.Net.WebSockets.WebSocketCloseStatus]::NormalClosure,
                    'done',
                    $closeCts.Token
                )
                Wait-TaskWithUi -Task $closeTask -TimeoutMs 1500 -Action "закрытие соединения $($Session.Profile)" | Out-Null
            }
            catch {
                try { $ws.Abort() } catch {}
            }
            finally {
                $closeCts.Dispose()
            }
        }
        $ws.Dispose()
        $cts.Dispose()
    }
}

function Get-MaxitochkaProcessCandidates {
    param($Session)

    $pids = New-Object System.Collections.Generic.List[int]
    $port = [int]$Session.Port
    $profilePath = ""
    if ($Session.PortFile) {
        try {
            $profilePath = [System.IO.Path]::GetDirectoryName([string]$Session.PortFile)
        }
        catch {
            $profilePath = ""
        }
    }

    try {
        Get-NetTCPConnection -LocalPort $port -ErrorAction Stop |
            Where-Object { $_.OwningProcess -gt 0 } |
            ForEach-Object {
                if (-not $pids.Contains([int]$_.OwningProcess)) { $pids.Add([int]$_.OwningProcess) }
            }
    }
    catch {
    }

    try {
        $processes = @(Get-CimInstance Win32_Process -ErrorAction Stop)
        foreach ($process in $processes) {
            $commandLine = [string]$process.CommandLine
            $matched = $false
            if ($commandLine -match "remote-debugging-port[=\s]+$port") { $matched = $true }
            if (-not $matched -and -not [string]::IsNullOrWhiteSpace($profilePath) -and $commandLine.Contains($profilePath)) {
                $matched = $true
            }
            if ($matched) {
                foreach ($candidatePid in @([int]$process.ProcessId, [int]$process.ParentProcessId)) {
                    if ($candidatePid -gt 0 -and -not $pids.Contains($candidatePid)) { $pids.Add($candidatePid) }
                }
            }
        }
    }
    catch {
    }

    $candidates = New-Object System.Collections.Generic.List[object]
    foreach ($candidatePid in @($pids | Select-Object -Unique)) {
        try {
            $process = Get-Process -Id $candidatePid -ErrorAction Stop
            if ($process.MainWindowHandle -ne [IntPtr]::Zero) {
                $candidates.Add($process)
            }
        }
        catch {
        }
    }

    return $candidates.ToArray()
}

function Invoke-MaxitochkaWindowToFront {
    param(
        $Session,
        [int]$DelayMs = 900
    )

    try {
        $processes = @(Get-MaxitochkaProcessCandidates $Session)
    }
    catch {
        return $false
    }
    if ($processes.Count -eq 0) {
        return $false
    }

    $shell = $null
    try {
        $shell = New-Object -ComObject WScript.Shell
    }
    catch {
        $shell = $null
    }

    foreach ($process in $processes) {
        $handle = $process.MainWindowHandle
        if ($handle -eq [IntPtr]::Zero) { continue }

        try {
            if ([MaxContactWin32]::IsIconic($handle)) {
                [MaxContactWin32]::ShowWindowAsync($handle, 9) | Out-Null
            }
            else {
                [MaxContactWin32]::ShowWindowAsync($handle, 5) | Out-Null
            }
            Start-Sleep -Milliseconds 120
            if ($shell) {
                [void]$shell.AppActivate([int]$process.Id)
                Start-Sleep -Milliseconds 120
            }
            [MaxContactWin32]::SetForegroundWindow($handle) | Out-Null
            Start-Sleep -Milliseconds ([Math]::Max(200, [Math]::Min(5000, $DelayMs)))

            if ([MaxContactWin32]::GetForegroundWindow() -eq $handle) {
                $script:LastActivatedMaxWindowHandle = $handle
                $script:LastActivatedMaxSessionProfile = [string]$Session.Profile
                return $true
            }
        }
        catch {
        }
    }

    return $false
}

function Test-MaxitochkaWindowForeground {
    param($Session)

    $foreground = [MaxContactWin32]::GetForegroundWindow()
    if ($foreground -eq [IntPtr]::Zero) { return $false }

    try {
        $processes = @(Get-MaxitochkaProcessCandidates $Session)
    }
    catch {
        return $false
    }

    foreach ($process in $processes) {
        if ($process.MainWindowHandle -eq $foreground) {
            return $true
        }
    }

    return $false
}

function Focus-MaxitochkaComposerForAhk {
    param($Session)

    try {
        Invoke-MaxitochkaBringToFront -Session $Session -TimeoutMs 6000 | Out-Null
    }
    catch {
        return [pscustomobject]@{ ok = $false; error = "не удалось активировать вкладку MAX: $($_.Exception.Message)" }
    }

    $activated = $false
    try {
        $activated = Invoke-MaxitochkaWindowToFront -Session $Session -DelayMs ([Math]::Max(500, [int]$script:SwitchDelayMs))
    }
    catch {
        return [pscustomobject]@{ ok = $false; error = "не удалось вывести окно MAX на передний план: $($_.Exception.Message)" }
    }

    if (-not $activated -or -not (Test-MaxitochkaWindowForeground $Session)) {
        return [pscustomobject]@{ ok = $false; error = 'активное окно Windows не совпадает с нужным MAX-профилем' }
    }

    try {
        $focusResult = Invoke-MaxitochkaScript -Session $Session -Expression (New-MaxitochkaFocusComposerScript) -TimeoutMs 15000
        if (-not $focusResult.ok) {
            return [pscustomobject]@{ ok = $false; error = "не найдено поле сообщения: $($focusResult.error)" }
        }
    }
    catch {
        return [pscustomobject]@{ ok = $false; error = "не удалось сфокусировать поле сообщения: $($_.Exception.Message)" }
    }

    [System.Windows.Forms.Application]::DoEvents()
    Start-Sleep -Milliseconds 250

    try {
        Invoke-MaxitochkaWindowToFront -Session $Session -DelayMs 250 | Out-Null
    }
    catch {
    }

    if (-not (Test-MaxitochkaWindowForeground $Session)) {
        return [pscustomobject]@{ ok = $false; error = 'после фокуса активное окно сменилось, печать AHK остановлена' }
    }

    return [pscustomobject]@{ ok = $true; error = '' }
}

function Get-SelectedMaxitochkaSessions {
    if ($maxitochkaGrid -and $maxitochkaGrid.Columns.Contains('MxUse')) {
        return @(Get-CheckedMaxitochkaSessions)
    }

    $sessions = @()
    if ($maxitochkaGrid.SelectedRows.Count -gt 0) {
        foreach ($row in $maxitochkaGrid.SelectedRows) {
            $match = Get-MaxitochkaRowSession $row
            if ($match -and $match.Status -eq 'MAX открыт') { $sessions += $match }
        }
    }
    else {
        $sessions = @($script:MaxitochkaSessions | Where-Object { $_.Status -eq 'MAX открыт' })
    }
    return $sessions
}

function Format-BirthDateForContactName {
    param([string]$BirthDate)

    if ([string]::IsNullOrWhiteSpace($BirthDate)) { return "" }
    $result = [DateTime]::MinValue
    if ([DateTime]::TryParseExact($BirthDate, 'yyyy-MM-dd', [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::None, [ref]$result)) {
        return $result.ToString('dd.MM.yyyy')
    }
    return $BirthDate
}

function Get-MaxitochkaContactPayload {
    param($Contact)

    $digits = ([string]$Contact.Phone -replace '\D', '')
    $localPhone = $digits
    if ($digits.Length -eq 11 -and $digits.StartsWith('7')) {
        $localPhone = $digits.Substring(1)
    }

    return [ordered]@{
        fullName = [string]$Contact.FullName
        phone = [string]$Contact.Phone
        localPhone = $localPhone
        birthDate = Format-BirthDateForContactName $Contact.BirthDate
        firstName = [string]$Contact.FullName
        lastName = Format-BirthDateForContactName $Contact.BirthDate
    }
}

function Get-ContactSurname {
    param($Contact)

    $name = [string]$Contact.FullName
    $parts = @($name.Trim() -split '\s+' | Where-Object { $_ })
    if ($parts.Count -gt 0) { return $parts[0] }
    return $name.Trim()
}

function Apply-GroupExtraTemplate {
    param(
        [string]$Template,
        $Contact,
        [string]$BaseGroupName,
        [int]$Index
    )

    $surname = Get-ContactSurname $Contact
    $text = [string]$Template
    $text = $text.Replace('{fio}', [string]$Contact.FullName)
    $text = $text.Replace('{surname}', [string]$surname)
    $text = $text.Replace('{phone}', [string]$Contact.Phone)
    $text = $text.Replace('{birthdate}', [string]$Contact.BirthDate)
    $text = $text.Replace('{group}', [string]$BaseGroupName)
    $text = $text.Replace('{n}', [string]($Index + 1))
    return $text.Trim()
}

function Get-DefaultGroupNameTemplates {
    return @(
        '{surname} Домофон',
        '{surname} Ключи',
        'Домофон',
        'Ключи'
    )
}

function Get-GroupNameForContact {
    param(
        $Contact,
        [int]$Index = -1
    )

    $baseName = $groupBox.Text.Trim()
    if ([string]::IsNullOrWhiteSpace($baseName)) { $baseName = 'Группа' }

    $templates = @()
    if ($script:UseGroupNameExtras -and $script:GroupNameExtras.Count -gt 0) {
        $templates = @($script:GroupNameExtras)
    }
    else {
        $templates = @(Get-DefaultGroupNameTemplates)
    }

    $template = [string]$templates[(Get-Random -Minimum 0 -Maximum $templates.Count)]
    $name = Apply-GroupExtraTemplate -Template $template -Contact $Contact -BaseGroupName $baseName -Index ([Math]::Max(0, $Index))
    if ([string]::IsNullOrWhiteSpace($name)) {
        return $baseName
    }

    return $name
}

function Get-DistributedContactBatches {
    param(
        [array]$Sessions,
        [array]$Contacts
    )

    $batches = New-Object System.Collections.Generic.List[object]
    if ($Sessions.Count -eq 0 -or $Contacts.Count -eq 0) { return $batches }

    $baseCount = [Math]::Floor($Contacts.Count / $Sessions.Count)
    $remainder = $Contacts.Count % $Sessions.Count
    $offset = 0

    for ($i = 0; $i -lt $Sessions.Count; $i++) {
        $take = $baseCount
        if ($i -lt $remainder) { $take++ }

        $assigned = @()
        if ($take -gt 0) {
            $assigned = @($Contacts[$offset..($offset + $take - 1)])
        }
        $startIndex = $offset
        $offset += $take

        $batches.Add([pscustomobject]@{
            Session = $Sessions[$i]
            Contacts = $assigned
            StartIndex = $startIndex
        })
    }

    return $batches
}

function Get-RoundRobinContactTasks {
    param(
        [array]$Sessions,
        [array]$Contacts,
        [int]$BatchSize = 1
    )

    $tasks = New-Object System.Collections.Generic.List[object]
    if ($Sessions.Count -eq 0 -or $Contacts.Count -eq 0) { return $tasks }
    $BatchSize = [Math]::Max(1, [Math]::Min(50, $BatchSize))

    for ($i = 0; $i -lt $Contacts.Count; $i++) {
        $session = Get-MaxitochkaSessionForContactIndex -Sessions $Sessions -ContactIndex $i -BatchSize $BatchSize
        $tasks.Add([pscustomobject]@{
            Session = $session
            Contact = $Contacts[$i]
            ContactIndex = $i
        })
    }

    return $tasks
}

function Get-MaxitochkaSessionForContactIndex {
    param(
        [array]$Sessions,
        [int]$ContactIndex,
        [int]$BatchSize = 1
    )

    if ($Sessions.Count -eq 0) { return $null }
    $BatchSize = [Math]::Max(1, [Math]::Min(50, $BatchSize))
    $batchIndex = [int][Math]::Floor([double]([Math]::Max(0, $ContactIndex)) / [double]$BatchSize)
    return $Sessions[$batchIndex % $Sessions.Count]
}

function Get-RoundRobinDistributionLines {
    param(
        [array]$Sessions,
        [array]$Contacts,
        [int]$BatchSize = 1,
        [int]$StartIndex = 0,
        $SentKeys = $null
    )

    if ($Sessions.Count -eq 0) { return @() }

    $BatchSize = [Math]::Max(1, [Math]::Min(50, $BatchSize))
    $counts = @{}
    $skippedBeforeAssignment = 0
    $safeStart = [Math]::Max(0, [Math]::Min($Contacts.Count, $StartIndex))
    for ($i = $safeStart; $i -lt $Contacts.Count; $i++) {
        if ($SentKeys -and (Test-ContactAlreadyWrittenCached -Contact $Contacts[$i] -SentKeys $SentKeys)) {
            $skippedBeforeAssignment++
            continue
        }
        $assignmentIndex = [Math]::Max(0, $i - $skippedBeforeAssignment)
        $session = Get-MaxitochkaSessionForContactIndex -Sessions $Sessions -ContactIndex $assignmentIndex -BatchSize $BatchSize
        $key = "$($session.Profile)|$($session.Port)"
        if (-not $counts.ContainsKey($key)) { $counts[$key] = 0 }
        $counts[$key] = [int]$counts[$key] + 1
    }

    $lines = New-Object System.Collections.Generic.List[string]
    for ($i = 0; $i -lt $Sessions.Count; $i++) {
        $session = $Sessions[$i]
        $key = "$($session.Profile)|$($session.Port)"
        $count = if ($counts.ContainsKey($key)) { [int]$counts[$key] } else { 0 }
        $lines.Add("$($session.Profile) ($($session.Port)): $count")
    }
    return $lines.ToArray()
}

function Get-DefaultAhkPath {
    $command = Get-Command AutoHotkey.exe -ErrorAction SilentlyContinue
    if ($command -and (Test-Path -LiteralPath $command.Source)) {
        return $command.Source
    }

    try {
        $key = [Microsoft.Win32.Registry]::ClassesRoot.OpenSubKey('AutoHotkeyScript\Shell\Open\Command')
        if ($key) {
            $commandText = [string]$key.GetValue('')
            $key.Close()
            $match = [regex]::Match($commandText, '"([^"]+[.]exe)"|^([^"]+?[.]exe)')
            if ($match.Success) {
                $path = if ($match.Groups[1].Success) { $match.Groups[1].Value } else { $match.Groups[2].Value }
                if (Test-Path -LiteralPath $path) { return $path }
            }
        }
    }
    catch {
    }

    $localPrograms = Join-Path $env:LOCALAPPDATA 'Programs\AutoHotkey'
    $candidates = @(
        'C:\Program Files\AutoHotkey\AutoHotkey.exe',
        'C:\Program Files\AutoHotkey\v2\AutoHotkey.exe',
        'C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe',
        'C:\Program Files\AutoHotkey\UX\AutoHotkeyUX.exe',
        'C:\Program Files\AutoHotkey\v1.1\AutoHotkeyU64.exe',
        'C:\Program Files\AutoHotkey\v1.1\AutoHotkeyU32.exe',
        'C:\Program Files (x86)\AutoHotkey\AutoHotkey.exe',
        (Join-Path $localPrograms 'AutoHotkey.exe'),
        (Join-Path $localPrograms 'v2\AutoHotkey.exe'),
        (Join-Path $localPrograms 'v2\AutoHotkey64.exe'),
        (Join-Path $localPrograms 'UX\AutoHotkeyUX.exe')
    )
    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath $candidate) { return $candidate }
    }
    return ''
}

function Resolve-AhkExePath {
    param([string]$Path)

    $candidate = ([string]$Path).Trim().Trim('"')
    if (-not [string]::IsNullOrWhiteSpace($candidate) -and (Test-Path -LiteralPath $candidate)) {
        if ([IO.Path]::GetExtension($candidate).Equals('.exe', [StringComparison]::OrdinalIgnoreCase)) {
            return $candidate
        }
    }

    $default = Get-DefaultAhkPath
    if (-not [string]::IsNullOrWhiteSpace($default) -and (Test-Path -LiteralPath $default)) {
        return $default
    }

    if (-not [string]::IsNullOrWhiteSpace($candidate) -and [IO.Path]::GetExtension($candidate).Equals('.ahk', [StringComparison]::OrdinalIgnoreCase)) {
        throw 'В поле AutoHotkey выбран .ahk файл. Нужно выбрать AutoHotkey.exe, а скрипт печати программа подставит сама.'
    }

    return ''
}

function Get-AhkScriptPath {
    param([string]$ExePath)

    $v2Script = Join-Path $script:AppRoot 'type_text_ahk_v2.ahk'
    $v1Script = Join-Path $script:AppRoot 'type_text_ahk_v1.ahk'
    if ([string]$ExePath -match '\\v2\\|AutoHotkey(32|64)[.]exe$|AutoHotkeyUX[.]exe$') {
        if (Test-Path -LiteralPath $v2Script) { return $v2Script }
    }
    return $v1Script
}

function Invoke-AhkTypeText {
    param(
        [string]$Text,
        [bool]$PressEnter = $true
    )

    if ([string]::IsNullOrWhiteSpace($script:AhkExePath)) {
        $script:AhkExePath = Get-DefaultAhkPath
    }
    $script:AhkExePath = Resolve-AhkExePath $script:AhkExePath
    if ($ahkPathBox -and $ahkPathBox.Text -ne $script:AhkExePath) {
        $ahkPathBox.Text = $script:AhkExePath
    }
    if ([string]::IsNullOrWhiteSpace($script:AhkExePath) -or -not (Test-Path -LiteralPath $script:AhkExePath)) {
        throw 'AutoHotkey.exe не найден. Укажи путь во вкладке Настройки.'
    }
    $ahkScriptPath = Get-AhkScriptPath $script:AhkExePath
    if (-not (Test-Path -LiteralPath $ahkScriptPath)) {
        throw "Не найден AHK-скрипт печати: $ahkScriptPath"
    }

    $tempPath = Join-Path $env:TEMP ("max_contact_text_{0}_{1}.txt" -f $PID, ([Guid]::NewGuid().ToString('N')))
    try {
        Set-Content -LiteralPath $tempPath -Value $Text -Encoding UTF8
        $enterArg = if ($PressEnter) { '1' } else { '0' }
        $process = Start-Process -FilePath $script:AhkExePath -ArgumentList @($ahkScriptPath, $tempPath, $enterArg) -PassThru -WindowStyle Hidden
        Wait-ProcessWithUi -Process $process -PollMs 100
        if ($process.ExitCode -ne 0) {
            throw "AutoHotkey завершился с кодом $($process.ExitCode)"
        }
    }
    finally {
        Remove-Item -LiteralPath $tempPath -ErrorAction SilentlyContinue
    }
}

function New-MaxitochkaAddContactScript {
    param($ContactPayload)

    $json = $ContactPayload | ConvertTo-Json -Depth 6 -Compress
    $template = @'
(async () => {
  const contact = __CONTACT_JSON__;
  const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
  const norm = s => (s || '').trim().replace(/\s+/g, ' ');
  const lower = s => norm(s).toLocaleLowerCase('ru-RU');
  const visible = el => {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    const st = getComputedStyle(el);
    return r.width > 2 && r.height > 2 && st.visibility !== 'hidden' && st.display !== 'none';
  };
  const labelOf = el => norm(el.getAttribute('aria-label') || el.getAttribute('title') || el.getAttribute('placeholder') || el.innerText || el.textContent || '');
  const buttons = () => [...document.querySelectorAll('button,[role="button"],[role="menuitem"]')].filter(visible);
  const clickElement = el => {
    el.scrollIntoView({block: 'center', inline: 'center'});
    el.dispatchEvent(new MouseEvent('mousedown', {bubbles:true, cancelable:true, view:window}));
    el.dispatchEvent(new MouseEvent('mouseup', {bubbles:true, cancelable:true, view:window}));
    el.click();
  };
  const clickLabel = (label, partial = false) => {
    const btn = buttons().find(el => partial ? labelOf(el).includes(label) : labelOf(el) === label);
    if (!btn) return false;
    clickElement(btn);
    return true;
  };
  const pageText = () => norm(document.body.innerText || '');
  const numberNotFoundOpen = () => {
    const text = lower(pageText());
    return text.includes('не нашли номер') ||
      text.includes('отправьте ссылку-приглашение') ||
      text.includes('найти другой номер') ||
      text.includes('скопировать ссылку');
  };
  const closeNumberNotFound = async () => {
    for (let i = 0; i < 5; i++) {
      if (!numberNotFoundOpen()) return true;
      if (clickLabel('Найти другой номер') || clickLabel('Закрыть') || clickLabel('Отменить') || clickLabel('Назад')) {
        await delay(650);
        continue;
      }
      document.dispatchEvent(new KeyboardEvent('keydown', {key:'Escape', code:'Escape', keyCode:27, which:27, bubbles:true}));
      window.dispatchEvent(new KeyboardEvent('keydown', {key:'Escape', code:'Escape', keyCode:27, which:27, bubbles:true}));
      await delay(500);
    }
    return !numberNotFoundOpen();
  };
  const closeOverlays = async () => {
    for (let i = 0; i < 3; i++) {
      if (clickLabel('Закрыть') || clickLabel('Отменить')) {
        await delay(300);
      }
    }
  };
  const typeInput = async (el, value) => {
    el.focus();
    const hasValue = 'value' in el;
    const proto = hasValue && el.tagName.toLowerCase() === 'textarea' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = hasValue ? Object.getOwnPropertyDescriptor(proto, 'value').set : null;
    const setValue = text => {
      if (hasValue) setter.call(el, text);
      else el.textContent = text;
    };
    setValue('');
    el.dispatchEvent(new InputEvent('input', {bubbles:true, inputType:'deleteContentBackward', data:null}));
    await delay(120);
    let current = '';
    for (const ch of String(value || '')) {
      current += ch;
      setValue(current);
      el.dispatchEvent(new KeyboardEvent('keydown', {key: ch, bubbles:true}));
      el.dispatchEvent(new InputEvent('input', {bubbles:true, inputType:'insertText', data: ch}));
      el.dispatchEvent(new KeyboardEvent('keyup', {key: ch, bubbles:true}));
      await delay(70 + Math.floor(Math.random() * 55));
    }
    el.dispatchEvent(new Event('change', {bubbles:true}));
  };
  const addFormOpen = () => buttons().some(el => labelOf(el) === 'Сохранить контакт') &&
    [...document.querySelectorAll('input')].filter(visible).length >= 3;
  const startChatVisible = () => buttons().some(el => labelOf(el) === 'Начать общение');
  const leaveChatIfNeeded = async () => {
    for (let i = 0; i < 5; i++) {
      if (addFormOpen() || startChatVisible()) return true;
      if (clickLabel('Перейти назад') || clickLabel('Назад') || clickLabel('Back')) {
        await delay(850);
        continue;
      }
      const text = pageText();
      if (text.includes('Сообщение') && !startChatVisible()) {
        document.dispatchEvent(new KeyboardEvent('keydown', {key:'Escape', code:'Escape', keyCode:27, which:27, bubbles:true}));
        window.dispatchEvent(new KeyboardEvent('keydown', {key:'Escape', code:'Escape', keyCode:27, which:27, bubbles:true}));
        await delay(500);
        continue;
      }
      break;
    }
    return addFormOpen() || startChatVisible();
  };

  if (!addFormOpen()) {
    await closeOverlays();
    await leaveChatIfNeeded();
    clickLabel('Контакты');
    await delay(700);
    if (!clickLabel('Начать общение')) {
      await leaveChatIfNeeded();
      if (!clickLabel('Начать общение')) {
        return {ok:false, step:'open', error:'Не вышел из текущего чата к кнопке Начать общение'};
      }
    }
    await delay(800);
    if (!clickLabel('Добавить контакт')) {
      return {ok:false, step:'open', error:'Не нашел кнопку Добавить контакт'};
    }
    await delay(1200);
  }

  const inputs = [...document.querySelectorAll('input')].filter(visible);
  const phoneInput = inputs.find(el => !labelOf(el)) || inputs[0];
  const firstInput = inputs.find(el => labelOf(el) === 'Имя') || inputs[1];
  const lastInput = inputs.find(el => labelOf(el).includes('Фамилия')) || inputs[2];
  if (!phoneInput || !firstInput || !lastInput) {
    return {ok:false, step:'fields', error:'Не нашел поля контакта'};
  }

  await typeInput(phoneInput, contact.localPhone || contact.phone || '');
  await delay(350);
  await typeInput(firstInput, contact.firstName || contact.fullName || '');
  await delay(350);
  await typeInput(lastInput, contact.lastName || '');
  await delay(700);

  const save = buttons().find(el => labelOf(el) === 'Сохранить контакт');
  if (!save) return {ok:false, step:'save', error:'Не нашел кнопку Сохранить контакт'};
  if (save.disabled || save.getAttribute('aria-disabled') === 'true') {
    return {ok:false, step:'save', error:'Кнопка сохранения неактивна'};
  }
  clickElement(save);
  for (let i = 0; i < 18; i++) {
    await delay(250);
    if (numberNotFoundOpen()) {
      const closed = await closeNumberNotFound();
      return {
        ok:false,
        step:'not-found',
        code:'number_not_found',
        skipMaxSlot:true,
        closed,
        error:'Не нашли номер в MAX',
        contact: contact.fullName,
        phone: contact.phone
      };
    }
  }

  const body = norm(document.body.innerText || '');
  const knownError = ['Некоррект', 'Ошибка', 'не найден', 'уже есть', 'слишком'].find(x => body.includes(x));
  return {ok: !knownError, step:'done', error: knownError || '', contact: contact.fullName, phone: contact.phone};
})()
'@
    return $template.Replace('__CONTACT_JSON__', $json)
}

function New-MaxitochkaCreateGroupScript {
    param([array]$Contacts, [string]$GroupName, [string]$MessageText = "")

    $payload = [ordered]@{
        groupName = $GroupName
        messageText = $MessageText
        contacts = @($Contacts | ForEach-Object { Get-MaxitochkaContactPayload $_ })
    }
    $json = $payload | ConvertTo-Json -Depth 8 -Compress
    $template = @'
(async () => {
  const job = __GROUP_JSON__;
  const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
  const norm = s => (s || '').trim().replace(/\s+/g, ' ');
  const visible = el => {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    const st = getComputedStyle(el);
    return r.width > 2 && r.height > 2 && st.visibility !== 'hidden' && st.display !== 'none';
  };
  const labelOf = el => norm(el.getAttribute('aria-label') || el.getAttribute('title') || el.getAttribute('placeholder') || el.innerText || el.textContent || '');
  const lower = s => norm(s).toLocaleLowerCase('ru-RU');
  const digitsOf = s => String(s || '').replace(/\D/g, '');
  const buttons = () => [...document.querySelectorAll('button,[role="button"],[role="menuitem"]')].filter(visible);
  const isDisabled = el => !el || el.disabled || el.getAttribute('disabled') !== null ||
    el.getAttribute('aria-disabled') === 'true' || lower(String(el.className || '')).includes('disabled');
  const clickElement = el => {
    const target = el.closest('button,[role="button"],[role="menuitem"],[role="option"],[role="listitem"],[role="row"],[class*="cell"],[class*="Cell"],[class*="contact"],[class*="Contact"]') || el;
    target.scrollIntoView({block: 'center', inline: 'center'});
    try {
      target.dispatchEvent(new PointerEvent('pointerdown', {bubbles:true, cancelable:true, view:window, pointerId:1, pointerType:'mouse', isPrimary:true}));
      target.dispatchEvent(new PointerEvent('pointerup', {bubbles:true, cancelable:true, view:window, pointerId:1, pointerType:'mouse', isPrimary:true}));
    } catch {}
    target.dispatchEvent(new MouseEvent('mousedown', {bubbles:true, cancelable:true, view:window}));
    target.dispatchEvent(new MouseEvent('mouseup', {bubbles:true, cancelable:true, view:window}));
    target.click();
  };
  const clickLabel = (label, partial = false) => {
    const wanted = lower(label);
    const btn = buttons().find(el => {
      const text = labelOf(el);
      const t = lower(text);
      return partial ? t.includes(wanted) : (text === label || t === wanted);
    });
    if (!btn) return false;
    clickElement(btn);
    return true;
  };
  const typeInput = async (el, value) => {
    el.focus();
    const hasValue = 'value' in el;
    const proto = hasValue && el.tagName.toLowerCase() === 'textarea' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = hasValue ? Object.getOwnPropertyDescriptor(proto, 'value').set : null;
    const setValue = text => {
      if (hasValue) setter.call(el, text);
      else el.textContent = text;
    };
    setValue('');
    el.dispatchEvent(new InputEvent('input', {bubbles:true, inputType:'deleteContentBackward', data:null}));
    await delay(120);
    let current = '';
    for (const ch of String(value || '')) {
      current += ch;
      setValue(current);
      el.dispatchEvent(new KeyboardEvent('keydown', {key: ch, bubbles:true}));
      el.dispatchEvent(new InputEvent('input', {bubbles:true, inputType:'insertText', data: ch}));
      el.dispatchEvent(new KeyboardEvent('keyup', {key: ch, bubbles:true}));
      await delay(70 + Math.floor(Math.random() * 55));
    }
    el.dispatchEvent(new Event('change', {bubbles:true}));
  };
  const allInputs = () => [...document.querySelectorAll('input,textarea')].filter(visible);
  const findInput = label => allInputs().find(el => lower(labelOf(el)).includes(lower(label)));
  const findSearchInputByLabel = () => {
    const inputs = allInputs();
    return inputs.find(el => ['найти по имени', 'найти', 'поиск', 'search'].some(x => lower(labelOf(el)).includes(x))) || null;
  };
  const findSearchInput = () => {
    const inputs = allInputs();
    return findSearchInputByLabel() || inputs[0] || null;
  };
  const nextButton = () => buttons().find(el => lower(labelOf(el)) === 'далее' || lower(labelOf(el)).includes('далее'));
  const createButton = () => buttons().find(el => {
    const t = lower(labelOf(el));
    if (!t) return false;
    if (['создать', 'создать группу', 'создать чат', 'готово'].includes(t)) return true;
    return t.includes('создать') && !t.includes('звонок') && !t.includes('канал') && !t.includes('участник');
  });
  const controlLabels = ['контакты', 'чаты', 'звонки', 'настройки', 'все', 'новые', 'каналы', 'начать общение', 'создать группу', 'создать приватный канал', 'создать групповой звонок', 'пригласить по ссылке', 'найти по номеру', 'выберите участников', 'найти по имени', 'разрешите доступ', 'камера', 'микрофон', 'хорошо', 'создать', 'готово', 'далее', 'назад', 'отмена', 'отменить', 'закрыть', 'сохранить контакт'];
  const isControlText = text => {
    const t = lower(text);
    return !t || controlLabels.some(x => t === x || (t.length <= 32 && t.includes(x)));
  };
  const contactWords = contact => lower(contact.fullName || '').split(' ').filter(x => x.length > 1);
  const contactMatchesText = (contact, text) => {
    const t = lower(text);
    if (!t || isControlText(t) || t.includes('max сервисные уведомления')) return false;
    const words = contactWords(contact);
    const hits = words.filter(w => t.includes(w)).length;
    if (words.length > 1 && hits >= Math.min(2, words.length)) return true;
    if (words.length === 1 && hits === 1) return true;
    const textDigits = digitsOf(text);
    const contactDigits = digitsOf(contact.localPhone || contact.phone);
    if (contactDigits.length >= 5) {
      const variants = [contactDigits, contactDigits.slice(-10), contactDigits.slice(-7)].filter(x => x.length >= 5);
      if (variants.some(x => textDigits.includes(x) || t.includes(x))) return true;
    }
    return false;
  };
  const hasSelectedClass = cls => {
    const c = lower(cls).replace(/unchecked|unselected|not-selected/g, '');
    return c.includes('selected') || c.includes('checked') || /(^|[\s_-])(chip|tag)([\s_-]|$)/.test(c);
  };
  const selectionElements = () => [...document.querySelectorAll(
    '[aria-selected="true"],[aria-checked="true"],[data-selected="true"],[data-checked="true"],[class*="selected"],[class*="Selected"],[class*="checked"],[class*="Checked"],[class*="chip"],[class*="Chip"],[class*="tag"],[class*="Tag"]'
  )].filter(visible).filter(el => el.getAttribute('aria-selected') === 'true' || el.getAttribute('aria-checked') === 'true' ||
    el.getAttribute('data-selected') === 'true' || el.getAttribute('data-checked') === 'true' || hasSelectedClass(String(el.className || '')));
  const selectionCount = () => new Set(selectionElements().map(el => lower(labelOf(el))).filter(t => t && !isControlText(t))).size;
  const elementLooksSelected = el => {
    let current = el;
    for (let i = 0; current && i < 4; i++, current = current.parentElement) {
      const aria = current.getAttribute('aria-selected') || current.getAttribute('aria-checked') || current.getAttribute('data-selected') || current.getAttribute('data-checked');
      const cls = String(current.className || '');
      if (aria === 'true' || hasSelectedClass(cls)) return true;
    }
    return false;
  };
  const contactIsSelected = contact => selectionElements().some(el => contactMatchesText(contact, labelOf(el)));
  const contactSearchQueries = contact => {
    const values = [norm(contact.fullName || '')];
    const phone = digitsOf(contact.localPhone || contact.phone);
    if (phone) {
      values.push(phone);
      if (phone.length > 10) values.push(phone.slice(-10));
      if (phone.length > 7) values.push(phone.slice(-7));
    }
    return [...new Set(values.filter(x => x && x.length >= 3))];
  };
  const contactCandidateSelector = 'button,[role="button"],[role="option"],[role="listitem"],[role="row"],[class*="cell"],[class*="Cell"],[class*="contact"],[class*="Contact"]';
  const findContactCandidate = contact => {
    const items = [...document.querySelectorAll(contactCandidateSelector)].filter(visible).map(el => {
      const text = labelOf(el);
      if (!contactMatchesText(contact, text)) return null;
      let score = 1;
      const cls = lower(String(el.className || ''));
      const role = lower(el.getAttribute('role') || '');
      const full = lower(contact.fullName || '');
      if (full && lower(text).includes(full)) score += 8;
      if (cls.includes('cell') || cls.includes('contact')) score += 4;
      if (['option', 'listitem', 'row', 'button'].includes(role)) score += 3;
      if (elementLooksSelected(el)) score -= 2;
      const r = el.getBoundingClientRect();
      return { el, score, top: r.top, left: r.left };
    }).filter(Boolean);
    items.sort((a, b) => b.score - a.score || a.top - b.top || a.left - b.left);
    return items[0] ? items[0].el : null;
  };
  const waitForCandidate = async contact => {
    for (let i = 0; i < 44; i++) {
      const candidate = findContactCandidate(contact);
      if (candidate) return candidate;
      await delay(250);
    }
    return null;
  };
  const waitForSelected = async (contact, beforeNextReady, beforeCount, clicked) => {
    for (let i = 0; i < 18; i++) {
      const nextReady = !isDisabled(nextButton());
      if (contactIsSelected(contact) || elementLooksSelected(clicked) || selectionCount() > beforeCount || (!beforeNextReady && nextReady)) return true;
      await delay(250);
    }
    return contactIsSelected(contact) || elementLooksSelected(clicked) || selectionCount() > beforeCount || (!beforeNextReady && !isDisabled(nextButton()));
  };
  const selectContact = async contact => {
    const attempts = [];
    for (const query of contactSearchQueries(contact)) {
      const search = findSearchInput();
      if (!search) return { ok:false, error:'нет поля поиска' };
      await typeInput(search, query);
      await delay(350);
      const candidate = await waitForCandidate(contact);
      if (!candidate) {
        attempts.push(query);
        continue;
      }
      const beforeNextReady = !isDisabled(nextButton());
      const beforeCount = selectionCount();
      clickElement(candidate);
      const confirmed = await waitForSelected(contact, beforeNextReady, beforeCount, candidate);
      if (confirmed) return { ok:true, query };
      attempts.push(query + ' (клик не подтвердился)');
    }
    return { ok:false, error:'не найден/не выбран: ' + attempts.join(', ') };
  };
  const waitForNameInput = async () => {
    for (let i = 0; i < 24; i++) {
      const inputs = allInputs();
      const byLabel = inputs.find(el => lower(labelOf(el)).includes('название'));
      if (byLabel) return byLabel;
      const search = findSearchInputByLabel();
      const fallback = inputs.find(el => el !== search && !lower(labelOf(el)).includes('найти') && !lower(labelOf(el)).includes('поиск'));
      if (fallback && isDisabled(nextButton())) return fallback;
      await delay(250);
    }
    return null;
  };
  const focusAtEnd = el => {
    el.focus();
    if ('value' in el) {
      const len = String(el.value || '').length;
      if (el.setSelectionRange) el.setSelectionRange(len, len);
      return;
    }
    const range = document.createRange();
    range.selectNodeContents(el);
    range.collapse(false);
    const selection = window.getSelection();
    selection.removeAllRanges();
    selection.addRange(range);
  };
  const textOfEditable = el => 'value' in el ? String(el.value || '') : String(el.innerText || el.textContent || '');
  const clearEditable = async el => {
    el.focus();
    if ('value' in el) {
      const proto = el.tagName.toLowerCase() === 'textarea' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
      setter.call(el, '');
      el.dispatchEvent(new InputEvent('input', {bubbles:true, inputType:'deleteContentBackward', data:null}));
    } else {
      const range = document.createRange();
      range.selectNodeContents(el);
      const selection = window.getSelection();
      selection.removeAllRanges();
      selection.addRange(range);
      document.execCommand('delete', false, null);
      if (textOfEditable(el).trim()) el.textContent = '';
    }
    await delay(150);
  };
  const typeMessage = async (el, value) => {
    const text = String(value || '');
    await clearEditable(el);
    if ('value' in el) {
      const chunks = text.match(/[\s\S]{1,3}/g) || [];
      const proto = el.tagName.toLowerCase() === 'textarea' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
      let current = '';
      for (const chunk of chunks) {
        current += chunk;
        setter.call(el, current);
        el.dispatchEvent(new InputEvent('input', {bubbles:true, inputType:'insertText', data: chunk}));
        await delay(35 + Math.floor(Math.random() * 35));
      }
    } else {
      for (const chunk of Array.from(text)) {
        focusAtEnd(el);
        const inserted = document.execCommand('insertText', false, chunk);
        if (!inserted) {
          el.textContent = textOfEditable(el) + chunk;
        }
        await delay(18 + Math.floor(Math.random() * 25));
      }
    }
    el.dispatchEvent(new Event('change', {bubbles:true}));
  };
  const messageFields = () => {
    const fields = [...document.querySelectorAll('textarea,[contenteditable="true"],div[role="textbox"]')].filter(visible).filter(el => {
      const label = labelOf(el);
      if (label.includes('Найти') || label.includes('Название') || label.includes('Имя') || label.includes('Фамилия')) return false;
      const r = el.getBoundingClientRect();
      return r.bottom > window.innerHeight * 0.35;
    });
    return fields.sort((a, b) => b.getBoundingClientRect().bottom - a.getBoundingClientRect().bottom);
  };
  const waitForComposer = async () => {
    for (let i = 0; i < 40; i++) {
      const field = messageFields()[0];
      if (field) return field;
      await delay(500);
    }
    return null;
  };
  const sendMessage = async (text) => {
    const message = String(text || '').trim();
    if (!message) return {sent:false, reason:'empty'};
    await delay(1800);
    const composer = await waitForComposer();
    if (!composer) return {sent:false, reason:'composer'};
    await typeMessage(composer, message);
    await delay(700);
    const expected = norm(message);
    const typed = norm(textOfEditable(composer));
    if (expected && typed !== expected) {
      await clearEditable(composer);
      return {sent:false, reason:'typed-mismatch', typed: typed.slice(0, 40)};
    }
    const cRect = composer.getBoundingClientRect();
    const send = buttons().find(el => ['Отправить', 'Send'].includes(labelOf(el)) || labelOf(el).includes('Отправить')) ||
      buttons().filter(el => {
        const r = el.getBoundingClientRect();
        return r.bottom >= cRect.top - 12 && r.top <= cRect.bottom + 12 && r.left > cRect.left;
      }).sort((a, b) => b.getBoundingClientRect().left - a.getBoundingClientRect().left)[0];
    if (send && !send.disabled && send.getAttribute('aria-disabled') !== 'true') {
      clickElement(send);
    } else {
      focusAtEnd(composer);
      composer.dispatchEvent(new KeyboardEvent('keydown', {key:'Enter', code:'Enter', keyCode:13, which:13, bubbles:true}));
      composer.dispatchEvent(new KeyboardEvent('keyup', {key:'Enter', code:'Enter', keyCode:13, which:13, bubbles:true}));
    }
    await delay(1800);
    const afterSend = document.body.contains(composer) ? norm(textOfEditable(composer)) : '';
    if (expected && afterSend === expected) {
      return {sent:false, reason:'send-still-in-composer', typed: afterSend.slice(0, 80)};
    }
    return {sent:true};
  };

  const closeOverlays = async () => {
    for (let i = 0; i < 3; i++) {
      if (clickLabel('Закрыть') || clickLabel('Отменить') || clickLabel('Хорошо')) {
        await delay(300);
      }
    }
  };
  const pageText = () => lower(document.body.innerText || '');
  const chatListOpen = () => {
    const text = pageText();
    const tabsVisible = ['все', 'новые', 'каналы'].filter(x => text.includes(x)).length >= 2;
    return tabsVisible && buttons().some(el => lower(labelOf(el)) === 'начать общение');
  };
  const clickTopLeftBack = () => {
    if (clickLabel('Перейти назад') || clickLabel('Назад') || clickLabel('Back')) return true;
    const leftTop = buttons().map(el => ({ el, rect: el.getBoundingClientRect(), text: lower(labelOf(el)) }))
      .filter(x => !isDisabled(x.el) && x.rect.top >= 0 && x.rect.top < 92 && x.rect.left >= 0 && x.rect.left < 96 && x.rect.width >= 20 && x.rect.height >= 20)
      .sort((a, b) => a.rect.left - b.rect.left || a.rect.top - b.rect.top)[0];
    if (!leftTop) return false;
    clickElement(leftTop.el);
    return true;
  };
  const chatIsOnlyYou = () => {
    const text = pageText();
    return text.includes('тут только вы') || text.includes('только вы') || text.includes('only you');
  };
  const leaveConfirmOpen = () => {
    const text = pageText();
    return (text.includes('выйти из чата') || text.includes('leave chat')) &&
      (text.includes('все равно выйти') || text.includes('сможете вернуться') ||
       text.includes('остаться') || text.includes('stay'));
  };
  const groupStillVisible = () => {
    const group = lower(job.groupName || '');
    if (!group) return false;
    return pageText().includes(group);
  };
  const clickLeaveConfirmButton = () => {
    const candidates = buttons().map(el => ({ el, rect: el.getBoundingClientRect(), text: lower(labelOf(el)) }))
      .filter(x => !isDisabled(x.el))
      .filter(x => {
        if (x.text === 'выйти' || x.text === 'leave') return true;
        if ((x.text === 'да' || x.text === 'ок' || x.text === 'ok' || x.text === 'подтвердить') &&
            x.rect.top > window.innerHeight * 0.35) return true;
        return false;
      })
      .sort((a, b) => {
        const ap = (a.text === 'выйти' || a.text === 'leave') ? 0 : 1;
        const bp = (b.text === 'выйти' || b.text === 'leave') ? 0 : 1;
        return ap - bp || b.rect.top - a.rect.top || a.rect.left - b.rect.left;
      });
    if (!candidates.length) return false;
    clickElement(candidates[0].el);
    return true;
  };
  const clickLeaveChatControl = () => {
    return clickLabel('Удалить чат', true) || clickLabel('Удалить группу', true) ||
      clickLabel('Покинуть чат', true) || clickLabel('Выйти из чата', true) ||
      clickLabel('Покинуть', true);
  };
  const clickTopRightMenu = () => {
    const bad = ['звонок', 'позвонить', 'видео', 'поиск', 'назад', 'back'];
    const candidate = buttons().map(el => ({ el, rect: el.getBoundingClientRect(), text: lower(labelOf(el)) }))
      .filter(x => !isDisabled(x.el) && x.rect.top >= 0 && x.rect.top < 96 && x.rect.right > window.innerWidth - 180 &&
        !bad.some(word => x.text.includes(word)))
      .sort((a, b) => b.rect.right - a.rect.right || a.rect.top - b.rect.top)[0];
    if (!candidate) return false;
    clickElement(candidate.el);
    return true;
  };
  const deleteCurrentChatIfOnlyYou = async () => {
    if (!chatIsOnlyYou()) return {deleted:false, reason:'not-only-you'};
    let leaveOpened = false;
    let confirmClicked = false;
    for (let attempt = 0; attempt < 12; attempt++) {
      if (leaveConfirmOpen()) {
        leaveOpened = true;
        if (clickLeaveConfirmButton()) {
          confirmClicked = true;
          for (let wait = 0; wait < 14; wait++) {
            await delay(450);
            if (chatListOpen()) return {deleted:true, confirmed:true};
            if (!leaveConfirmOpen() && !groupStillVisible() && !chatIsOnlyYou()) {
              return {deleted:true, confirmed:true};
            }
          }
        }
        await delay(450);
        continue;
      }
      if (leaveOpened && chatListOpen()) return {deleted:true, confirmed:confirmClicked};
      if (clickLeaveChatControl()) {
        leaveOpened = true;
        await delay(750);
        continue;
      }
      if (clickTopRightMenu()) {
        await delay(650);
        continue;
      }
      await delay(350);
    }
    return {
      deleted:false,
      reason: confirmClicked ? 'leave-confirm-not-completed' : (leaveOpened ? 'leave-confirm-button-not-found' : 'delete-control-not-found')
    };
  };
  const goToChats = async () => {
    for (let attempt = 0; attempt < 5; attempt++) {
      if (chatListOpen()) return true;
      if (pageText().includes('разрешите доступ к камере') || pageText().includes('разрешите доступ к микрофону')) {
        clickLabel('Хорошо');
        await delay(500);
      }
      const chatTab = buttons().map(el => ({ el, text: lower(labelOf(el)), rect: el.getBoundingClientRect() }))
        .filter(x => x.text === 'чаты' || x.text === 'chats')
        .sort((a, b) => b.rect.top - a.rect.top)[0];
      if (chatTab) {
        clickElement(chatTab.el);
        await delay(700);
        continue;
      }
      if (clickTopLeftBack()) {
        await delay(800);
        continue;
      }
      await delay(400);
    }
    return chatListOpen();
  };
  const createGroupMenuOpen = () => buttons().some(el => lower(labelOf(el)) === 'создать группу');
  const clickStartChat = () => {
    return clickLabel('Начать общение') || clickLabel('Начать общение', true);
  };
  const openCreateGroupMenu = async () => {
    for (let attempt = 0; attempt < 3; attempt++) {
      if (createGroupMenuOpen()) return true;
      await closeOverlays();
      if (!await goToChats()) return false;
      if (!clickStartChat()) {
        await delay(500);
        continue;
      }
      for (let i = 0; i < 12; i++) {
        await delay(250);
        if (createGroupMenuOpen()) return true;
      }
    }
    return createGroupMenuOpen();
  };
  const participantsPickerOpen = () => {
    const text = pageText();
    return text.includes('выберите участников') ||
      allInputs().some(el => lower(labelOf(el)).includes('найти по имени'));
  };

  if (buttons().some(el => labelOf(el) === 'Сохранить контакт')) {
    location.reload();
    await delay(3500);
  }
  await closeOverlays();
  await goToChats();
  if (!await openCreateGroupMenu()) {
    return {ok:false, step:'open', error:'Не нашел кнопку Начать общение или меню создания группы'};
  }
  if (!clickLabel('Создать группу')) {
    return {ok:false, step:'open', error:'Не нашел пункт Создать группу'};
  }
  for (let i = 0; i < 24; i++) {
    await delay(250);
    if (participantsPickerOpen()) break;
  }
  if (!participantsPickerOpen()) {
    return {ok:false, step:'open', error:'Открыл Создать группу, но окно выбора участников не появилось'};
  }
  await delay(700);

  const selected = [];
  const missing = [];
  for (const contact of job.contacts) {
    const result = await selectContact(contact);
    if (result.ok) {
      selected.push(contact.fullName);
      await delay(700);
    } else {
      missing.push(contact.fullName + ' (' + result.error + ')');
    }
  }

  if (!selected.length) {
    return {ok:false, step:'select', error:'Не выбраны контакты', selected, missing};
  }
  const next = nextButton();
  if (!next) {
    return {ok:false, step:'next', error:'Не нашел кнопку Далее', selected, missing};
  }
  if (isDisabled(next)) {
    return {ok:false, step:'next', error:'Кнопка Далее неактивна: MAX не подтвердил выбор контактов', selected, missing};
  }
  clickElement(next);
  await delay(1400);

  const nameInput = await waitForNameInput();
  if (!nameInput) {
    return {ok:false, step:'name', error:'Не нашел поле названия группы', selected, missing};
  }
  await typeInput(nameInput, job.groupName || 'Новая группа');
  await delay(800);

  const create = createButton();
  if (!create) {
    return {ok:false, step:'create', error:'Не нашел финальную кнопку создания', selected, missing};
  }
  if (isDisabled(create)) {
    return {ok:false, step:'create', error:'Финальная кнопка неактивна', selected, missing};
  }
  clickElement(create);
  for (let i = 0; i < 18; i++) {
    await delay(250);
    if (chatIsOnlyYou()) break;
  }
  await delay(900);
  if (chatIsOnlyYou()) {
    const cleanup = await deleteCurrentChatIfOnlyYou();
    return {
      ok:true,
      step:'only-you',
      onlyYou:true,
      deleted: !!cleanup.deleted,
      deleteReason: cleanup.reason || '',
      selected,
      missing,
      groupName: job.groupName,
      message: {sent:false, reason:'only-you'},
      url: location.href,
      title: document.title
    };
  }
  const message = await sendMessage(job.messageText);
  return {ok:true, step:'done', selected, missing, groupName: job.groupName, message, url: location.href, title: document.title};
})()
'@
    return $template.Replace('__GROUP_JSON__', $json)
}

function New-MaxitochkaSendCurrentChatMessageScript {
    param([string]$MessageText)

    $payload = [ordered]@{
        messageText = $MessageText
    }
    $json = $payload | ConvertTo-Json -Depth 4 -Compress
    $template = @'
(async () => {
  const job = __MESSAGE_JSON__;
  const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
  const norm = s => (s || '').trim().replace(/\s+/g, ' ');
  const visible = el => {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    const st = getComputedStyle(el);
    return r.width > 2 && r.height > 2 && st.visibility !== 'hidden' && st.display !== 'none';
  };
  const labelOf = el => norm(el.getAttribute('aria-label') || el.getAttribute('title') || el.getAttribute('placeholder') || el.innerText || el.textContent || '');
  const buttons = () => [...document.querySelectorAll('button,[role="button"]')].filter(visible);
  const clickElement = el => {
    el.scrollIntoView({block: 'center', inline: 'center'});
    el.dispatchEvent(new MouseEvent('mousedown', {bubbles:true, cancelable:true, view:window}));
    el.dispatchEvent(new MouseEvent('mouseup', {bubbles:true, cancelable:true, view:window}));
    el.click();
  };
  const focusAtEnd = el => {
    el.focus();
    if ('value' in el) {
      const len = String(el.value || '').length;
      if (el.setSelectionRange) el.setSelectionRange(len, len);
      return;
    }
    const range = document.createRange();
    range.selectNodeContents(el);
    range.collapse(false);
    const selection = window.getSelection();
    selection.removeAllRanges();
    selection.addRange(range);
  };
  const textOfEditable = el => 'value' in el ? String(el.value || '') : String(el.innerText || el.textContent || '');
  const clearEditable = async el => {
    el.focus();
    if ('value' in el) {
      const proto = el.tagName.toLowerCase() === 'textarea' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
      setter.call(el, '');
      el.dispatchEvent(new InputEvent('input', {bubbles:true, inputType:'deleteContentBackward', data:null}));
    } else {
      const range = document.createRange();
      range.selectNodeContents(el);
      const selection = window.getSelection();
      selection.removeAllRanges();
      selection.addRange(range);
      document.execCommand('delete', false, null);
      if (textOfEditable(el).trim()) el.textContent = '';
    }
    await delay(150);
  };
  const typeMessage = async (el, value) => {
    const text = String(value || '');
    await clearEditable(el);
    if ('value' in el) {
      const chunks = text.match(/[\s\S]{1,4}/g) || [];
      const proto = el.tagName.toLowerCase() === 'textarea' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
      let current = '';
      for (const chunk of chunks) {
        current += chunk;
        setter.call(el, current);
        el.dispatchEvent(new InputEvent('input', {bubbles:true, inputType:'insertText', data: chunk}));
        await delay(30 + Math.floor(Math.random() * 35));
      }
    } else {
      for (const chunk of Array.from(text)) {
        focusAtEnd(el);
        const inserted = document.execCommand('insertText', false, chunk);
        if (!inserted) {
          el.textContent = textOfEditable(el) + chunk;
        }
        await delay(16 + Math.floor(Math.random() * 22));
      }
    }
    el.dispatchEvent(new Event('change', {bubbles:true}));
  };
  const messageFields = () => {
    const fields = [...document.querySelectorAll('textarea,[contenteditable="true"],div[role="textbox"]')].filter(visible).filter(el => {
      const label = labelOf(el);
      if (label.includes('Найти') || label.includes('Название') || label.includes('Имя') || label.includes('Фамилия')) return false;
      const r = el.getBoundingClientRect();
      return r.bottom > window.innerHeight * 0.35;
    });
    return fields.sort((a, b) => b.getBoundingClientRect().bottom - a.getBoundingClientRect().bottom);
  };
  const waitForComposer = async () => {
    for (let i = 0; i < 44; i++) {
      const field = messageFields()[0];
      if (field) return field;
      await delay(500);
    }
    return null;
  };
  const message = String(job.messageText || '').trim();
  if (!message) return {sent:false, reason:'empty'};
  const composer = await waitForComposer();
  if (!composer) return {sent:false, reason:'composer'};
  await typeMessage(composer, message);
  await delay(700);
  const expected = norm(message);
  const typed = norm(textOfEditable(composer));
  if (expected && typed !== expected) {
    return {sent:false, reason:'typed-mismatch', typed: typed.slice(0, 80)};
  }
  const cRect = composer.getBoundingClientRect();
  const send = buttons().find(el => ['Отправить', 'Send'].includes(labelOf(el)) || labelOf(el).includes('Отправить')) ||
    buttons().filter(el => {
      const r = el.getBoundingClientRect();
      return r.bottom >= cRect.top - 12 && r.top <= cRect.bottom + 12 && r.left > cRect.left;
    }).sort((a, b) => b.getBoundingClientRect().left - a.getBoundingClientRect().left)[0];
  if (send && !send.disabled && send.getAttribute('aria-disabled') !== 'true') {
    clickElement(send);
  } else {
    focusAtEnd(composer);
    composer.dispatchEvent(new KeyboardEvent('keydown', {key:'Enter', code:'Enter', keyCode:13, which:13, bubbles:true}));
    composer.dispatchEvent(new KeyboardEvent('keyup', {key:'Enter', code:'Enter', keyCode:13, which:13, bubbles:true}));
  }
  await delay(1600);
  const afterSend = document.body.contains(composer) ? norm(textOfEditable(composer)) : '';
  if (expected && afterSend === expected) {
    return {sent:false, reason:'send-still-in-composer', typed: afterSend.slice(0, 80)};
  }
  return {sent:true, reason:''};
})()
'@
    return $template.Replace('__MESSAGE_JSON__', $json)
}

function New-MaxitochkaFocusComposerScript {
    $template = @'
(async () => {
  const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
  const norm = s => (s || '').trim().replace(/\s+/g, ' ');
  const visible = el => {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    const st = getComputedStyle(el);
    return r.width > 2 && r.height > 2 && st.visibility !== 'hidden' && st.display !== 'none';
  };
  const labelOf = el => norm(el.getAttribute('aria-label') || el.getAttribute('title') || el.getAttribute('placeholder') || el.innerText || el.textContent || '');
  const fields = () => [...document.querySelectorAll('textarea,[contenteditable="true"],div[role="textbox"]')].filter(visible).filter(el => {
    const label = labelOf(el);
    if (label.includes('Найти') || label.includes('Название') || label.includes('Имя') || label.includes('Фамилия')) return false;
    const r = el.getBoundingClientRect();
    return r.bottom > window.innerHeight * 0.35;
  }).sort((a, b) => b.getBoundingClientRect().bottom - a.getBoundingClientRect().bottom);
  for (let i = 0; i < 18; i++) {
    const composer = fields()[0];
    if (composer) {
      composer.scrollIntoView({block:'center', inline:'center'});
      composer.focus();
      return {ok:true};
    }
    await delay(500);
  }
  return {ok:false, error:'Не нашел поле сообщения'};
})()
'@
    return $template
}

function New-MaxitochkaCollectRecentMessagesScript {
    $template = @'
(() => {
  const norm = value => String(value || '').replace(/\u00a0/g, ' ').trim().replace(/\s+/g, ' ');
  const visible = el => {
    if (!el) return false;
    const rect = el.getBoundingClientRect();
    const style = getComputedStyle(el);
    return rect.width > 2 && rect.height > 2 && style.visibility !== 'hidden' && style.display !== 'none' && Number(style.opacity || 1) > 0;
  };
  const countOf = value => {
    const text = norm(value);
    let match = text.match(/(?:^|[^\d])(\d{1,3})(?:[^\d]|$)/);
    if (!match) return '';
    const number = parseInt(match[1], 10);
    if (!Number.isFinite(number) || number <= 0 || number > 999) return '';
    return String(number);
  };
  const cleanLine = value => norm(value)
    .replace(/^\d{1,3}\s+/, '')
    .replace(/\s+\d{1,3}$/, '')
    .replace(/\s+\d{1,2}:\d{2}$/, '')
    .trim();
  const junk = /^(MAX|Контакты|Чаты|Настройки|Создать|Добавить|Поиск|Найти|Сообщение|Написать|Отправить|Вложения|Сегодня|Вчера|Online|Offline|Emoji|Attach|Close|Back|Назад|Меню|Звонок|Видео|Микрофон|Профиль|Группа|Участники)$/i;
  const badLine = value => {
    const line = cleanLine(value);
    if (!line || line.length < 2 || line.length > 360) return true;
    if (junk.test(line)) return true;
    if (/^(\d{1,3}|\d{1,2}:\d{2}|прочитан|прочитано|отправлено|доставлено|seen|read|unread|непрочитано)$/i.test(line)) return true;
    return false;
  };
  const colorSignal = value => {
    const match = String(value || '').match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
    if (!match) return false;
    const r = parseInt(match[1], 10);
    const g = parseInt(match[2], 10);
    const b = parseInt(match[3], 10);
    if (![r, g, b].every(Number.isFinite)) return false;
    return (b >= 120 && g >= 80) || (r >= 180 && g <= 120 && b <= 120) || (g >= 150 && r <= 120);
  };
  const roundish = (style, rect) => {
    const radius = parseFloat(style.borderRadius || '0');
    return radius >= Math.min(rect.width, rect.height) * 0.35 || String(style.borderRadius || '').includes('%');
  };
  const messages = [];
  const seen = new Set();
  const addMessage = item => {
    if (!item || !item.text) return;
    const sender = cleanLine(item.sender || item.title || 'Уведомление') || 'Уведомление';
    const text = cleanLine(item.text);
    const count = item.count || '';
    const key = `${sender}|${text}|${count}`.toLowerCase();
    if (seen.has(key)) return;
    seen.add(key);
    messages.push({
      sender,
      title: document.title || 'MAX',
      text,
      source: item.source || 'MAX',
      count,
      url: location.href
    });
  };
  const badgeInfo = root => {
    const nodes = [root, ...root.querySelectorAll('[aria-label],[title],[data-testid],span,div,b,i')].filter(visible).slice(0, 90);
    for (const node of nodes) {
      const rect = node.getBoundingClientRect();
      const style = getComputedStyle(node);
      const meta = norm(`${node.getAttribute('aria-label') || ''} ${node.getAttribute('title') || ''} ${node.getAttribute('data-testid') || ''} ${node.className || ''}`).toLowerCase();
      const text = norm(node.innerText || node.textContent || '');
      const strong = /(unread|badge|counter|notification|непроч|счетчик|уведом)/i.test(meta);
      const numericBadge = /^\d{1,3}$/.test(text) && rect.width <= 96 && rect.height <= 96 && rect.width >= 6 && rect.height >= 6;
      const dotBadge = !text && rect.width >= 5 && rect.height >= 5 && rect.width <= 28 && rect.height <= 28 && roundish(style, rect) && colorSignal(style.backgroundColor);
      const coloredNumeric = numericBadge && (roundish(style, rect) || colorSignal(style.backgroundColor) || colorSignal(style.color));
      if (strong || coloredNumeric || dotBadge) {
        return { count: countOf(`${meta} ${text}`), source: dotBadge ? 'точка' : 'бейдж' };
      }
    }
    return null;
  };
  const textLinesOf = el => {
    const parts = [];
    const push = value => String(value || '').split(/\n+|\t+| {2,}/).map(cleanLine).filter(Boolean).forEach(x => parts.push(x));
    push(el.getAttribute('aria-label'));
    push(el.getAttribute('title'));
    push(el.innerText || el.textContent || '');
    const unique = [];
    const localSeen = new Set();
    for (const part of parts) {
      const key = part.toLowerCase();
      if (localSeen.has(key)) continue;
      localSeen.add(key);
      unique.push(part);
    }
    return unique.filter(line => !badLine(line)).slice(0, 12);
  };
  const parseChatRow = (el, badge) => {
    const lines = textLinesOf(el);
    if (!lines.length) return null;
    const title = lines[0] || document.title || 'MAX';
    let sender = '';
    let preview = '';
    const colonIndex = lines.findIndex(line => /:\s*$/.test(line) || /^.{2,180}?:\s+.+/.test(line));
    if (colonIndex >= 0) {
      const raw = lines[colonIndex];
      let match = raw.match(/^(.{2,180}?)\s+\d{1,3}\s*:\s*(.*)$/) || raw.match(/^(.{2,180}?)\s*:\s*(.*)$/);
      if (match) {
        sender = cleanLine(match[1]);
        preview = cleanLine(match[2]);
      }
      else {
        sender = cleanLine(raw.replace(/:\s*$/, ''));
      }
      if (!preview) {
        preview = lines.slice(colonIndex + 1).find(line => !badLine(line) && line !== sender && line !== title) || '';
      }
    }
    if (!sender && lines.length >= 2) {
      sender = lines[0];
      preview = lines.slice(1).find(line => !badLine(line) && line !== sender) || '';
    }
    if (!sender) sender = title;
    if (!preview) {
      preview = badge && badge.count ? `Новое сообщение (${badge.count})` : 'Новое сообщение';
    }
    return { sender, text: preview, count: badge ? badge.count : '', source: 'строка чата' };
  };

  const title = norm(document.title || '');
  if (/[•●]/.test(title) || /\b(unread|new messages?)\b/i.test(title) || /(непроч|новые сообщения)/i.test(title)) {
    addMessage({ sender: 'MAX', text: 'Есть новое уведомление в заголовке', count: countOf(title), source: 'заголовок' });
  }
  const titleCount = title.match(/[\(\[]\s*(\d{1,3})\s*[\)\]]|^\s*(\d{1,3})\s+|\s+(\d{1,3})\s*$/);
  if (titleCount) addMessage({ sender: 'MAX', text: `Непрочитанных: ${titleCount[1] || titleCount[2] || titleCount[3]}`, count: titleCount[1] || titleCount[2] || titleCount[3], source: 'заголовок' });

  const rowSelectors = [
    '[role="listitem"]',
    '[role="button"]',
    '[data-testid*="chat" i]',
    '[data-testid*="dialog" i]',
    '[data-testid*="conversation" i]',
    '[class*="chat" i]',
    '[class*="dialog" i]',
    '[class*="conversation" i]',
    '[class*="cell" i]',
    'button',
    'a'
  ].join(',');
  const rows = [...document.querySelectorAll(rowSelectors)]
    .filter(visible)
    .filter(el => {
      const rect = el.getBoundingClientRect();
      const text = norm(el.innerText || el.textContent || el.getAttribute('aria-label') || el.getAttribute('title') || '');
      return rect.width >= 90 && rect.height >= 24 && rect.height <= 190 && text.length >= 2 && text.length <= 900;
    })
    .slice(0, 220);
  for (const row of rows) {
    const badge = badgeInfo(row);
    if (!badge) continue;
    addMessage(parseChatRow(row, badge));
    if (messages.length >= 10) break;
  }

  if (messages.length === 0) {
    const all = [...document.querySelectorAll('[aria-label],[title],[data-testid],span,div,b,i,button,a')].filter(visible).slice(0, 700);
    const counts = [];
    for (const el of all) {
      const badge = badgeInfo(el);
      if (!badge) continue;
      if (badge.count && !counts.includes(badge.count)) counts.push(badge.count);
      if (counts.length >= 6) break;
    }
    if (counts.length) {
      addMessage({ sender: 'MAX', text: `Непрочитанных: ${counts.join(', ')}`, count: counts.join(', '), source: 'бейдж' });
    }
  }

  return {
    ok: true,
    url: location.href,
    title: document.title,
    count: messages.length,
    messages: messages.slice(-12)
  };
})()
'@
    return $template
}

function Update-OneByOneRecentMaxMessages {
    param(
        [int]$IntervalSeconds = 2,
        [switch]$Force
    )

    if (-not $script:OneByOneStopSignal) { return $false }
    if ($script:RepliesAutoCheckBusy -or $script:MaxitochkaDevToolsBusy) { return $false }
    if (-not $Force -and ((Get-Date) - $script:OneByOneLastMaxMessageScanAt).TotalSeconds -lt $IntervalSeconds) {
        return $false
    }
    $script:OneByOneLastMaxMessageScanAt = Get-Date

    $sessions = New-Object System.Collections.Generic.List[object]
    $seenSessions = @{}
    foreach ($session in @($script:MaxitochkaSessions | Where-Object { $_.Status -eq 'MAX открыт' })) {
        $key = "$($session.Profile)|$($session.Port)|$($session.PortFile)"
        if ($seenSessions.ContainsKey($key)) { continue }
        $seenSessions[$key] = $true
        $sessions.Add($session)
    }
    if ($sessions.Count -eq 0) {
        foreach ($session in @(Get-SelectedMaxitochkaSessions)) {
            if (-not $session -or $session.Status -ne 'MAX открыт') { continue }
            $key = "$($session.Profile)|$($session.Port)|$($session.PortFile)"
            if ($seenSessions.ContainsKey($key)) { continue }
            $seenSessions[$key] = $true
            $sessions.Add($session)
        }
    }
    if ($sessions.Count -eq 0) {
        if ([string]::IsNullOrWhiteSpace([string]$script:OneByOneStopSignal.HistoryText)) {
            $script:OneByOneStopSignal.HistoryText = 'MAX не найден'
        }
        return $false
    }

    if ([string]::IsNullOrWhiteSpace([string]$script:OneByOneStopSignal.HistoryText)) {
        $script:OneByOneStopSignal.HistoryText = 'Пока новых сообщений MAX нет'
    }

    $changed = $false
    $checked = 0
    $errors = 0
    $sessionCount = [int]$sessions.Count
    $scanInterval = [Math]::Max(1, [int]$IntervalSeconds)
    $targetFullScanSeconds = [Math]::Max($scanInterval, [int]$script:OneByOneNotificationFullScanSeconds)
    $scanRounds = [Math]::Max(1, [int][Math]::Ceiling([double]$targetFullScanSeconds / [double]$scanInterval))
    $batchSize = [Math]::Max(1, [int][Math]::Ceiling([double]$sessionCount / [double]$scanRounds))
    $scanTimeoutMs = if ($sessionCount -gt 8) { 350 } else { 550 }
    $startIndex = [int]$script:OneByOneNotificationScanCursor
    if ($startIndex -lt 0 -or $startIndex -ge $sessionCount) { $startIndex = 0 }

    for ($offset = 0; $offset -lt $batchSize; $offset++) {
        $sessionIndex = ($startIndex + $offset) % $sessionCount
        $session = $sessions[$sessionIndex]
        if (Test-OneByOneStopRequested) { break }
        $checked++
        try {
            $sessionNotifications = New-Object System.Collections.Generic.List[object]
            $target = Get-MaxitochkaPageTarget ([int]$session.Port)
            if ($target) {
                $titleText = Get-MaxNotificationTextFromTitle ([string]$target.title)
                if (-not [string]::IsNullOrWhiteSpace($titleText)) {
                    $sessionNotifications.Add([pscustomobject]@{ Sender = 'MAX'; Text = $titleText }) | Out-Null
                }
            }

            $result = Invoke-MaxitochkaScript -Session $session -Expression (New-MaxitochkaCollectRecentMessagesScript) -TimeoutMs $scanTimeoutMs
            if ($result -and $result.ok -and $result.messages) {
                foreach ($message in @($result.messages)) {
                    $sender = if (-not [string]::IsNullOrWhiteSpace([string]$message.sender)) { [string]$message.sender } elseif (-not [string]::IsNullOrWhiteSpace([string]$message.title)) { [string]$message.title } else { [string]$result.title }
                    $text = [string]$message.text
                    if ([string]::IsNullOrWhiteSpace($text)) { continue }
                    $sessionNotifications.Add([pscustomobject]@{ Sender = $sender; Text = $text }) | Out-Null
                }
            }

            $profile = [string]$session.Profile
            $profileKey = Get-MaxitochkaSessionKey $session
            if ($null -eq $script:OneByOneNotificationBaselineKeys) { $script:OneByOneNotificationBaselineKeys = @{} }
            if ($null -eq $script:OneByOneNotificationBaselineProfiles) { $script:OneByOneNotificationBaselineProfiles = @{} }

            if (-not $script:OneByOneNotificationBaselineProfiles.ContainsKey($profileKey)) {
                for ($notificationIndex = 0; $notificationIndex -lt $sessionNotifications.Count; $notificationIndex++) {
                    $notification = $sessionNotifications[$notificationIndex]
                    $oldKey = Get-OneByOneNotificationKey -Profile $profile -Sender ([string]$notification.Sender) -Text ([string]$notification.Text)
                    $script:OneByOneNotificationBaselineKeys[$oldKey] = $true
                }
                $script:OneByOneNotificationBaselineProfiles[$profileKey] = $true
                continue
            }

            for ($notificationIndex = 0; $notificationIndex -lt $sessionNotifications.Count; $notificationIndex++) {
                $notification = $sessionNotifications[$notificationIndex]
                $sender = [string]$notification.Sender
                $text = [string]$notification.Text
                $newKey = Get-OneByOneNotificationKey -Profile $profile -Sender $sender -Text $text
                if ($script:OneByOneNotificationBaselineKeys.ContainsKey($newKey)) { continue }
                $script:OneByOneNotificationBaselineKeys[$newKey] = $true
                if (Add-OneByOneRecentMaxMessage -Profile $profile -Sender $sender -Text $text) {
                    $changed = $true
                }
            }
        }
        catch {
            $errors++
        }
    }
    if ($sessionCount -gt 0) {
        $script:OneByOneNotificationScanCursor = ($startIndex + [Math]::Max(1, $checked)) % $sessionCount
    }

    if (-not $changed) {
        if ($script:OneByOneRecentMaxMessages -and $script:OneByOneRecentMaxMessages.Count -gt 0) {
            Update-OneByOneRecentMaxMessagesText
        }
        else {
            $script:OneByOneStopSignal.HistoryText = if ($errors -gt 0) { "Пока новых сообщений MAX нет | ошибок: $errors" } else { 'Пока новых сообщений MAX нет' }
        }
    }
    return $changed
}

function Add-ContactsViaMaxitochka {
    $sessions = @(Get-SelectedMaxitochkaSessions)
    $contacts = @(Get-ValidContacts)
    if ($sessions.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show('Сначала нажми "Найти открытые" и выбери MAX-профили со статусом "MAX открыт".', 'Maxitochka', 'OK', 'Warning') | Out-Null
        return
    }
    if ($contacts.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show('Нет контактов со статусом OK.', 'Maxitochka', 'OK', 'Warning') | Out-Null
        return
    }
    if (-not $consentCheck.Checked) {
        [System.Windows.Forms.MessageBox]::Show('Отметь подтверждение согласия контактов перед добавлением.', 'Maxitochka', 'OK', 'Warning') | Out-Null
        return
    }

    $totalActions = $sessions.Count * $contacts.Count
    $confirm = [System.Windows.Forms.MessageBox]::Show(
        "Добавить $($contacts.Count) контактов в $($sessions.Count) MAX-профилей?`nВсего действий: $totalActions",
        'Подтвердить добавление',
        'OKCancel',
        'Question'
    )
    if ($confirm -ne 'OK') { return }

    $ok = 0
    $errors = New-Object System.Collections.Generic.List[string]
    foreach ($session in $sessions) {
        foreach ($contact in $contacts) {
            try {
                $payload = Get-MaxitochkaContactPayload $contact
                $scriptText = New-MaxitochkaAddContactScript $payload
                $result = Invoke-MaxitochkaScript -Session $session -Expression $scriptText -TimeoutMs 25000
                if ($result.ok) {
                    $ok++
                }
                else {
                    $errors.Add("$($session.Profile): $($contact.FullName) - $($result.error)")
                }
                $maxitochkaStatusLabel.Text = "Добавление: $ok/$totalActions"
                [System.Windows.Forms.Application]::DoEvents()
                Start-Sleep -Milliseconds 700
            }
            catch {
                $errors.Add("$($session.Profile): $($contact.FullName) - $($_.Exception.Message)")
            }
        }
    }

    $message = "Готово. Успешно: $ok из $totalActions."
    if ($errors.Count -gt 0) {
        $message += "`nОшибок: $($errors.Count)`n" + (($errors | Select-Object -First 8) -join "`n")
    }
    [System.Windows.Forms.MessageBox]::Show($message, 'Maxitochka', 'OK', 'Information') | Out-Null
}

function Create-GroupViaMaxitochka {
    $sessions = @(Get-SelectedMaxitochkaSessions)
    $contacts = @(Get-ValidContacts)
    $groupName = $groupBox.Text.Trim()
    if ([string]::IsNullOrWhiteSpace($groupName)) { $groupName = 'Новая группа' }

    if ($sessions.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show('Сначала нажми "Найти открытые" и выбери MAX-профили со статусом "MAX открыт".', 'Maxitochka', 'OK', 'Warning') | Out-Null
        return
    }
    if ($contacts.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show('Нет контактов со статусом OK.', 'Maxitochka', 'OK', 'Warning') | Out-Null
        return
    }
    if (-not $consentCheck.Checked) {
        [System.Windows.Forms.MessageBox]::Show('Отметь подтверждение согласия контактов перед созданием группы.', 'Maxitochka', 'OK', 'Warning') | Out-Null
        return
    }

    $confirm = [System.Windows.Forms.MessageBox]::Show(
        "Создать группу ""$groupName"" в $($sessions.Count) MAX-профилей и выбрать $($contacts.Count) контактов?",
        'Подтвердить создание группы',
        'OKCancel',
        'Question'
    )
    if ($confirm -ne 'OK') { return }

    $ok = 0
    $errors = New-Object System.Collections.Generic.List[string]
    foreach ($session in $sessions) {
        try {
            $scriptText = New-MaxitochkaCreateGroupScript -Contacts $contacts -GroupName $groupName
            $result = Invoke-MaxitochkaScript -Session $session -Expression $scriptText -TimeoutMs 90000
            if ($result.ok) {
                $ok++
            }
            else {
                $errors.Add("$($session.Profile): $($result.error)")
            }
            $maxitochkaStatusLabel.Text = "Группы: $ok/$($sessions.Count)"
            [System.Windows.Forms.Application]::DoEvents()
            Start-Sleep -Milliseconds 700
        }
        catch {
            $errors.Add("$($session.Profile): $($_.Exception.Message)")
        }
    }

    $message = "Готово. Создано групп: $ok из $($sessions.Count)."
    if ($errors.Count -gt 0) {
        $message += "`nОшибок: $($errors.Count)`n" + (($errors | Select-Object -First 8) -join "`n")
    }
    [System.Windows.Forms.MessageBox]::Show($message, 'Maxitochka', 'OK', 'Information') | Out-Null
}

function Invoke-OneByOneViaMaxitochka {
    param([switch]$AutoStart)

    if ($script:OneByOneRunning) {
        [System.Windows.Forms.MessageBox]::Show('Обработка уже запущена.', 'MAX: по одному', 'OK', 'Information') | Out-Null
        return
    }

    $sessions = @(Get-SelectedMaxitochkaSessions)
    $contacts = @(Get-ValidContacts)
    if ($sessions.Count -eq 0) {
        if ($AutoStart) {
            if ($delayedStartStatusLabel) { $delayedStartStatusLabel.Text = 'Не запущено: нет MAX' }
            return
        }
        [System.Windows.Forms.MessageBox]::Show('Сначала нажми "Найти открытые" и выбери MAX-профили со статусом "MAX открыт".', 'Maxitochka', 'OK', 'Warning') | Out-Null
        return
    }
    if ($contacts.Count -eq 0) {
        if ($AutoStart) {
            if ($delayedStartStatusLabel) { $delayedStartStatusLabel.Text = 'Не запущено: нет контактов' }
            return
        }
        [System.Windows.Forms.MessageBox]::Show('Нет контактов со статусом OK.', 'Maxitochka', 'OK', 'Warning') | Out-Null
        return
    }
    if (-not $consentCheck.Checked) {
        if ($AutoStart) {
            if ($delayedStartStatusLabel) { $delayedStartStatusLabel.Text = 'Не запущено: нет согласия' }
            return
        }
        [System.Windows.Forms.MessageBox]::Show('Отметь подтверждение согласия контактов перед добавлением и созданием групп.', 'Maxitochka', 'OK', 'Warning') | Out-Null
        return
    }
    if ($groupExtrasBox) {
        Set-GroupNameExtrasFromText $groupExtrasBox.Text
        $script:UseGroupNameExtras = [bool]$useGroupExtrasCheck.Checked
        Save-ProcessingState
    }
    Load-ReplyRecords
    $sentContactKeys = Get-SentReplyContactKeySet
    $peoplePerMax = [Math]::Max(1, [Math]::Min(50, [int]$script:PeoplePerMax))

    if ($script:OneByOneNextIndex -ge $contacts.Count) {
        if ($AutoStart) {
            Refresh-OneByOneStatus
            if ($delayedStartStatusLabel) { $delayedStartStatusLabel.Text = 'Не запущено: очередь завершена' }
            return
        }
        $restart = [System.Windows.Forms.MessageBox]::Show(
            "Все $($contacts.Count) контактов уже отмечены как обработанные.`nНачать очередь сначала?",
            'MAX: по одному',
            'OKCancel',
            'Question'
        )
        if ($restart -ne 'OK') { return }
        $script:OneByOneNextIndex = 0
        Save-ProcessingState
        Refresh-OneByOneStatus
    }

    $queueStartIndex = [int]$script:OneByOneNextIndex
    $remainingTotal = $contacts.Count - $queueStartIndex
    $alreadyWrittenRemaining = 0
    for ($checkIndex = $queueStartIndex; $checkIndex -lt $contacts.Count; $checkIndex++) {
        if (Test-ContactAlreadyWrittenCached -Contact $contacts[$checkIndex] -SentKeys $sentContactKeys) {
            $alreadyWrittenRemaining++
        }
    }
    $pendingToWrite = [Math]::Max(0, $remainingTotal - $alreadyWrittenRemaining)
    if ($pendingToWrite -le 0) {
        $script:OneByOneNextIndex = $contacts.Count
        Save-ProcessingState
        Refresh-OneByOneStatus
        if ($AutoStart) {
            if ($delayedStartStatusLabel) { $delayedStartStatusLabel.Text = 'Не запущено: все уже отправлены' }
            return
        }
        [System.Windows.Forms.MessageBox]::Show('Все оставшиеся люди уже есть в списке отправленных. Повторно писать им не буду.', 'MAX: по одному', 'OK', 'Information') | Out-Null
        return
    }

    $distributionLines = @(Get-RoundRobinDistributionLines -Sessions $sessions -Contacts $contacts -BatchSize $peoplePerMax -StartIndex $queueStartIndex -SentKeys $sentContactKeys)
    $distributionPreview = @($distributionLines | Select-Object -First 12)
    if ($distributionLines.Count -gt 12) {
        $distributionPreview += "... ещё MAX: $($distributionLines.Count - 12)"
    }
    $distribution = $distributionPreview -join "`n"
    $startAt = [int]$script:OneByOneNextIndex + 1
    $textMode = if ($script:MessageTemplates.Count -gt 0) {
        "файл текстов, следующий вариант $(($script:MessageTemplateIndex % $script:MessageTemplates.Count) + 1) из $($script:MessageTemplates.Count)"
    }
    else {
        'текст из поля шаблона'
    }
    $groupMode = if ($script:UseGroupNameExtras -and $script:GroupNameExtras.Count -gt 0) {
        "случайно из списка ($($script:GroupNameExtras.Count) вариантов)"
    }
    else {
        'случайно из стандартных вариантов'
    }

    if (-not $AutoStart) {
        $confirm = [System.Windows.Forms.MessageBox]::Show(
            "Запустить постепенную обработку?`n`nНачать с контакта: $startAt из $($contacts.Count)`nОсталось в очереди: $remainingTotal`nК отправке: $pendingToWrite`nУже в списке отправленных и будут пропущены: $alreadyWrittenRemaining`nMAX-профилей: $($sessions.Count)`nПорядок: по $peoplePerMax человек(а) подряд на одном MAX, потом следующий MAX`nГруппы: $groupMode`nТексты: $textMode`nТемп: примерно $($script:PersonDelaySeconds) сек. на человека, включая добавление, группу и сообщение.`n`nРаспределение:`n$distribution",
            'MAX: по одному',
            'OKCancel',
            'Question'
        )
        if ($confirm -ne 'OK') { return }
    }

    $total = $contacts.Count
    $doneThisRun = 0
    $addedOk = 0
    $groupsOk = 0
    $skippedAlreadyWritten = 0
    $skippedNotFound = 0
    $skippedOnlyYou = 0
    $stopped = $false
    $finishedByStop = $false
    $errors = New-Object System.Collections.Generic.List[string]

    Reset-OneByOneStopSignal
    $script:OneByOneRunning = $true
    Update-OneByOneButtonState
    Show-OneByOneStopWindow
    try {
        if ($form) { $form.WindowState = 'Minimized' }
    }
    catch {
    }
    Set-OneByOneStopInfo -Status 'Работа запущена' -Total $total
    if ($script:OneByOneStopSignal) {
        $script:OneByOneStopSignal.HistoryText = 'Пока новых сообщений MAX нет'
    }
    $loadTextsButton.Enabled = $false
    $clearTextsButton.Enabled = $false

    try {
        $skippedForAssignment = 0
        for ($globalIndex = [int]$script:OneByOneNextIndex; $globalIndex -lt $contacts.Count; $globalIndex++) {
            if (Test-OneByOneStopRequested) {
                $stopped = $true
                break
            }
            if (Wait-OneByOneIfPaused -Status 'Пауза: продолжу со следующего действия после СТАРТ') {
                $stopped = $true
                break
            }
                $contact = $contacts[$globalIndex]
                if (Test-ContactAlreadyWrittenCached -Contact $contact -SentKeys $sentContactKeys) {
                    $skippedAlreadyWritten++
                    $skippedForAssignment++
                    $script:OneByOneNextIndex = $globalIndex + 1
                    Save-ProcessingState
                    Refresh-OneByOneStatus
                    Set-MaxitochkaProgressStatus -Text "Пропущен уже отправленный: $($contact.FullName) | $($script:OneByOneNextIndex)/$total" -Index ($globalIndex + 1) -Total $total -ContactName ([string]$contact.FullName) -Profile 'пропуск'
                    [System.Windows.Forms.Application]::DoEvents()
                    continue
                }
                $assignmentIndex = [Math]::Max(0, $globalIndex - $skippedForAssignment)
                $session = Get-MaxitochkaSessionForContactIndex -Sessions $sessions -ContactIndex $assignmentIndex -BatchSize $peoplePerMax

                $cycleWatch = [Diagnostics.Stopwatch]::StartNew()
                $targetMs = [Math]::Max(10000, [int]$script:PersonDelaySeconds * 1000)
                $displayIndex = $globalIndex + 1
                $groupName = Get-GroupNameForContact -Contact $contact -Index $globalIndex
                Set-MaxitochkaProgressStatus -Text "Переключаюсь на $($session.Profile) | контакт $displayIndex/$total" -Index $displayIndex -Total $total -ContactName ([string]$contact.FullName) -Profile ([string]$session.Profile)
                [System.Windows.Forms.Application]::DoEvents()
                if ($script:ActivateMaxWindow) {
                    try {
                        Invoke-MaxitochkaBringToFront -Session $session -TimeoutMs 6000 | Out-Null
                    }
                    catch {
                        $errors.Add("$($session.Profile): не удалось активировать вкладку MAX: $($_.Exception.Message)")
                    }
                    try {
                        $windowActivated = Invoke-MaxitochkaWindowToFront -Session $session -DelayMs $script:SwitchDelayMs
                        if (-not $windowActivated) {
                            $errors.Add("$($session.Profile): окно Windows не найдено для переключения, действие будет через DevTools")
                        }
                    }
                    catch {
                        $errors.Add("$($session.Profile): не удалось вывести окно MAX на передний план: $($_.Exception.Message)")
                    }
                }
                else {
                    Start-Sleep -Milliseconds 300
                }
                if (Wait-OneByOneIfPaused -Status 'Пауза: продолжу после СТАРТ') {
                    $stopped = $true
                    break
                }

                Set-MaxitochkaProgressStatus -Text "MAX: по одному $displayIndex/$total | $($session.Profile) | $($contact.FullName)" -Index $displayIndex -Total $total -ContactName ([string]$contact.FullName) -Profile ([string]$session.Profile)
                [System.Windows.Forms.Application]::DoEvents()

                $canCreateGroup = $false
                $currentContactNeedsRetry = $false
                $skipDelayForCurrentContact = $false
                try {
                    $payload = Get-MaxitochkaContactPayload $contact
                    $addScript = New-MaxitochkaAddContactScript $payload
                    $addResult = Invoke-MaxitochkaScript -Session $session -Expression $addScript -TimeoutMs 30000
                    if ($addResult.ok -or ([string]$addResult.error) -match 'уже') {
                        $addedOk++
                        $canCreateGroup = $true
                        Set-OneByOneStopInfo -Status "Контакт добавлен/уже был: $($session.Profile) | $($contact.FullName)" -Index $displayIndex -Total $total -ContactName ([string]$contact.FullName) -Profile ([string]$session.Profile)
                        Wait-Cancellable -Milliseconds 1200
                    }
                    else {
                        if ([string]$addResult.code -eq 'number_not_found' -or [bool]$addResult.skipMaxSlot) {
                            $skippedNotFound++
                            $skippedForAssignment++
                            $skipDelayForCurrentContact = $true
                            Set-OneByOneStopInfo -Status "Номер не найден в MAX, пропускаю: $($session.Profile) | $($contact.FullName)" -Index $displayIndex -Total $total -ContactName ([string]$contact.FullName) -Profile ([string]$session.Profile)
                            Set-MaxitochkaProgressStatus -Text "Номер не найден в MAX: $($contact.FullName) | следующий останется на $($session.Profile)" -Index $displayIndex -Total $total -ContactName ([string]$contact.FullName) -Profile ([string]$session.Profile)
                        }
                        else {
                            $errors.Add("$($session.Profile): $($contact.FullName) - контакт не добавлен: $($addResult.error)")
                            Set-OneByOneStopInfo -Status "Ошибка контакта: $($session.Profile) | $($contact.FullName)" -Index $displayIndex -Total $total -ContactName ([string]$contact.FullName) -Profile ([string]$session.Profile)
                        }
                    }
                }
                catch {
                    $errors.Add("$($session.Profile): $($contact.FullName) - ошибка добавления: $($_.Exception.Message)")
                    Set-OneByOneStopInfo -Status "Ошибка добавления: $($session.Profile) | $($contact.FullName)" -Index $displayIndex -Total $total -ContactName ([string]$contact.FullName) -Profile ([string]$session.Profile)
                }

                if ($canCreateGroup) {
                    try {
                        $templateIndexBeforeSend = [int]$script:MessageTemplateIndex
                        $messageTemplate = Take-MessageTemplateForSend
                        $messageText = Apply-Template $messageTemplate $contact $groupName
                        $useAhkMessage = [bool]$script:UseAhkTyping -and -not [string]::IsNullOrWhiteSpace($messageText)
                        $messageForBrowser = if ($useAhkMessage) { "" } else { $messageText }
                        $groupScript = New-MaxitochkaCreateGroupScript -Contacts @($contact) -GroupName $groupName -MessageText $messageForBrowser
                        $groupResult = Invoke-MaxitochkaScript -Session $session -Expression $groupScript -TimeoutMs 90000
                        if ($groupResult.ok) {
                            if ([bool]$groupResult.onlyYou) {
                                $skippedOnlyYou++
                                $deleteText = if ([bool]$groupResult.deleted) { 'пустая группа удалена' } else { 'пустую группу не удалось удалить автоматически' }
                                Set-OneByOneStopInfo -Status "Группа без клиента: $deleteText | $($session.Profile) | $($contact.FullName)" -Index $displayIndex -Total $total -ContactName ([string]$contact.FullName) -Profile ([string]$session.Profile)
                                Set-MaxitochkaProgressStatus -Text "Группа только с нами: $($contact.FullName) | $deleteText | сообщение не отправляю" -Index $displayIndex -Total $total -ContactName ([string]$contact.FullName) -Profile ([string]$session.Profile)
                                if (-not [bool]$groupResult.deleted) {
                                    $reason = if ($groupResult.deleteReason) { [string]$groupResult.deleteReason } else { 'неизвестно' }
                                    $errors.Add("$($session.Profile): $($contact.FullName) - пустая группа не удалена: $reason")
                                    $script:OneByOneCancelRequested = $true
                                    $stopped = $true
                                    [System.Windows.Forms.Application]::DoEvents()
                                    break
                                }
                                if ($script:MessageTemplates.Count -gt 0) {
                                    $script:MessageTemplateIndex = [Math]::Max(0, $templateIndexBeforeSend) % $script:MessageTemplates.Count
                                    if ($messageBox) {
                                        $messageBox.Text = [string]$script:MessageTemplates[$script:MessageTemplateIndex]
                                    }
                                }
                                $doneThisRun++
                                $script:OneByOneNextIndex = $globalIndex + 1
                                Save-ProcessingState
                                Refresh-OneByOneStatus
                                [System.Windows.Forms.Application]::DoEvents()
                                continue
                            }
                            $groupsOk++
                            Set-OneByOneStopInfo -Status "Группа создана: $($session.Profile) | $($contact.FullName)" -Index $displayIndex -Total $total -ContactName ([string]$contact.FullName) -Profile ([string]$session.Profile)
                            $messageSent = $false
                            $messageFailureReason = ''
                            $messageFailureTyped = ''
                            if ($useAhkMessage) {
                                Set-MaxitochkaProgressStatus -Text "AHK: фокусирую $($session.Profile) | контакт $displayIndex/$total" -Index $displayIndex -Total $total -ContactName ([string]$contact.FullName) -Profile ([string]$session.Profile)
                                [System.Windows.Forms.Application]::DoEvents()
                                $focusResult = Focus-MaxitochkaComposerForAhk -Session $session
                                if ($focusResult.ok) {
                                    Invoke-AhkTypeText -Text $messageText -PressEnter $true
                                    $messageSent = $true
                                }
                                else {
                                    $messageFailureReason = "AHK: $($focusResult.error)"
                                }
                            }
                            elseif ($null -ne $groupResult.message -and $null -ne $groupResult.message.sent) {
                                $messageSent = [bool]$groupResult.message.sent
                                if (-not $messageSent) {
                                    $messageFailureReason = if ($groupResult.message.reason) { [string]$groupResult.message.reason } else { 'неизвестно' }
                                    $messageFailureTyped = if ($groupResult.message.typed) { [string]$groupResult.message.typed } else { '' }
                                }
                            }

                            if (-not [string]::IsNullOrWhiteSpace($messageText) -and -not $messageSent) {
                                try {
                                    Set-MaxitochkaProgressStatus -Text "Повторно отправляю текст: $($session.Profile) | контакт $displayIndex/$total" -Index $displayIndex -Total $total -ContactName ([string]$contact.FullName) -Profile ([string]$session.Profile)
                                    [System.Windows.Forms.Application]::DoEvents()
                                    $fallbackScript = New-MaxitochkaSendCurrentChatMessageScript -MessageText $messageText
                                    $fallbackResult = Invoke-MaxitochkaScript -Session $session -Expression $fallbackScript -TimeoutMs 42000
                                    if ($fallbackResult.sent) {
                                        $messageSent = $true
                                        $messageFailureReason = ''
                                        $messageFailureTyped = ''
                                    }
                                    else {
                                        if ($fallbackResult.reason) { $messageFailureReason = [string]$fallbackResult.reason }
                                        if ($fallbackResult.typed) { $messageFailureTyped = [string]$fallbackResult.typed }
                                    }
                                }
                                catch {
                                    if ([string]::IsNullOrWhiteSpace($messageFailureReason)) {
                                        $messageFailureReason = $_.Exception.Message
                                    }
                                }
                            }

                            if (-not [string]::IsNullOrWhiteSpace($messageText) -and -not $messageSent) {
                                $reason = if (-not [string]::IsNullOrWhiteSpace($messageFailureReason)) { $messageFailureReason } else { 'неизвестно' }
                                $typed = if (-not [string]::IsNullOrWhiteSpace($messageFailureTyped)) { " В поле было: $messageFailureTyped" } else { "" }
                                $errors.Add("$($session.Profile): $($contact.FullName) - текст не отправлен: $reason.$typed")
                                $currentContactNeedsRetry = $true
                                $script:OneByOneCancelRequested = $true
                            }
                            if ($messageSent -and -not [string]::IsNullOrWhiteSpace($messageText)) {
                                Register-OneByOneReplyWatch -Session $session -Contact $contact -GroupName $groupName -MessageText $messageText -GroupResult $groupResult
                                $sentKey = Get-ContactReplyKey $contact
                                if (-not [string]::IsNullOrWhiteSpace($sentKey)) {
                                    $sentContactKeys[$sentKey.ToLowerInvariant()] = $true
                                }
                                $messagePreview = ([string]$messageText).Trim()
                                if ($messagePreview.Length -gt 90) { $messagePreview = $messagePreview.Substring(0, 90) + '...' }
                                Set-OneByOneStopInfo -Status "Сообщение отправлено: $($session.Profile) | $($contact.FullName) | $messagePreview" -Index $displayIndex -Total $total -ContactName ([string]$contact.FullName) -Profile ([string]$session.Profile)
                            }
                        }
                        else {
                            $errors.Add("$($session.Profile): $($contact.FullName) - группа не создана: $($groupResult.error)")
                            Set-OneByOneStopInfo -Status "Группа не создана: $($session.Profile) | $($contact.FullName)" -Index $displayIndex -Total $total -ContactName ([string]$contact.FullName) -Profile ([string]$session.Profile)
                        }
                    }
                    catch {
                        $errors.Add("$($session.Profile): $($contact.FullName) - ошибка группы: $($_.Exception.Message)")
                        Set-OneByOneStopInfo -Status "Ошибка группы: $($session.Profile) | $($contact.FullName)" -Index $displayIndex -Total $total -ContactName ([string]$contact.FullName) -Profile ([string]$session.Profile)
                    }
                }

                if ($currentContactNeedsRetry) {
                    if ($script:MessageTemplates.Count -gt 0) {
                        $script:MessageTemplateIndex = [Math]::Max(0, $templateIndexBeforeSend) % $script:MessageTemplates.Count
                        if ($messageBox) {
                            $messageBox.Text = [string]$script:MessageTemplates[$script:MessageTemplateIndex]
                        }
                    }
                    $stopped = $true
                    Set-MaxitochkaProgressStatus -Text "Остановлено: текст не отправлен, контакт останется в очереди $displayIndex/$total" -Index $displayIndex -Total $total -ContactName ([string]$contact.FullName) -Profile ([string]$session.Profile)
                    [System.Windows.Forms.Application]::DoEvents()
                    break
                }

                $doneThisRun++
                $script:OneByOneNextIndex = $globalIndex + 1
                Save-ProcessingState
                Refresh-OneByOneStatus
                Set-OneByOneStopInfo -Status "MAX: по одному $displayIndex/$total" -Index $displayIndex -Total $total -ContactName ([string]$contact.FullName) -Profile ([string]$session.Profile) -AddLog $false
                try { [void](Update-OneByOneRecentMaxMessages -IntervalSeconds ([Math]::Max(1, [int]$script:OneByOneNotificationScanIntervalSeconds)) -Force) } catch {}
                if (Wait-OneByOneIfPaused -Status 'Пауза: продолжу со следующего человека после СТАРТ') {
                    $stopped = $true
                    break
                }

                $cycleWatch.Stop()
                $remainingMs = $targetMs - [int]$cycleWatch.ElapsedMilliseconds
                if ($remainingMs -gt 0 -and -not $skipDelayForCurrentContact -and -not (Test-OneByOneStopRequested)) {
                    $remainingSec = [Math]::Ceiling($remainingMs / 1000)
                    Set-MaxitochkaProgressStatus -Text "MAX: по одному $displayIndex/$total | пауза $remainingSec сек. | контакты $addedOk | группы $groupsOk" -Index $displayIndex -Total $total -ContactName ([string]$contact.FullName) -Profile ([string]$session.Profile) -AddLog $false
                    [System.Windows.Forms.Application]::DoEvents()
                    Wait-Cancellable -Milliseconds $remainingMs
                }

                Set-MaxitochkaProgressStatus -Text "MAX: по одному $displayIndex/$total | контакты $addedOk | группы $groupsOk" -Index $displayIndex -Total $total -ContactName ([string]$contact.FullName) -Profile ([string]$session.Profile) -AddLog $false
                [System.Windows.Forms.Application]::DoEvents()

                if (Test-OneByOneStopRequested) {
                    $stopped = $true
                    Set-MaxitochkaProgressStatus -Text "Остановлено после контакта $displayIndex/$total | контакты $addedOk | группы $groupsOk" -Index $displayIndex -Total $total -ContactName ([string]$contact.FullName) -Profile ([string]$session.Profile)
                    [System.Windows.Forms.Application]::DoEvents()
                    break
                }
        }
    }
    finally {
        $finishedByStop = [bool]($stopped -or $script:OneByOneCancelRequested)
        $script:OneByOneRunning = $false
        $script:OneByOneCancelRequested = $false
        if ($script:OneByOneStopSignal) {
            $script:OneByOneStopSignal.Requested = $false
            $script:OneByOneStopSignal.Paused = $false
            Set-OneByOneStopInfo -Status $(if ($finishedByStop) { 'Остановлено после текущего человека' } else { 'Работа завершена' })
        }
        Update-OneByOneButtonState
        $loadTextsButton.Enabled = $true
        $clearTextsButton.Enabled = $true
        Save-ProcessingState
        Refresh-OneByOneStatus
        Refresh-MessageTemplatesStatus
    }

    $title = if ($finishedByStop) { 'Остановлено' } else { 'Готово' }
    $nextText = if ($script:OneByOneNextIndex -lt $total) {
        "Следующий контакт: $($script:OneByOneNextIndex + 1) из $total"
    }
    else {
        "Очередь завершена: $total из $total"
    }
    $message = "$title.`nЗа этот запуск обработано: $doneThisRun`nПропущено уже отправленных: $skippedAlreadyWritten`nНе найдены в MAX: $skippedNotFound`nГрупп только с нами: $skippedOnlyYou`nДобавлено/уже было: $addedOk`nГрупп создано: $groupsOk`n$nextText"
    if ($errors.Count -gt 0) {
        $message += "`nОшибок: $($errors.Count)`n" + (($errors | Select-Object -First 10) -join "`n")
    }
    [System.Windows.Forms.MessageBox]::Show($message, 'MAX: по одному', 'OK', 'Information') | Out-Null
}

function Invoke-MaxApi {
    param(
        [string]$Method,
        [string]$Url,
        [string]$Token,
        $Body = $null
    )

    $headers = @{ Authorization = $Token }
    if ($null -ne $Body) {
        $json = $Body | ConvertTo-Json -Depth 8
        return Invoke-RestMethod -Method $Method -Uri $Url -Headers $headers -ContentType 'application/json; charset=utf-8' -Body $json
    }

    return Invoke-RestMethod -Method $Method -Uri $Url -Headers $headers
}

function Send-GroupMessage {
    $token = $tokenBox.Text.Trim()
    $chatId = $chatIdBox.Text.Trim()
    $template = $messageBox.Text
    $groupName = $groupBox.Text.Trim()

    if ([string]::IsNullOrWhiteSpace($token) -or [string]::IsNullOrWhiteSpace($chatId)) {
        [System.Windows.Forms.MessageBox]::Show('Укажи токен бота MAX и Chat ID существующего группового чата.', 'MAX', 'OK', 'Warning') | Out-Null
        return
    }

    if (-not $consentCheck.Checked) {
        [System.Windows.Forms.MessageBox]::Show('Отметь подтверждение согласия контактов перед отправкой.', 'MAX', 'OK', 'Warning') | Out-Null
        return
    }

    $contacts = Get-ValidContacts
    if ($contacts.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show('Нет контактов со статусом OK.', 'MAX', 'OK', 'Warning') | Out-Null
        return
    }

    $preview = Apply-Template $template $contacts[0] $groupName
    $confirm = [System.Windows.Forms.MessageBox]::Show(
        "Будет отправлено одно сообщение в чат $chatId.`n`nПример:`n$preview",
        'Подтвердить отправку',
        'OKCancel',
        'Question'
    )
    if ($confirm -ne 'OK') { return }

    try {
        $url = "https://platform-api.max.ru/messages?chat_id=$chatId"
        $body = @{
            text = $preview
            notify = $true
        }
        Invoke-MaxApi -Method 'Post' -Url $url -Token $token -Body $body | Out-Null
        [System.Windows.Forms.MessageBox]::Show('Сообщение отправлено в групповой чат.', 'MAX', 'OK', 'Information') | Out-Null
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show("Ошибка отправки: $($_.Exception.Message)", 'MAX', 'OK', 'Error') | Out-Null
    }
}

function Add-MaxMembers {
    $token = $tokenBox.Text.Trim()
    $chatId = $chatIdBox.Text.Trim()

    if ([string]::IsNullOrWhiteSpace($token) -or [string]::IsNullOrWhiteSpace($chatId)) {
        [System.Windows.Forms.MessageBox]::Show('Укажи токен бота MAX и Chat ID существующего группового чата.', 'MAX', 'OK', 'Warning') | Out-Null
        return
    }

    if (-not $consentCheck.Checked) {
        [System.Windows.Forms.MessageBox]::Show('Отметь подтверждение согласия контактов перед добавлением в чат.', 'MAX', 'OK', 'Warning') | Out-Null
        return
    }

    $userIds = @(
        Get-ValidContacts |
            Where-Object { -not [string]::IsNullOrWhiteSpace($_.MaxUserId) } |
            ForEach-Object { $_.MaxUserId.Trim() }
    )

    if ($userIds.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show('В файле нет MaxUserId. MAX API добавляет участников по user_id, не по телефонному номеру.', 'MAX', 'OK', 'Warning') | Out-Null
        return
    }

    $confirm = [System.Windows.Forms.MessageBox]::Show(
        "Добавить $($userIds.Count) участников в чат $chatId по MaxUserId?",
        'Подтвердить добавление',
        'OKCancel',
        'Question'
    )
    if ($confirm -ne 'OK') { return }

    try {
        $url = "https://platform-api.max.ru/chats/$chatId/members"
        $body = @{ user_ids = $userIds }
        Invoke-MaxApi -Method 'Post' -Url $url -Token $token -Body $body | Out-Null
        [System.Windows.Forms.MessageBox]::Show('Запрос на добавление участников отправлен.', 'MAX', 'OK', 'Information') | Out-Null
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show("Ошибка добавления: $($_.Exception.Message)", 'MAX', 'OK', 'Error') | Out-Null
    }
}

function Choose-SavePath {
    param([string]$Filter, [string]$FileName)

    $dialog = New-Object System.Windows.Forms.SaveFileDialog
    $dialog.Filter = $Filter
    $dialog.FileName = $FileName
    $dialog.OverwritePrompt = $true
    if ($dialog.ShowDialog() -eq 'OK') {
        return $dialog.FileName
    }
    return $null
}

function Get-AppThemePalette {
    param([string]$ThemeName)

    switch ($ThemeName) {
        'Карбон' {
            return [pscustomobject]@{
                Form = '#0F1110'; Panel = '#171A18'; Text = '#F4F1EA'; Muted = '#B4ADA5'
                Input = '#111411'; Button = '#1D211E'; Accent = '#9A9A94'; AccentText = '#111111'; Danger = '#3A3A36'
                Grid = '#121513'; AltGrid = '#171B18'; Header = '#202520'; Border = '#333831'; Selection = '#4A4A45'; SelectionText = '#FFFFFF'
                Row = '#171A18'; RowHover = '#262B26'; Divider = '#30352F'; Arrow = '#B4ADA5'
            }
        }
        'Темная' {
            return [pscustomobject]@{
                Form = '#121212'; Panel = '#2A2A2A'; Text = '#F4F4F2'; Muted = '#B8B8B2'
                Input = '#1A1A1A'; Button = '#303030'; Accent = '#9A9A94'; AccentText = '#111111'; Danger = '#3A3A36'
                Grid = '#171717'; AltGrid = '#202020'; Header = '#2F2F2F'; Border = '#3A3A3A'; Selection = '#4A4A45'; SelectionText = '#FFFFFF'
                Row = '#282828'; RowHover = '#353535'; Divider = '#3A3A3A'; Arrow = '#B8B8B2'
            }
        }
        'COURAGE' {
            return [pscustomobject]@{
                Form = '#0B0C0E'; Panel = '#15171A'; Text = '#F1F2F4'; Muted = '#A3A8AE'
                Input = '#101215'; Button = '#22262B'; Accent = '#C8CDD4'; AccentText = '#0B0C0E'; Danger = '#565B63'
                Grid = '#121416'; AltGrid = '#181B1F'; Header = '#22262B'; Border = '#343A42'; Selection = '#5D6672'; SelectionText = '#FFFFFF'
                Row = '#171A1E'; RowHover = '#252A30'; Divider = '#2B3037'; Arrow = '#C8CDD4'
            }
        }
        'Синяя' {
            return [pscustomobject]@{
                Form = '#EEF5F8'; Panel = '#FBFDFF'; Text = '#132D44'; Muted = '#607687'
                Input = '#FFFFFF'; Button = '#E5EEF4'; Accent = '#2F78B7'; AccentText = '#FFFFFF'; Danger = '#E06F6F'
                Grid = '#FFFFFF'; AltGrid = '#F4F8FA'; Header = '#DDEAF2'; Border = '#CFDDE6'; Selection = '#2F78B7'; SelectionText = '#FFFFFF'
                Row = '#FBFDFF'; RowHover = '#E7F1F5'; Divider = '#D9E5EA'; Arrow = '#6E8494'
            }
        }
        'Зеленая' {
            return [pscustomobject]@{
                Form = '#EFF7F2'; Panel = '#FCFEFC'; Text = '#173326'; Muted = '#63786D'
                Input = '#FFFFFF'; Button = '#E4EEE8'; Accent = '#2F8A61'; AccentText = '#FFFFFF'; Danger = '#D46B68'
                Grid = '#FFFFFF'; AltGrid = '#F5F9F6'; Header = '#DDEBE2'; Border = '#CFDED5'; Selection = '#2F8A61'; SelectionText = '#FFFFFF'
                Row = '#FCFEFC'; RowHover = '#E8F2EC'; Divider = '#DAE6DE'; Arrow = '#6B8275'
            }
        }
        'Розовая' {
            return [pscustomobject]@{
                Form = '#FAF3F6'; Panel = '#FFFFFF'; Text = '#3B2532'; Muted = '#7F6874'
                Input = '#FFFFFF'; Button = '#F1E5EA'; Accent = '#B85A82'; AccentText = '#FFFFFF'; Danger = '#D06A6A'
                Grid = '#FFFFFF'; AltGrid = '#FAF6F8'; Header = '#EEDFE6'; Border = '#E2D1D9'; Selection = '#B85A82'; SelectionText = '#FFFFFF'
                Row = '#FFFFFF'; RowHover = '#F5E9EF'; Divider = '#E8DCE2'; Arrow = '#876F7B'
            }
        }
        'Радуга' {
            return [pscustomobject]@{
                Form = '#10121E'; Panel = '#171A2A'; Text = '#FFF7FA'; Muted = '#BFC7E8'
                Input = '#111629'; Button = '#202642'; Accent = '#FFCA3A'; AccentText = '#171008'; Danger = '#FF5C7A'
                Grid = '#12172A'; AltGrid = '#18203A'; Header = '#20294B'; Border = '#3B4770'; Selection = '#7B5CFF'; SelectionText = '#FFFFFF'
                Row = '#1A2036'; RowHover = '#253052'; Divider = '#313B62'; Arrow = '#7CF7D4'
            }
        }
        'Коричневая' {
            return [pscustomobject]@{
                Form = '#191817'; Panel = '#242220'; Text = '#F6F1EA'; Muted = '#A99E93'
                Input = '#171514'; Button = '#2B2926'; Accent = '#B8896A'; AccentText = '#11100F'; Danger = '#4A2D2D'
                Grid = '#1E1C1A'; AltGrid = '#25221F'; Header = '#302D29'; Border = '#403B35'; Selection = '#665247'; SelectionText = '#FFFFFF'
                Row = '#242220'; RowHover = '#322F2B'; Divider = '#36312D'; Arrow = '#B2A195'
            }
        }
        'Дота' {
            return [pscustomobject]@{
                Form = '#020101'; Panel = '#0A0808'; Text = '#F7E6DF'; Muted = '#A88C84'
                Input = '#050303'; Button = '#161010'; Accent = '#B82E24'; AccentText = '#FFFFFF'; Danger = '#641711'
                Grid = '#080606'; AltGrid = '#100B0B'; Header = '#1A1010'; Border = '#33201D'; Selection = '#7A211A'; SelectionText = '#FFFFFF'
                Row = '#0A0808'; RowHover = '#1D1110'; Divider = '#271816'; Arrow = '#D66B4B'
            }
        }
        'Раст' {
            return [pscustomobject]@{
                Form = '#171512'; Panel = '#211D18'; Text = '#F5E8D6'; Muted = '#B9A184'
                Input = '#11100D'; Button = '#2E271E'; Accent = '#C8662D'; AccentText = '#FFFFFF'; Danger = '#61351F'
                Grid = '#1B1814'; AltGrid = '#242019'; Header = '#342C22'; Border = '#4D3B2B'; Selection = '#8B4E25'; SelectionText = '#FFFFFF'
                Row = '#211D18'; RowHover = '#332B21'; Divider = '#3D3126'; Arrow = '#7FA16A'
            }
        }
        default {
            return [pscustomobject]@{
                Form = '#F4F7F8'; Panel = '#FFFFFF'; Text = '#17212B'; Muted = '#667580'
                Input = '#FFFFFF'; Button = '#EDF3F4'; Accent = '#2F7E7B'; AccentText = '#FFFFFF'; Danger = '#D45F5F'
                Grid = '#FFFFFF'; AltGrid = '#F6F9FA'; Header = '#E8EEF0'; Border = '#D8E2E5'; Selection = '#2F7E7B'; SelectionText = '#FFFFFF'
                Row = '#FFFFFF'; RowHover = '#ECF4F4'; Divider = '#E0E7EA'; Arrow = '#6B7C86'
            }
        }
    }
}

function Get-LowPerformancePalette {
    return [pscustomobject]@{
        Form = '#121212'; Panel = '#2A2A2A'; Text = '#F4F4F2'; Muted = '#B8B8B2'
        Input = '#181818'; Button = '#303030'; Accent = '#8F8F8A'; AccentText = '#111111'; Danger = '#383838'
        Grid = '#171717'; AltGrid = '#202020'; Header = '#2F2F2F'; Border = '#3A3A3A'; Selection = '#4A4A45'; SelectionText = '#FFFFFF'
        Row = '#282828'; RowHover = '#353535'; Divider = '#3A3A3A'; Arrow = '#B8B8B2'
    }
}

function Convert-HtmlColor {
    param([string]$Color)
    return [System.Drawing.ColorTranslator]::FromHtml($Color)
}

function Get-WallpaperTargets {
    if ($script:UiTheme -in @('Дота', 'Радуга', 'COURAGE')) {
        return @($form) | Where-Object { $null -ne $_ }
    }

    return @(
        $rootPanel,
        $titlePanel,
        $navPanel,
        $contentPanel,
        $workTab,
        $settingsTab
    ) | Where-Object { $null -ne $_ }
}

function Clear-AppWallpaperImage {
    foreach ($target in Get-WallpaperTargets) {
        try {
            $target.BackgroundImage = $null
            $target.BackgroundImageLayout = 'None'
        }
        catch {
        }
    }

    if ($script:WallpaperImage) {
        try { $script:WallpaperImage.Dispose() } catch {}
        $script:WallpaperImage = $null
    }
}

function Load-AppWallpaperImage {
    param([string]$Path)

    if ([string]::IsNullOrWhiteSpace($Path) -or -not (Test-Path -LiteralPath $Path)) {
        return $null
    }

    $stream = [System.IO.File]::Open($Path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
    try {
        $source = [System.Drawing.Image]::FromStream($stream)
        try {
            return New-Object System.Drawing.Bitmap($source)
        }
        finally {
            $source.Dispose()
        }
    }
    finally {
        $stream.Dispose()
    }
}

function New-DotaThemeWallpaperBitmap {
    param(
        [int]$Width = 1280,
        [int]$Height = 720
    )

    $bitmap = New-Object System.Drawing.Bitmap($Width, $Height)
    $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
    $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $graphics.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality

    $black = [System.Drawing.Color]::FromArgb(255, 1, 0, 0)
    $red = [System.Drawing.Color]::FromArgb(236, 169, 38, 28)
    $redDark = [System.Drawing.Color]::FromArgb(255, 87, 15, 12)

    $backgroundBrush = New-Object System.Drawing.SolidBrush $black
    $markBrush = New-Object System.Drawing.SolidBrush $red
    $shadowBrush = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(85, 0, 0, 0))
    $cutPen = New-Object System.Drawing.Pen -ArgumentList @([System.Drawing.Color]::FromArgb(255, 4, 0, 0), 26)
    $cutPen.StartCap = [System.Drawing.Drawing2D.LineCap]::Square
    $cutPen.EndCap = [System.Drawing.Drawing2D.LineCap]::Square
    $edgePen = New-Object System.Drawing.Pen -ArgumentList @($redDark, 3)

    try {
        $graphics.FillRectangle($backgroundBrush, 0, 0, $Width, $Height)

        $size = [Math]::Min(145, [Math]::Min($Width, $Height) * 0.22)
        $cx = $Width / 2.0
        $cy = $Height / 2.0
        $x = $cx - ($size / 2.0)
        $y = $cy - ($size / 2.0)
        $j = $size * 0.045

        $shadowRect = New-Object System.Drawing.RectangleF -ArgumentList @([single]($x + 10), [single]($y + 12), [single]$size, [single]$size)
        $graphics.FillRectangle($shadowBrush, $shadowRect)

        $markPoints = [System.Drawing.PointF[]]@(
            (New-Object System.Drawing.PointF -ArgumentList ([single]($x + $j)), ([single]($y + 4))),
            (New-Object System.Drawing.PointF -ArgumentList ([single]($x + $size - 8)), ([single]($y + $j))),
            (New-Object System.Drawing.PointF -ArgumentList ([single]($x + $size - 2)), ([single]($y + $size - 10))),
            (New-Object System.Drawing.PointF -ArgumentList ([single]($x + 8)), ([single]($y + $size - 2))),
            (New-Object System.Drawing.PointF -ArgumentList ([single]($x + 2)), ([single]($y + $size * 0.58))),
            (New-Object System.Drawing.PointF -ArgumentList ([single]($x + 6)), ([single]($y + $size * 0.22)))
        )
        $graphics.FillPolygon($markBrush, $markPoints)
        $graphics.DrawPolygon($edgePen, $markPoints)

        $graphics.DrawLine($cutPen, [single]($x + $size * 0.18), [single]($y + $size * 0.18), [single]($x + $size * 0.82), [single]($y + $size * 0.82))

        $triTop = [System.Drawing.PointF[]]@(
            (New-Object System.Drawing.PointF -ArgumentList ([single]($x + $size * 0.66)), ([single]($y + $size * 0.13))),
            (New-Object System.Drawing.PointF -ArgumentList ([single]($x + $size * 0.92)), ([single]($y + $size * 0.14))),
            (New-Object System.Drawing.PointF -ArgumentList ([single]($x + $size * 0.91)), ([single]($y + $size * 0.39)))
        )
        $triBottom = [System.Drawing.PointF[]]@(
            (New-Object System.Drawing.PointF -ArgumentList ([single]($x + $size * 0.12)), ([single]($y + $size * 0.64))),
            (New-Object System.Drawing.PointF -ArgumentList ([single]($x + $size * 0.35)), ([single]($y + $size * 0.88))),
            (New-Object System.Drawing.PointF -ArgumentList ([single]($x + $size * 0.12)), ([single]($y + $size * 0.91)))
        )
        $cutBrush = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(255, 4, 0, 0))
        try {
            $graphics.FillPolygon($cutBrush, $triTop)
            $graphics.FillPolygon($cutBrush, $triBottom)
        }
        finally {
            $cutBrush.Dispose()
        }
    }
    finally {
        $edgePen.Dispose()
        $cutPen.Dispose()
        $shadowBrush.Dispose()
        $markBrush.Dispose()
        $backgroundBrush.Dispose()
        $graphics.Dispose()
    }

    return $bitmap
}

function New-RainbowThemeWallpaperBitmap {
    param(
        [int]$Width = 1280,
        [int]$Height = 720
    )

    $bitmap = New-Object System.Drawing.Bitmap($Width, $Height)
    $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
    $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $graphics.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality

    $backgroundBrush = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(255, 16, 18, 30))
    $shadeBrush = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(125, 6, 8, 18))
    $pens = New-Object System.Collections.Generic.List[System.Drawing.Pen]

    try {
        $graphics.FillRectangle($backgroundBrush, 0, 0, $Width, $Height)

        $colors = @(
            [System.Drawing.Color]::FromArgb(118, 255, 78, 92),
            [System.Drawing.Color]::FromArgb(108, 255, 180, 58),
            [System.Drawing.Color]::FromArgb(104, 255, 231, 76),
            [System.Drawing.Color]::FromArgb(105, 74, 222, 128),
            [System.Drawing.Color]::FromArgb(112, 58, 169, 255),
            [System.Drawing.Color]::FromArgb(116, 122, 92, 255),
            [System.Drawing.Color]::FromArgb(112, 255, 92, 204)
        )

        $bandWidth = [Math]::Max(120, [int]($Width / 9))
        $startX = -$Width
        for ($i = 0; $i -lt 12; $i++) {
            $pen = New-Object System.Drawing.Pen -ArgumentList @($colors[$i % $colors.Count], $bandWidth)
            $pen.StartCap = [System.Drawing.Drawing2D.LineCap]::Round
            $pen.EndCap = [System.Drawing.Drawing2D.LineCap]::Round
            $pens.Add($pen)
            $x = $startX + ($i * $bandWidth * 0.72)
            $graphics.DrawLine($pen, [single]$x, [single]($Height + 180), [single]($x + $Width * 0.9), [single]-180)
        }

        $graphics.FillRectangle($shadeBrush, 0, 0, $Width, $Height)
    }
    finally {
        foreach ($pen in $pens) { $pen.Dispose() }
        $shadeBrush.Dispose()
        $backgroundBrush.Dispose()
        $graphics.Dispose()
    }

    return $bitmap
}

function New-CourageThemeWallpaperBitmap {
    param(
        [int]$Width = 1280,
        [int]$Height = 720
    )

    $bitmap = New-Object System.Drawing.Bitmap($Width, $Height)
    $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
    $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $graphics.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit
    $graphics.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality

    $backgroundBrush = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(255, 11, 12, 14))
    $panelBrush = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(150, 34, 38, 43))
    $textBrush = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(52, 238, 240, 244))
    $textStrokePen = New-Object System.Drawing.Pen -ArgumentList @([System.Drawing.Color]::FromArgb(74, 255, 255, 255), 2)
    $linePen = New-Object System.Drawing.Pen -ArgumentList @([System.Drawing.Color]::FromArgb(38, 210, 215, 222), 2)
    $fontSize = [single]([Math]::Max(78, [Math]::Min($Width, $Height) / 5.2))
    $font = New-Object System.Drawing.Font -ArgumentList @('Segoe UI Black', $fontSize, [System.Drawing.FontStyle]::Bold, [System.Drawing.GraphicsUnit]::Pixel)
    $path = New-Object System.Drawing.Drawing2D.GraphicsPath

    try {
        $graphics.FillRectangle($backgroundBrush, 0, 0, $Width, $Height)

        for ($i = -1; $i -lt 6; $i++) {
            $x = [single]($i * $Width / 4.0)
            $graphics.DrawLine($linePen, $x, [single]$Height, [single]($x + $Width * 0.55), [single]0)
        }

        $panelRect = New-Object System.Drawing.RectangleF -ArgumentList @([single]($Width * 0.08), [single]($Height * 0.30), [single]($Width * 0.84), [single]($Height * 0.40))
        $graphics.FillRectangle($panelBrush, $panelRect)

        $format = New-Object System.Drawing.StringFormat
        try {
            $format.Alignment = [System.Drawing.StringAlignment]::Center
            $format.LineAlignment = [System.Drawing.StringAlignment]::Center
            $path.AddString('COURAGE', $font.FontFamily, [int][System.Drawing.FontStyle]::Bold, $font.Size, $panelRect, $format)
            $graphics.DrawPath($textStrokePen, $path)
            $graphics.FillPath($textBrush, $path)
        }
        finally {
            $format.Dispose()
        }
    }
    finally {
        $path.Dispose()
        $font.Dispose()
        $linePen.Dispose()
        $textStrokePen.Dispose()
        $textBrush.Dispose()
        $panelBrush.Dispose()
        $backgroundBrush.Dispose()
        $graphics.Dispose()
    }

    return $bitmap
}

function Apply-AppWallpaper {
    Clear-AppWallpaperImage

    if ($wallpaperPathBox) {
        $wallpaperPathBox.Text = [string]$script:WallpaperPath
    }

    if ([bool]$script:LowPerformanceMode) {
        return
    }

    $image = $null
    if ($script:UiTheme -eq 'Дота') {
        $image = New-DotaThemeWallpaperBitmap
    }
    elseif ($script:UiTheme -eq 'Радуга') {
        $image = New-RainbowThemeWallpaperBitmap
    }
    elseif ($script:UiTheme -eq 'COURAGE') {
        $image = New-CourageThemeWallpaperBitmap
    }
    elseif ([string]::IsNullOrWhiteSpace($script:WallpaperPath)) {
        return
    }

    if ($script:UiTheme -notin @('Дота', 'Радуга', 'COURAGE') -and -not (Test-Path -LiteralPath $script:WallpaperPath)) {
        $script:WallpaperPath = ""
        if ($wallpaperPathBox) { $wallpaperPathBox.Text = "" }
        Save-ProcessingState
        return
    }

    try {
        if (-not $image) {
            $image = Load-AppWallpaperImage $script:WallpaperPath
        }
        if (-not $image) { return }

        $script:WallpaperImage = $image
        foreach ($target in Get-WallpaperTargets) {
            try {
                $target.BackgroundImage = $script:WallpaperImage
                $target.BackgroundImageLayout = 'Zoom'
                if (-not ($target -is [System.Windows.Forms.Form])) {
                    $target.BackColor = [System.Drawing.Color]::Transparent
                }
            }
            catch {
            }
        }
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show("Не удалось применить обои: $($_.Exception.Message)", 'Обои', 'OK', 'Warning') | Out-Null
    }
}

function Convert-HtmlColorToColorRef {
    param([string]$Color)

    $drawingColor = Convert-HtmlColor $Color
    return [int]($drawingColor.R -bor ($drawingColor.G -shl 8) -bor ($drawingColor.B -shl 16))
}

function Convert-HtmlColorWithAlpha {
    param(
        [string]$Color,
        [int]$Alpha
    )

    $drawingColor = Convert-HtmlColor $Color
    $safeAlpha = [Math]::Max(0, [Math]::Min(255, $Alpha))
    return [System.Drawing.Color]::FromArgb($safeAlpha, $drawingColor.R, $drawingColor.G, $drawingColor.B)
}

function Test-AppWallpaperEnabled {
    if ([bool]$script:LowPerformanceMode) { return $false }
    return ($script:UiTheme -in @('Дота', 'Радуга', 'COURAGE') -or -not [string]::IsNullOrWhiteSpace([string]$script:WallpaperPath))
}

function Test-AppBackgroundImageEnabled {
    if ([bool]$script:LowPerformanceMode) { return $false }
    return ($script:UiTheme -in @('Дота', 'Радуга', 'COURAGE') -or -not [string]::IsNullOrWhiteSpace([string]$script:WallpaperPath))
}

function Set-ControlBackColorSafe {
    param(
        $Control,
        [System.Drawing.Color]$Color,
        [System.Drawing.Color]$FallbackColor
    )

    if ($null -eq $Control) { return }

    try {
        $Control.BackColor = $Color
    }
    catch {
        try { $Control.BackColor = $FallbackColor } catch {}
    }
}

function Test-ControlInSmoothScrollArea {
    param($Control)

    if ($null -eq $Control) { return $false }

    try {
        $current = $Control
        while ($null -ne $current) {
            if (($settingsScrollPanel -and $current -eq $settingsScrollPanel) -or
                ($settingsMain -and $current -eq $settingsMain)) {
                return $true
            }
            $current = $current.Parent
        }
    }
    catch {
    }

    return $false
}

function New-RoundedRectanglePath {
    param(
        [System.Drawing.Rectangle]$Bounds,
        [int]$Radius
    )

    $path = New-Object System.Drawing.Drawing2D.GraphicsPath
    $diameter = [Math]::Max(1, [Math]::Min($Radius * 2, [Math]::Min($Bounds.Width, $Bounds.Height)))

    if ($diameter -le 2) {
        $path.AddRectangle($Bounds)
        return $path
    }

    $path.AddArc($Bounds.X, $Bounds.Y, $diameter, $diameter, 180, 90)
    $path.AddArc($Bounds.Right - $diameter, $Bounds.Y, $diameter, $diameter, 270, 90)
    $path.AddArc($Bounds.Right - $diameter, $Bounds.Bottom - $diameter, $diameter, $diameter, 0, 90)
    $path.AddArc($Bounds.X, $Bounds.Bottom - $diameter, $diameter, $diameter, 90, 90)
    $path.CloseFigure()
    return $path
}

function New-GooseBitmap {
    param(
        [int]$Size = 64,
        [string]$AccentColor = '#D4B06A',
        [switch]$Rainbow
    )

    $bitmap = New-Object System.Drawing.Bitmap($Size, $Size)
    $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
    $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $graphics.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
    $scale = $Size / 64.0
    $s = { param([double]$Value) [single]($Value * $scale) }
    $rect = {
        param([double]$X, [double]$Y, [double]$W, [double]$H)
        New-Object System.Drawing.RectangleF -ArgumentList @((&$s $X), (&$s $Y), (&$s $W), (&$s $H))
    }
    $point = {
        param([double]$X, [double]$Y)
        New-Object System.Drawing.PointF -ArgumentList @((&$s $X), (&$s $Y))
    }

    $accentBrush = New-Object System.Drawing.SolidBrush (Convert-HtmlColor $AccentColor)
    $rainbowBackBrush = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(255, 16, 18, 30))
    $whiteBrush = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(250, 255, 255, 255))
    $wingBrush = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(230, 222, 232, 242))
    $beakBrush = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(255, 255, 184, 74))
    $eyeBrush = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(255, 25, 28, 36))
    $shadowBrush = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(42, 0, 0, 0))
    $neckPen = New-Object System.Drawing.Pen -ArgumentList @([System.Drawing.Color]::FromArgb(250, 255, 255, 255), (&$s 8))
    $neckPen.StartCap = [System.Drawing.Drawing2D.LineCap]::Round
    $neckPen.EndCap = [System.Drawing.Drawing2D.LineCap]::Round

    try {
        $graphics.Clear([System.Drawing.Color]::Transparent)
        if ($Rainbow) {
            $graphics.FillEllipse($rainbowBackBrush, (&$rect 3 3 58 58))
        }
        else {
            $graphics.FillEllipse($accentBrush, (&$rect 3 3 58 58))
        }
        $graphics.FillEllipse($shadowBrush, (&$rect 17 37 36 12))
        $graphics.DrawBezier($neckPen, (&$point 33 35), (&$point 30 28), (&$point 29 20), (&$point 36 17))

        if ($Rainbow) {
            $goosePath = New-Object System.Drawing.Drawing2D.GraphicsPath
            try {
                $goosePath.AddEllipse((&$rect 16 30 34 19))
                $goosePath.AddEllipse((&$rect 31 11 18 15))
                $graphics.SetClip($goosePath)
                $rainbowColors = @(
                    [System.Drawing.Color]::FromArgb(255, 255, 78, 92),
                    [System.Drawing.Color]::FromArgb(255, 255, 180, 58),
                    [System.Drawing.Color]::FromArgb(255, 255, 231, 76),
                    [System.Drawing.Color]::FromArgb(255, 74, 222, 128),
                    [System.Drawing.Color]::FromArgb(255, 58, 169, 255),
                    [System.Drawing.Color]::FromArgb(255, 122, 92, 255),
                    [System.Drawing.Color]::FromArgb(255, 255, 92, 204)
                )
                $bandWidth = 7
                for ($i = 0; $i -lt $rainbowColors.Count; $i++) {
                    $bandBrush = New-Object System.Drawing.SolidBrush $rainbowColors[$i]
                    try {
                        $graphics.FillRectangle($bandBrush, (&$rect (13 + ($i * $bandWidth)) 8 $bandWidth 45))
                    }
                    finally {
                        $bandBrush.Dispose()
                    }
                }
            }
            finally {
                $graphics.ResetClip()
                $goosePath.Dispose()
            }
        }
        else {
            $graphics.FillEllipse($whiteBrush, (&$rect 16 30 34 19))
            $graphics.FillEllipse($whiteBrush, (&$rect 31 11 18 15))
        }

        $beakPoints = [System.Drawing.PointF[]]@(
            (&$point 48 17),
            (&$point 58 20),
            (&$point 48 23)
        )
        $graphics.FillPolygon($beakBrush, $beakPoints)
        $graphics.FillEllipse($wingBrush, (&$rect 25 36 17 8))
        $graphics.FillEllipse($eyeBrush, (&$rect 40 16 3 3))
    }
    finally {
        $neckPen.Dispose()
        $shadowBrush.Dispose()
        $eyeBrush.Dispose()
        $beakBrush.Dispose()
        $wingBrush.Dispose()
        $whiteBrush.Dispose()
        $rainbowBackBrush.Dispose()
        $accentBrush.Dispose()
        $graphics.Dispose()
    }

    return $bitmap
}

function New-GooseAppIcon {
    param(
        [string]$AccentColor = '#D4B06A',
        [switch]$Rainbow
    )

    $bitmap = New-GooseBitmap -Size 64 -AccentColor $AccentColor -Rainbow:$Rainbow
    $handle = [IntPtr]::Zero
    try {
        $handle = $bitmap.GetHicon()
        $icon = [System.Drawing.Icon]::FromHandle($handle)
        return $icon.Clone()
    }
    finally {
        if ($handle -ne [IntPtr]::Zero) {
            [MaxContactWin32]::DestroyIcon($handle) | Out-Null
        }
        $bitmap.Dispose()
    }
}

function Update-AppGooseIcon {
    param($Palette)

    if ($null -eq $Palette) { return }

    $accentColor = [string]$Palette.Accent
    $useRainbowGoose = ($script:UiTheme -eq 'Радуга')
    if ($form) {
        try {
            $newIcon = New-GooseAppIcon -AccentColor $accentColor -Rainbow:$useRainbowGoose
            $oldIcon = $script:AppIcon
            $form.Icon = $newIcon
            $script:AppIcon = $newIcon
            if ($oldIcon) { $oldIcon.Dispose() }
        }
        catch {
        }
    }

    if ($titleIconLabel) {
        try {
            $newImage = New-GooseBitmap -Size 22 -AccentColor $accentColor -Rainbow:$useRainbowGoose
            $oldImage = $script:AppTitleImage
            $titleIconLabel.Image = $newImage
            $titleIconLabel.ImageAlign = 'MiddleCenter'
            $script:AppTitleImage = $newImage
            if ($oldImage) { $oldImage.Dispose() }
        }
        catch {
        }
    }
}

function Get-NextGoosePhrase {
    $phrases = @($script:GoosePhrases | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) })
    if ($phrases.Count -eq 0) { return '' }

    if (-not $script:GoosePhraseQueue -or $script:GoosePhraseQueue.Count -eq 0) {
        $script:GoosePhraseQueue = New-Object System.Collections.Generic.List[string]
        foreach ($phrase in ($phrases | Sort-Object { Get-Random })) {
            $script:GoosePhraseQueue.Add([string]$phrase)
        }
    }

    $next = [string]$script:GoosePhraseQueue[0]
    $script:GoosePhraseQueue.RemoveAt(0)
    return $next
}

function New-GooseQuackWavBytes {
    $sampleRate = 22050
    $durationSeconds = 0.42
    $samples = [int]($sampleRate * $durationSeconds)
    $dataBytes = $samples * 2
    $stream = New-Object System.IO.MemoryStream
    $writer = New-Object System.IO.BinaryWriter($stream)

    try {
        $writer.Write([Text.Encoding]::ASCII.GetBytes('RIFF'))
        $writer.Write([int](36 + $dataBytes))
        $writer.Write([Text.Encoding]::ASCII.GetBytes('WAVE'))
        $writer.Write([Text.Encoding]::ASCII.GetBytes('fmt '))
        $writer.Write([int]16)
        $writer.Write([int16]1)
        $writer.Write([int16]1)
        $writer.Write([int]$sampleRate)
        $writer.Write([int]($sampleRate * 2))
        $writer.Write([int16]2)
        $writer.Write([int16]16)
        $writer.Write([Text.Encoding]::ASCII.GetBytes('data'))
        $writer.Write([int]$dataBytes)

        $random = New-Object System.Random
        for ($i = 0; $i -lt $samples; $i++) {
            $t = [double]$i / [double]$sampleRate
            $progress = [double]$i / [double]$samples
            $freq = 330.0 - (120.0 * $progress) + (22.0 * [Math]::Sin(2.0 * [Math]::PI * 8.0 * $t))
            $wave = [Math]::Sin(2.0 * [Math]::PI * $freq * $t)
            $wave += 0.45 * [Math]::Sin(2.0 * [Math]::PI * ($freq * 0.52) * $t)
            $wave += 0.20 * (([double]$random.NextDouble() * 2.0) - 1.0)
            $attack = [Math]::Min(1.0, $progress / 0.08)
            $release = [Math]::Min(1.0, (1.0 - $progress) / 0.26)
            $envelope = [Math]::Max(0.0, [Math]::Min($attack, $release))
            $sample = [int16]([Math]::Max(-32767, [Math]::Min(32767, $wave * $envelope * 10500)))
            $writer.Write($sample)
        }

        $writer.Flush()
        return $stream.ToArray()
    }
    finally {
        $writer.Dispose()
        $stream.Dispose()
    }
}

function Play-GooseQuackSound {
    try {
        if ($script:GooseSoundPlayer) {
            try { $script:GooseSoundPlayer.controls.stop() } catch {}
            try { $script:GooseSoundPlayer.Stop() } catch {}
            try { $script:GooseSoundPlayer.Dispose() } catch {}
            try { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($script:GooseSoundPlayer) } catch {}
            $script:GooseSoundPlayer = $null
        }
        if ($script:GooseSoundStream) {
            try { $script:GooseSoundStream.Dispose() } catch {}
            $script:GooseSoundStream = $null
        }

        if (-not (Test-Path -LiteralPath $script:GooseSoundPath)) {
            throw "Файл звука не найден: $($script:GooseSoundPath)"
        }

        $player = New-Object -ComObject WMPlayer.OCX
        $player.settings.volume = [Math]::Max(0, [Math]::Min(100, [int]$script:GooseSoundVolume))
        $player.URL = [string]$script:GooseSoundPath
        $script:GooseSoundPlayer = $player
        $player.controls.play()
    }
    catch {
        try {
            $bytes = New-GooseQuackWavBytes
            $script:GooseSoundStream = New-Object System.IO.MemoryStream(,$bytes)
            $script:GooseSoundPlayer = New-Object System.Media.SoundPlayer($script:GooseSoundStream)
            $script:GooseSoundPlayer.Play()
        }
        catch {
            try { [Console]::Beep(330, 90); [Console]::Beep(230, 150) } catch {}
        }
    }
}

function Show-GoosePhrase {
    if ($NoGui -or -not $titleIconLabel) { return }

    $phrase = Get-NextGoosePhrase
    if ([string]::IsNullOrWhiteSpace($phrase)) { return }

    Play-GooseQuackSound

    try {
        if ($script:GoosePhrasePopupTimer) {
            try { $script:GoosePhrasePopupTimer.Stop() } catch {}
            try { $script:GoosePhrasePopupTimer.Dispose() } catch {}
            $script:GoosePhrasePopupTimer = $null
        }
        if ($script:GoosePhrasePopup) {
            try { $script:GoosePhrasePopup.Close() } catch {}
            try { $script:GoosePhrasePopup.Dispose() } catch {}
            $script:GoosePhrasePopup = $null
        }

        $palette = if ($script:CurrentThemePalette) { $script:CurrentThemePalette } else { Get-AppThemePalette $script:UiTheme }
        $backColor = Convert-HtmlColor $palette.Panel
        $borderColor = Convert-HtmlColor $palette.Border
        $titleColor = Convert-HtmlColor $palette.Accent
        $textColor = Convert-HtmlColor $palette.Text

        $titleFont = New-Object System.Drawing.Font('Segoe UI Semibold', 9)
        $bodyFont = New-Object System.Drawing.Font('Segoe UI', 9)
        $titleText = 'Гусь говорит'
        $titleSize = [System.Windows.Forms.TextRenderer]::MeasureText($titleText, $titleFont)
        $bodySize = [System.Windows.Forms.TextRenderer]::MeasureText($phrase, $bodyFont)
        $popupWidth = [Math]::Min(360, [Math]::Max(210, [Math]::Max($titleSize.Width, $bodySize.Width) + 36))
        $popupHeight = 78

        $popup = New-Object System.Windows.Forms.Form
        $popup.Text = ''
        $popup.FormBorderStyle = 'None'
        $popup.StartPosition = 'Manual'
        $popup.ShowInTaskbar = $false
        $popup.TopMost = $true
        $popup.Size = New-Object System.Drawing.Size($popupWidth, $popupHeight)
        $popup.BackColor = $borderColor
        $popup.Padding = New-Object System.Windows.Forms.Padding(1)

        $layout = New-Object System.Windows.Forms.TableLayoutPanel
        $layout.Dock = 'Fill'
        $layout.ColumnCount = 1
        $layout.RowCount = 2
        $layout.Padding = New-Object System.Windows.Forms.Padding(12, 9, 12, 10)
        $layout.BackColor = $backColor
        $layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 24))) | Out-Null
        $layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
        $popup.Controls.Add($layout)

        $title = New-Object System.Windows.Forms.Label
        $title.Text = $titleText
        $title.Dock = 'Fill'
        $title.TextAlign = 'MiddleLeft'
        $title.ForeColor = $titleColor
        $title.BackColor = [System.Drawing.Color]::Transparent
        $title.Font = $titleFont
        $layout.Controls.Add($title, 0, 0)

        $body = New-Object System.Windows.Forms.Label
        $body.Text = $phrase
        $body.Dock = 'Fill'
        $body.TextAlign = 'TopLeft'
        $body.AutoEllipsis = $false
        $body.ForeColor = $textColor
        $body.BackColor = [System.Drawing.Color]::Transparent
        $body.Font = $bodyFont
        $layout.Controls.Add($body, 0, 1)

        $point = $titleIconLabel.PointToScreen((New-Object System.Drawing.Point -ArgumentList 0, ([int]($titleIconLabel.Height + 8))))
        $screen = [System.Windows.Forms.Screen]::FromControl($form).WorkingArea
        $x = [Math]::Max($screen.Left + 8, [Math]::Min($point.X, $screen.Right - $popupWidth - 8))
        $y = $point.Y
        if (($y + $popupHeight) -gt ($screen.Bottom - 8)) {
            $above = $titleIconLabel.PointToScreen((New-Object System.Drawing.Point -ArgumentList 0, ([int](-$popupHeight - 8))))
            $y = $above.Y
        }
        $y = [Math]::Max($screen.Top + 8, [Math]::Min($y, $screen.Bottom - $popupHeight - 8))
        $popup.Location = New-Object System.Drawing.Point -ArgumentList ([int]$x), ([int]$y)

        $closePopup = {
            try {
                if ($script:GoosePhrasePopupTimer) {
                    $script:GoosePhrasePopupTimer.Stop()
                    $script:GoosePhrasePopupTimer.Dispose()
                    $script:GoosePhrasePopupTimer = $null
                }
                if ($script:GoosePhrasePopup) {
                    $closing = $script:GoosePhrasePopup
                    $script:GoosePhrasePopup = $null
                    $closing.Close()
                    $closing.Dispose()
                }
            }
            catch {
            }
        }
        $popup.Add_Click($closePopup)
        $layout.Add_Click($closePopup)
        $title.Add_Click($closePopup)
        $body.Add_Click($closePopup)

        $timer = New-Object System.Windows.Forms.Timer
        $timer.Interval = 3400
        $timer.Add_Tick($closePopup)
        $script:GoosePhrasePopup = $popup
        $script:GoosePhrasePopupTimer = $timer
        $timer.Start()

        if ($form) {
            [void]$popup.Show($form)
        }
        else {
            [void]$popup.Show()
        }
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show($phrase, 'Гусь говорит', 'OK', 'Information') | Out-Null
    }
}

function Clear-ControlRegion {
    param($Control)

    if ($null -eq $Control) { return }

    try {
        if ($Control.Region) {
            $oldRegion = $Control.Region
            $Control.Region = $null
            $oldRegion.Dispose()
        }
        $Control.AccessibleDescription = ([string]$Control.AccessibleDescription -replace ';?RoundedRegion:\d+', '').Trim(';')
    }
    catch {
    }
}

function Set-ControlRoundedRegion {
    param(
        $Control,
        [int]$Radius = 8,
        [bool]$AttachResize = $true
    )

    if ($null -eq $Control -or $Control.Width -le 0 -or $Control.Height -le 0) { return }

    try {
        if ([bool]$script:LowPerformanceMode) {
            Clear-ControlRegion $Control
            return
        }

        $descriptionBefore = [string]$Control.AccessibleDescription
        Clear-ControlRegion $Control

        $width = [Math]::Max(1, [int]$Control.Width)
        $height = [Math]::Max(1, [int]$Control.Height)
        $effectiveRadius = [Math]::Max(2, [Math]::Min([int]$Radius, [int]([Math]::Min($width, $height) / 3)))
        $bounds = New-Object System.Drawing.Rectangle(0, 0, [Math]::Max(1, $width - 1), [Math]::Max(1, $height - 1))
        $path = New-RoundedRectanglePath -Bounds $bounds -Radius $effectiveRadius
        try {
            $Control.Region = New-Object System.Drawing.Region($path)
        }
        finally {
            $path.Dispose()
        }

        $hasResizeHook = ($descriptionBefore -match 'RoundedRegionHook')
        if ($AttachResize -and -not $hasResizeHook) {
            $Control.Add_SizeChanged({
                param($sender, $eventArgs)
                try {
                    $match = [regex]::Match([string]$sender.AccessibleDescription, 'RoundedRegion:(\d+)')
                    if ($match.Success) {
                        Set-ControlRoundedRegion -Control $sender -Radius ([int]$match.Groups[1].Value) -AttachResize $false
                    }
                }
                catch {
                }
            })
            $hasResizeHook = $true
        }

        $description = ([string]$Control.AccessibleDescription -replace ';?RoundedRegion:\d+', '').Trim(';')
        if ([string]::IsNullOrWhiteSpace($description)) {
            $Control.AccessibleDescription = "RoundedRegion:$effectiveRadius"
        }
        else {
            $Control.AccessibleDescription = "$description;RoundedRegion:$effectiveRadius"
        }
        if ($hasResizeHook -and ([string]$Control.AccessibleDescription -notmatch 'RoundedRegionHook')) {
            $Control.AccessibleDescription = "$($Control.AccessibleDescription);RoundedRegionHook"
        }
    }
    catch {
    }
}

function Enable-ThemedComboBox {
    param([System.Windows.Forms.ComboBox]$Combo)

    if ($null -eq $Combo) { return }

    $Combo.DrawMode = 'OwnerDrawFixed'
    $Combo.ItemHeight = 26
    $Combo.Add_DrawItem({
        param($sender, $eventArgs)

        if ($eventArgs.Index -lt 0) { return }

        $palette = if ($script:CurrentThemePalette) { $script:CurrentThemePalette } else { Get-AppThemePalette $script:UiTheme }
        $wallpaperEnabled = Test-AppWallpaperEnabled
        $isSelected = (($eventArgs.State -band [System.Windows.Forms.DrawItemState]::Selected) -eq [System.Windows.Forms.DrawItemState]::Selected)
        $background = if ($isSelected) {
            if ($wallpaperEnabled) { Convert-HtmlColorWithAlpha $palette.Selection 205 } else { Convert-HtmlColor $palette.Selection }
        }
        else {
            if ($wallpaperEnabled) { Convert-HtmlColorWithAlpha $palette.Input 150 } else { Convert-HtmlColor $palette.Input }
        }
        $foreground = if ($isSelected -and $palette.SelectionText) { Convert-HtmlColor $palette.SelectionText } else { Convert-HtmlColor $palette.Text }
        $backgroundBrush = New-Object System.Drawing.SolidBrush $background

        try {
            $eventArgs.Graphics.FillRectangle($backgroundBrush, $eventArgs.Bounds)
            $textRect = New-Object System.Drawing.Rectangle(
                ($eventArgs.Bounds.Left + 8),
                $eventArgs.Bounds.Top,
                ([Math]::Max(0, $eventArgs.Bounds.Width - 12)),
                $eventArgs.Bounds.Height
            )
            $flags = [System.Windows.Forms.TextFormatFlags]::VerticalCenter -bor
                     [System.Windows.Forms.TextFormatFlags]::Left -bor
                     [System.Windows.Forms.TextFormatFlags]::EndEllipsis
            [System.Windows.Forms.TextRenderer]::DrawText($eventArgs.Graphics, [string]$sender.Items[$eventArgs.Index], $sender.Font, $textRect, $foreground, $flags)
        }
        finally {
            $backgroundBrush.Dispose()
        }
    })
}

function Enable-ThemedTabControl {
    param([System.Windows.Forms.TabControl]$Tabs)

    if ($null -eq $Tabs) { return }

    $Tabs.DrawMode = 'OwnerDrawFixed'
    $Tabs.SizeMode = 'Fixed'
    $Tabs.ItemSize = New-Object System.Drawing.Size(92, 28)
    $Tabs.Add_DrawItem({
        param($sender, $eventArgs)

        if ($eventArgs.Index -lt 0) { return }

        $palette = if ($script:CurrentThemePalette) { $script:CurrentThemePalette } else { Get-AppThemePalette $script:UiTheme }
        $selected = ($eventArgs.Index -eq $sender.SelectedIndex)
        $back = Convert-HtmlColor $(if ($selected) { $palette.Panel } else { $palette.Form })
        $fore = Convert-HtmlColor $(if ($selected) { $palette.Text } else { $palette.Muted })
        $border = Convert-HtmlColor $palette.Border
        $backBrush = New-Object System.Drawing.SolidBrush $back
        $borderPen = New-Object System.Drawing.Pen $border

        try {
            $rect = $eventArgs.Bounds
            $eventArgs.Graphics.FillRectangle($backBrush, $rect)
            $eventArgs.Graphics.DrawRectangle($borderPen, $rect.X, $rect.Y, [Math]::Max(0, $rect.Width - 1), [Math]::Max(0, $rect.Height - 1))
            $flags = [System.Windows.Forms.TextFormatFlags]::HorizontalCenter -bor
                     [System.Windows.Forms.TextFormatFlags]::VerticalCenter -bor
                     [System.Windows.Forms.TextFormatFlags]::EndEllipsis
            [System.Windows.Forms.TextRenderer]::DrawText(
                $eventArgs.Graphics,
                [string]$sender.TabPages[$eventArgs.Index].Text,
                $sender.Font,
                $rect,
                $fore,
                $flags
            )
        }
        finally {
            $backBrush.Dispose()
            $borderPen.Dispose()
        }
    })
}

function Set-WindowFrameTheme {
    param(
        [System.Windows.Forms.Form]$TargetForm,
        $Palette,
        [bool]$UseDarkMode
    )

    if ($null -eq $TargetForm -or $null -eq $Palette) { return }

    try {
        $method = [MaxContactWin32].GetMethod('DwmSetWindowAttribute')
        if (-not $method) { return }

        $darkValue = if ($UseDarkMode) { 1 } else { 0 }
        [void][MaxContactWin32]::DwmSetWindowAttribute($TargetForm.Handle, 20, [ref]$darkValue, 4)
        [void][MaxContactWin32]::DwmSetWindowAttribute($TargetForm.Handle, 19, [ref]$darkValue, 4)

        $borderColor = Convert-HtmlColorToColorRef $(if ($UseDarkMode) { $Palette.Divider } else { $Palette.Border })
        [void][MaxContactWin32]::DwmSetWindowAttribute($TargetForm.Handle, 34, [ref]$borderColor, 4)
    }
    catch {
    }
}

function Enable-DoubleBuffer {
    param($Control)

    if ($null -eq $Control) { return }

    try {
        if ([string]$Control.AccessibleDescription -match 'DoubleBufferedOn') {
            return
        }

        $flags = [System.Reflection.BindingFlags]::NonPublic -bor [System.Reflection.BindingFlags]::Instance
        $styleFlags = [System.Windows.Forms.ControlStyles]::OptimizedDoubleBuffer -bor
                      [System.Windows.Forms.ControlStyles]::AllPaintingInWmPaint
        $setStyle = [System.Windows.Forms.Control].GetMethod('SetStyle', $flags)
        if ($setStyle) {
            [void]$setStyle.Invoke($Control, @($styleFlags, $true))
        }
        $property = [System.Windows.Forms.Control].GetProperty('DoubleBuffered', $flags)
        if ($property) {
            $property.SetValue($Control, $true, $null)
        }
        $updateStyles = [System.Windows.Forms.Control].GetMethod('UpdateStyles', $flags)
        if ($updateStyles) {
            [void]$updateStyles.Invoke($Control, @())
        }

        $description = ([string]$Control.AccessibleDescription).Trim(';')
        if ([string]::IsNullOrWhiteSpace($description)) {
            $Control.AccessibleDescription = 'DoubleBufferedOn'
        }
        elseif ($description -notmatch 'DoubleBufferedOn') {
            $Control.AccessibleDescription = "$description;DoubleBufferedOn"
        }
    }
    catch {
    }
}

function Draw-GooseLoadingScene {
    param(
        [System.Drawing.Graphics]$Graphics,
        [int]$Width,
        [int]$Height
    )

    if ($null -eq $Graphics -or $Width -le 0 -or $Height -le 0) { return }

    $Graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $sky = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
        (New-Object System.Drawing.Rectangle(0, 0, $Width, [Math]::Max(1, $Height))),
        [System.Drawing.Color]::FromArgb(28, 33, 46),
        [System.Drawing.Color]::FromArgb(63, 77, 93),
        [System.Drawing.Drawing2D.LinearGradientMode]::Vertical
    )
    $roadBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(42, 42, 46))
    $grassBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(52, 116, 74))
    $lineBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(235, 205, 104))
    $whiteBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(248, 248, 238))
    $wingBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(215, 222, 211))
    $orangeBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(242, 146, 51))
    $blackBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(23, 23, 24))
    $shadowBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(70, 0, 0, 0))
    $pen = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(245, 154, 62), 3)
    try {
        $Graphics.FillRectangle($sky, 0, 0, $Width, $Height)
        $horizon = [int]($Height * 0.54)
        $Graphics.FillRectangle($grassBrush, 0, $horizon, $Width, [Math]::Max(1, $Height - $horizon))
        $roadTop = [int]($Height * 0.64)
        $roadPoints = New-Object 'System.Drawing.Point[]' 4
        $roadPoints[0] = New-Object System.Drawing.Point -ArgumentList ([int]($Width * 0.18)), ([int]$roadTop)
        $roadPoints[1] = New-Object System.Drawing.Point -ArgumentList ([int]($Width * 0.82)), ([int]$roadTop)
        $roadPoints[2] = New-Object System.Drawing.Point -ArgumentList ([int]$Width), ([int]$Height)
        $roadPoints[3] = New-Object System.Drawing.Point -ArgumentList 0, ([int]$Height)
        $Graphics.FillPolygon($roadBrush, $roadPoints)

        $offset = ($script:GooseLoadingFrame * 12) % 96
        for ($x = -96 + $offset; $x -lt $Width + 96; $x += 96) {
            $Graphics.FillRectangle($lineBrush, $x, [int]($Height * 0.80), 44, 5)
        }

        $xGoose = [int](30 + (($script:GooseLoadingFrame * 9) % [Math]::Max(1, ($Width + 110))) - 60)
        $yGoose = [int]($Height * 0.68) + [int](3 * [Math]::Sin($script:GooseLoadingFrame * 0.65))
        $legSwing = [int](9 * [Math]::Sin($script:GooseLoadingFrame * 0.9))

        $Graphics.FillEllipse($shadowBrush, $xGoose + 4, $yGoose + 47, 74, 12)
        $Graphics.FillEllipse($whiteBrush, $xGoose + 9, $yGoose + 18, 54, 34)
        $Graphics.FillEllipse($wingBrush, $xGoose + 24, $yGoose + 25, 24, 17)
        $Graphics.FillEllipse($whiteBrush, $xGoose + 51, $yGoose + 4, 24, 24)
        $beakPoints = New-Object 'System.Drawing.Point[]' 3
        $beakPoints[0] = New-Object System.Drawing.Point -ArgumentList ([int]($xGoose + 72)), ([int]($yGoose + 14))
        $beakPoints[1] = New-Object System.Drawing.Point -ArgumentList ([int]($xGoose + 91)), ([int]($yGoose + 18))
        $beakPoints[2] = New-Object System.Drawing.Point -ArgumentList ([int]($xGoose + 72)), ([int]($yGoose + 22))
        $Graphics.FillPolygon($orangeBrush, $beakPoints)
        $Graphics.FillEllipse($blackBrush, $xGoose + 66, $yGoose + 12, 4, 4)
        $Graphics.DrawLine($pen, $xGoose + 27, $yGoose + 48, $xGoose + 19 + $legSwing, $yGoose + 62)
        $Graphics.DrawLine($pen, $xGoose + 45, $yGoose + 48, $xGoose + 53 - $legSwing, $yGoose + 62)
        $Graphics.DrawLine($pen, $xGoose + 18 + $legSwing, $yGoose + 62, $xGoose + 9 + $legSwing, $yGoose + 62)
        $Graphics.DrawLine($pen, $xGoose + 52 - $legSwing, $yGoose + 62, $xGoose + 63 - $legSwing, $yGoose + 62)
    }
    finally {
        foreach ($item in @($sky, $roadBrush, $grassBrush, $lineBrush, $whiteBrush, $wingBrush, $orangeBrush, $blackBrush, $shadowBrush, $pen)) {
            try { if ($item) { $item.Dispose() } } catch {}
        }
    }
}

function Show-GooseLoading {
    param(
        $Owner,
        [string]$Text = 'Гусь бежит по дороге...'
    )

    if ($script:GooseLoadingForm) {
        Update-GooseLoadingText $Text
        return
    }

    $loadingForm = New-Object System.Windows.Forms.Form
    $loadingForm.Text = 'Загрузка'
    $loadingForm.FormBorderStyle = 'None'
    $loadingForm.StartPosition = 'CenterParent'
    $loadingForm.ShowInTaskbar = $false
    $loadingForm.TopMost = $true
    $loadingForm.Size = New-Object System.Drawing.Size(420, 210)
    $loadingForm.BackColor = [System.Drawing.Color]::FromArgb(18, 20, 27)
    $loadingForm.Padding = New-Object System.Windows.Forms.Padding(1)
    $loadingForm.Font = New-Object System.Drawing.Font('Segoe UI', 9)
    Enable-DoubleBuffer $loadingForm

    $layout = New-Object System.Windows.Forms.TableLayoutPanel
    $layout.Dock = 'Fill'
    $layout.RowCount = 2
    $layout.ColumnCount = 1
    $layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
    $layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 46))) | Out-Null
    $loadingForm.Controls.Add($layout)

    $panel = New-Object System.Windows.Forms.Panel
    $panel.Dock = 'Fill'
    $panel.Margin = New-Object System.Windows.Forms.Padding(8, 8, 8, 0)
    Enable-DoubleBuffer $panel
    $panel.Add_Paint({
        param($sender, $eventArgs)
        try {
            Draw-GooseLoadingScene -Graphics $eventArgs.Graphics -Width $sender.ClientSize.Width -Height $sender.ClientSize.Height
        }
        catch {
            try {
                $eventArgs.Graphics.Clear([System.Drawing.Color]::FromArgb(28, 33, 46))
                $fallbackBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(235, 238, 244))
                $fallbackFont = New-Object System.Drawing.Font('Segoe UI Semibold', 12)
                $eventArgs.Graphics.DrawString('Гусь бежит...', $fallbackFont, $fallbackBrush, 18, 18)
            }
            finally {
                try { if ($fallbackBrush) { $fallbackBrush.Dispose() } } catch {}
                try { if ($fallbackFont) { $fallbackFont.Dispose() } } catch {}
            }
        }
    })
    $layout.Controls.Add($panel, 0, 0)

    $label = New-Object System.Windows.Forms.Label
    $label.Text = $Text
    $label.Dock = 'Fill'
    $label.TextAlign = 'MiddleCenter'
    $label.ForeColor = [System.Drawing.Color]::FromArgb(235, 238, 244)
    $label.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 10)
    $layout.Controls.Add($label, 0, 1)

    $timer = New-Object System.Windows.Forms.Timer
    $timer.Interval = 42
    $timer.Add_Tick({
        $script:GooseLoadingFrame++
        if ($script:GooseLoadingPanel) { $script:GooseLoadingPanel.Invalidate() }
    })

    $script:GooseLoadingForm = $loadingForm
    $script:GooseLoadingPanel = $panel
    $script:GooseLoadingLabel = $label
    $script:GooseLoadingTimer = $timer
    $script:GooseLoadingFrame = 0
    $timer.Start()
    if ($Owner) { [void]$loadingForm.Show($Owner) } else { [void]$loadingForm.Show() }
    [System.Windows.Forms.Application]::DoEvents()
}

function Update-GooseLoadingText {
    param([string]$Text)

    if ($script:GooseLoadingLabel -and -not [string]::IsNullOrWhiteSpace($Text)) {
        $script:GooseLoadingLabel.Text = $Text
    }
    if ($script:GooseLoadingPanel) { $script:GooseLoadingPanel.Invalidate() }
    [System.Windows.Forms.Application]::DoEvents()
}

function Hide-GooseLoading {
    try { if ($script:GooseLoadingTimer) { $script:GooseLoadingTimer.Stop(); $script:GooseLoadingTimer.Dispose() } } catch {}
    try { if ($script:GooseLoadingForm) { $script:GooseLoadingForm.Close(); $script:GooseLoadingForm.Dispose() } } catch {}
    $script:GooseLoadingForm = $null
    $script:GooseLoadingPanel = $null
    $script:GooseLoadingLabel = $null
    $script:GooseLoadingTimer = $null
}

function Enable-SmoothPanelScroll {
    param([System.Windows.Forms.ScrollableControl]$Panel)

    if ($null -eq $Panel) { return }

    try {
        $Panel.TabStop = $true
        Enable-DoubleBuffer $Panel
        $Panel.Add_MouseEnter({
            param($sender, $eventArgs)
            try { $sender.Focus() } catch {}
        })
        $Panel.Add_MouseWheel({
            param($sender, $eventArgs)
            try {
                if (-not $sender.VerticalScroll.Visible) { return }
                try { $eventArgs.Handled = $true } catch {}

                $notches = [Math]::Max(1, [Math]::Abs([int]$eventArgs.Delta) / 120)
                $direction = if ($eventArgs.Delta -gt 0) { -1 } else { 1 }
                $step = [Math]::Max(28, [int]($sender.ClientSize.Height * 0.10))
                $target = [int]$sender.VerticalScroll.Value + ([int]($direction * $step * $notches))
                $maxValue = [Math]::Max(0, [int]$sender.VerticalScroll.Maximum - [int]$sender.VerticalScroll.LargeChange + 1)
                $target = [Math]::Max(0, [Math]::Min($maxValue, $target))
                if ($target -eq [int]$sender.VerticalScroll.Value) { return }

                $sender.AutoScrollPosition = New-Object System.Drawing.Point -ArgumentList 0, ([int]$target)
            }
            catch {
            }
        })
    }
    catch {
    }
}

function Set-DataGridLayout {
    param([System.Windows.Forms.DataGridView]$GridControl)

    if ($null -eq $GridControl) { return }

    Enable-DoubleBuffer $GridControl
    $GridControl.BorderStyle = 'None'
    $GridControl.CellBorderStyle = 'SingleHorizontal'
    $GridControl.ColumnHeadersBorderStyle = 'None'
    $GridControl.RowHeadersBorderStyle = 'None'
    $GridControl.AllowUserToResizeRows = $false
    if ([bool]$script:LowPerformanceMode) {
        $GridControl.CellBorderStyle = 'None'
        $GridControl.ColumnHeadersHeight = 34
        $GridControl.RowTemplate.Height = 30
        $GridControl.DefaultCellStyle.Padding = New-Object System.Windows.Forms.Padding(6, 0, 6, 0)
        $GridControl.AlternatingRowsDefaultCellStyle.Padding = New-Object System.Windows.Forms.Padding(6, 0, 6, 0)
        $GridControl.ColumnHeadersDefaultCellStyle.Padding = New-Object System.Windows.Forms.Padding(6, 0, 6, 0)
    }
    else {
        $GridControl.ColumnHeadersHeight = 38
        $GridControl.RowTemplate.Height = 34
        $GridControl.DefaultCellStyle.Padding = New-Object System.Windows.Forms.Padding(10, 0, 10, 0)
        $GridControl.AlternatingRowsDefaultCellStyle.Padding = New-Object System.Windows.Forms.Padding(10, 0, 10, 0)
        $GridControl.ColumnHeadersDefaultCellStyle.Padding = New-Object System.Windows.Forms.Padding(10, 0, 10, 0)
    }
}

function Set-ControlTheme {
    param($Control, $Palette)

    if ($null -eq $Control) { return }

    if ($Control -is [System.Windows.Forms.Panel] -or
        $Control -is [System.Windows.Forms.TableLayoutPanel] -or
        $Control -is [System.Windows.Forms.FlowLayoutPanel] -or
        $Control -is [System.Windows.Forms.TabControl] -or
        $Control -is [System.Windows.Forms.TabPage]) {
        Enable-DoubleBuffer $Control
    }

    $wallpaperEnabled = Test-AppWallpaperEnabled
    $textColor = Convert-HtmlColor $Palette.Text
    $panelColor = Convert-HtmlColor $Palette.Panel
    $inputColor = Convert-HtmlColor $Palette.Input
    $buttonColor = Convert-HtmlColor $Palette.Button
    $borderColor = Convert-HtmlColor $Palette.Border
    $mutedColor = Convert-HtmlColor $Palette.Muted
    $accentTextColor = Convert-HtmlColor $(if ($Palette.AccentText) { $Palette.AccentText } else { $Palette.Text })
    $selectionTextColor = Convert-HtmlColor $(if ($Palette.SelectionText) { $Palette.SelectionText } else { $Palette.Text })
    $hoverColor = Convert-HtmlColor $(if ($Palette.RowHover) { $Palette.RowHover } else { $Palette.Header })
    $transparentColor = [System.Drawing.Color]::Transparent
    $glassRowColor = Convert-HtmlColorWithAlpha $Palette.Row 118
    $glassButtonColor = Convert-HtmlColorWithAlpha $Palette.Button 138
    $glassSelectionColor = Convert-HtmlColorWithAlpha $Palette.Selection 205
    $glassHoverColor = Convert-HtmlColorWithAlpha $(if ($Palette.RowHover) { $Palette.RowHover } else { $Palette.Header }) 165
    $solidScrollArea = Test-ControlInSmoothScrollArea $Control
    $useGlass = $wallpaperEnabled -and -not $solidScrollArea

    try {
        if ($Control -is [System.Windows.Forms.Form]) {
            $Control.BackColor = Convert-HtmlColor $Palette.Form
            $Control.ForeColor = $textColor
        }
        elseif ($Control -is [System.Windows.Forms.TabControl]) {
            Set-ControlBackColorSafe -Control $Control -Color $(if ($useGlass) { $transparentColor } else { Convert-HtmlColor $Palette.Form }) -FallbackColor (Convert-HtmlColor $Palette.Form)
            $Control.ForeColor = $textColor
        }
        elseif ($Control -is [System.Windows.Forms.TabPage]) {
            Set-ControlBackColorSafe -Control $Control -Color $(if ($useGlass) { $transparentColor } else { Convert-HtmlColor $Palette.Form }) -FallbackColor (Convert-HtmlColor $Palette.Form)
            $Control.ForeColor = $textColor
        }
        elseif ($Control -is [System.Windows.Forms.Button]) {
            $isMenuRow = ([string]$Control.AccessibleName -eq 'MenuRow')
            $isPrimaryAction = ([string]$Control.AccessibleName -eq 'PrimaryAction')
            $isNavButton = ([string]$Control.AccessibleName -eq 'NavButton')
            $buttonBackColor = if ($isPrimaryAction) {
                Convert-HtmlColor $Palette.Accent
            }
            elseif ($isNavButton) {
                if ($useGlass) { Convert-HtmlColorWithAlpha $Palette.Form 92 } else { Convert-HtmlColor $Palette.Form }
            }
            elseif ($isMenuRow) {
                if ($useGlass) { $glassRowColor } else { Convert-HtmlColor $Palette.Row }
            }
            else {
                if ($useGlass) { $glassButtonColor } else { $buttonColor }
            }
            Set-ControlBackColorSafe -Control $Control -Color $buttonBackColor -FallbackColor $buttonColor
            $Control.ForeColor = if ($isPrimaryAction) { $accentTextColor } elseif ($isNavButton) { $mutedColor } else { $textColor }
            $Control.FlatStyle = 'Flat'
            $Control.UseVisualStyleBackColor = $false
            $Control.TextAlign = if ($isMenuRow) { 'MiddleLeft' } else { 'MiddleCenter' }
            $Control.Cursor = [System.Windows.Forms.Cursors]::Hand
            $Control.Padding = if ($isMenuRow) { New-Object System.Windows.Forms.Padding(14, 0, 12, 0) } elseif ($isNavButton) { New-Object System.Windows.Forms.Padding(0) } else { New-Object System.Windows.Forms.Padding(10, 0, 10, 0) }
            try { $Control.AutoEllipsis = $true } catch {}
            $Control.FlatAppearance.BorderSize = if ([bool]$script:LowPerformanceMode -or $isPrimaryAction) { 0 } else { 1 }
            $Control.FlatAppearance.BorderColor = $borderColor
            $Control.FlatAppearance.MouseOverBackColor = if ($useGlass) { $glassHoverColor } else { $hoverColor }
            $Control.FlatAppearance.MouseDownBackColor = if ($useGlass) { $glassSelectionColor } else { Convert-HtmlColor $Palette.Selection }
            $Control.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 9)
            if ([bool]$script:LowPerformanceMode) {
                Clear-ControlRegion $Control
            }
            else {
                Set-ControlRoundedRegion -Control $Control -Radius $(if ($isNavButton) { 5 } else { 6 })
            }
        }
        elseif ($Control -is [System.Windows.Forms.TextBox]) {
            $Control.BackColor = $inputColor
            $Control.ForeColor = $textColor
            $Control.BorderStyle = 'FixedSingle'
            $Control.Margin = New-Object System.Windows.Forms.Padding(8, 6, 8, 6)
            Clear-ControlRegion $Control
        }
        elseif ($Control -is [System.Windows.Forms.ComboBox]) {
            $Control.BackColor = $inputColor
            $Control.ForeColor = $textColor
            $Control.FlatStyle = 'Flat'
            $Control.Margin = New-Object System.Windows.Forms.Padding(8, 6, 8, 6)
            Clear-ControlRegion $Control
        }
        elseif ($Control -is [System.Windows.Forms.NumericUpDown]) {
            $Control.BackColor = $inputColor
            $Control.ForeColor = $textColor
            $Control.BorderStyle = 'FixedSingle'
            $Control.Margin = New-Object System.Windows.Forms.Padding(8, 6, 8, 6)
            Clear-ControlRegion $Control
        }
        elseif ($Control -is [System.Windows.Forms.DateTimePicker]) {
            $Control.BackColor = $inputColor
            $Control.ForeColor = $textColor
            $Control.CalendarMonthBackground = $inputColor
            $Control.CalendarForeColor = $textColor
            $Control.CalendarTitleBackColor = Convert-HtmlColor $Palette.Header
            $Control.CalendarTitleForeColor = $textColor
            $Control.Margin = New-Object System.Windows.Forms.Padding(8, 6, 8, 6)
            Clear-ControlRegion $Control
        }
        elseif ($Control -is [System.Windows.Forms.TrackBar]) {
            Set-ControlBackColorSafe -Control $Control -Color $(if ($useGlass) { $transparentColor } else { $panelColor }) -FallbackColor $panelColor
            $Control.ForeColor = $textColor
            $Control.Margin = New-Object System.Windows.Forms.Padding(8, 4, 8, 4)
            Enable-DoubleBuffer $Control
        }
        elseif ($Control -is [System.Windows.Forms.DataGridView]) {
            Set-DataGridLayout $Control
            $Control.BackgroundColor = Convert-HtmlColor $Palette.Grid
            $Control.BackgroundImage = $null
            $Control.BackgroundImageLayout = 'None'
            $Control.GridColor = Convert-HtmlColor $Palette.Divider
            $Control.DefaultCellStyle.BackColor = Convert-HtmlColor $Palette.Grid
            $Control.DefaultCellStyle.ForeColor = $textColor
            $Control.DefaultCellStyle.SelectionBackColor = Convert-HtmlColor $Palette.Selection
            $Control.DefaultCellStyle.SelectionForeColor = $selectionTextColor
            $Control.AlternatingRowsDefaultCellStyle.BackColor = Convert-HtmlColor $Palette.AltGrid
            $Control.AlternatingRowsDefaultCellStyle.ForeColor = $textColor
            $Control.AlternatingRowsDefaultCellStyle.SelectionBackColor = Convert-HtmlColor $Palette.Selection
            $Control.AlternatingRowsDefaultCellStyle.SelectionForeColor = $selectionTextColor
            $Control.ColumnHeadersDefaultCellStyle.BackColor = Convert-HtmlColor $Palette.Header
            $Control.ColumnHeadersDefaultCellStyle.ForeColor = $textColor
            $Control.ColumnHeadersDefaultCellStyle.SelectionBackColor = Convert-HtmlColor $Palette.Header
            $Control.ColumnHeadersDefaultCellStyle.SelectionForeColor = $textColor
            $Control.ColumnHeadersDefaultCellStyle.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 9)
            $Control.EnableHeadersVisualStyles = $false
        }
        elseif ($Control -is [System.Windows.Forms.Label] -or $Control -is [System.Windows.Forms.CheckBox]) {
            $Control.BackColor = if ($solidScrollArea) { $panelColor } else { [System.Drawing.Color]::Transparent }
            $Control.ForeColor = $textColor
            if ([string]$Control.AccessibleName -eq 'SettingsLabel') {
                $Control.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 9.5)
                $Control.ForeColor = $textColor
            }
            elseif ([string]$Control.AccessibleName -eq 'MutedLabel') {
                $Control.ForeColor = $mutedColor
                $Control.Font = New-Object System.Drawing.Font('Segoe UI', 9)
            }
            elseif ([string]$Control.AccessibleName -eq 'AccentLabel') {
                $Control.ForeColor = Convert-HtmlColor $Palette.Accent
                $Control.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 9)
            }
            if ($Control -is [System.Windows.Forms.CheckBox]) {
                $Control.Cursor = [System.Windows.Forms.Cursors]::Hand
            }
        }
        else {
            Set-ControlBackColorSafe -Control $Control -Color $(if ($useGlass) { $transparentColor } else { $panelColor }) -FallbackColor $panelColor
            $Control.ForeColor = $textColor
        }
    }
    catch {
    }

    foreach ($child in $Control.Controls) {
        Set-ControlTheme -Control $child -Palette $Palette
    }
}

function Apply-AppTheme {
    param([string]$ThemeName)

    $palette = if ([bool]$script:LowPerformanceMode) { Get-LowPerformancePalette } else { Get-AppThemePalette $ThemeName }
    $script:CurrentThemePalette = $palette
    $backgroundImageEnabled = (Test-AppBackgroundImageEnabled)
    $useDarkFrame = ([bool]$script:LowPerformanceMode -or $ThemeName -in @('Карбон', 'Темная', 'Коричневая', 'Дота', 'Раст', 'Радуга', 'COURAGE'))

    $layoutControls = @($form, $navPanel, $contentPanel, $updatesMain, $settingsScrollPanel, $settingsMain, $extraToolsWrap, $extraToolsPanel) | Where-Object { $null -ne $_ }
    foreach ($layoutControl in $layoutControls) {
        try { $layoutControl.SuspendLayout() } catch {}
    }

    try {
        if ($form) {
            $form.BackColor = Convert-HtmlColor $palette.Form
            Set-ControlTheme -Control $form -Palette $palette
            Set-WindowFrameTheme -TargetForm $form -Palette $palette -UseDarkMode $useDarkFrame
            Apply-AppOpacity
            if ([bool]$script:LowPerformanceMode -or $ThemeName -notin @('Дота', 'Радуга', 'COURAGE')) {
                $form.BackgroundImage = $null
                $form.BackgroundImageLayout = 'None'
            }
        }
        if ($navPanel) {
            Set-ControlBackColorSafe -Control $navPanel -Color $(if ($backgroundImageEnabled) { Convert-HtmlColorWithAlpha $palette.Form 88 } else { Convert-HtmlColor $palette.Form }) -FallbackColor (Convert-HtmlColor $palette.Form)
        }
        if ($contentPanel) {
            Set-ControlBackColorSafe -Control $contentPanel -Color $(if ($backgroundImageEnabled) { [System.Drawing.Color]::Transparent } else { Convert-HtmlColor $palette.Form }) -FallbackColor (Convert-HtmlColor $palette.Form)
        }
        if ($titlePanel) {
            Set-ControlBackColorSafe -Control $titlePanel -Color $(if ($backgroundImageEnabled) { Convert-HtmlColorWithAlpha $palette.Form 118 } else { Convert-HtmlColor $palette.Form }) -FallbackColor (Convert-HtmlColor $palette.Form)
            Set-ControlBackColorSafe -Control $rootPanel -Color $(if ($backgroundImageEnabled) { [System.Drawing.Color]::Transparent } else { Convert-HtmlColor $palette.Divider }) -FallbackColor (Convert-HtmlColor $palette.Divider)
            $form.Padding = New-Object System.Windows.Forms.Padding(1)
        }
        if ($titleLabel) {
            Set-ControlBackColorSafe -Control $titleLabel -Color $(if ($backgroundImageEnabled) { [System.Drawing.Color]::Transparent } else { Convert-HtmlColor $palette.Form }) -FallbackColor (Convert-HtmlColor $palette.Form)
            $titleLabel.ForeColor = Convert-HtmlColor $palette.Text
            $titleLabel.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 9.5)
        }
        if ($titleIconLabel) {
            Set-ControlBackColorSafe -Control $titleIconLabel -Color $(if ($backgroundImageEnabled) { [System.Drawing.Color]::Transparent } else { Convert-HtmlColor $palette.Form }) -FallbackColor (Convert-HtmlColor $palette.Form)
            $titleIconLabel.ForeColor = Convert-HtmlColor $palette.Accent
        }
        Update-AppGooseIcon -Palette $palette
        foreach ($titleButton in @($titleMinButton, $titleMaxButton, $titleCloseButton)) {
            if ($titleButton) {
                Set-ControlBackColorSafe -Control $titleButton -Color $(if ($backgroundImageEnabled) { Convert-HtmlColorWithAlpha $palette.Form 80 } else { Convert-HtmlColor $palette.Form }) -FallbackColor (Convert-HtmlColor $palette.Form)
                $titleButton.ForeColor = Convert-HtmlColor $palette.Text
                $titleButton.Font = New-Object System.Drawing.Font('Segoe UI', 10)
                $titleButton.FlatAppearance.BorderSize = 0
                $titleButton.FlatAppearance.MouseOverBackColor = if ($backgroundImageEnabled) { Convert-HtmlColorWithAlpha $palette.RowHover 165 } else { Convert-HtmlColor $palette.RowHover }
                $titleButton.FlatAppearance.MouseDownBackColor = if ($backgroundImageEnabled) { Convert-HtmlColorWithAlpha $palette.Selection 205 } else { Convert-HtmlColor $palette.Selection }
                Clear-ControlRegion $titleButton
            }
        }
        Update-OneByOneButtonState
        if ($cancelOneByOneButton) {
            $cancelOneByOneButton.BackColor = Convert-HtmlColor $palette.Danger
            $cancelOneByOneButton.ForeColor = Convert-HtmlColor $palette.Text
        }
        if ($lowPerformanceModeCheck) {
            $lowPerformanceModeCheck.Checked = [bool]$script:LowPerformanceMode
        }
        if ($notificationWindowCheck) {
            $notificationWindowCheck.Checked = [bool]$script:NotificationWindowEnabled
        }
        Apply-AppWallpaper
        Update-NavigationButtons
    }
    finally {
        [array]::Reverse($layoutControls)
        foreach ($layoutControl in $layoutControls) {
            try { $layoutControl.ResumeLayout($false) } catch {}
        }
        if ($form) {
            try {
                $form.PerformLayout()
                $form.Invalidate($true)
            }
            catch {
            }
        }
    }
}

function Get-ReplyProperty {
    param($Item, [string]$Name, [string]$Default = "")

    if ($null -eq $Item) { return $Default }
    try {
        $value = $Item.$Name
        if ($null -eq $value) { return $Default }
        return [string]$value
    }
    catch {
        return $Default
    }
}

function Get-ReplyRecordContactKey {
    param($Item)

    $existingKey = Get-ReplyProperty $Item 'contactKey'
    if (-not [string]::IsNullOrWhiteSpace($existingKey)) { return $existingKey }

    $phone = Get-ReplyProperty $Item 'phone'
    $digits = ((Normalize-Phone $phone) -replace '\D', '')
    if ($digits.Length -ge 10) {
        return "phone:$digits"
    }

    $name = (Get-ReplyProperty $Item 'contactName').Trim().ToLowerInvariant() -replace '\s+', ' '
    if (-not [string]::IsNullOrWhiteSpace($name)) {
        return "name:$name"
    }

    return ""
}

function New-ReplyRecordObject {
    param($Item)

    $port = 0
    [void][int]::TryParse((Get-ReplyProperty $Item 'port'), [ref]$port)

    $id = Get-ReplyProperty $Item 'id'
    if ([string]::IsNullOrWhiteSpace($id)) {
        $id = [guid]::NewGuid().ToString()
    }

    $createdAt = Get-ReplyProperty $Item 'createdAt'
    if ([string]::IsNullOrWhiteSpace($createdAt)) {
        $createdAt = (Get-Date).ToString('s')
    }

    $readStatus = Get-ReplyProperty $Item 'readStatus'
    if ([string]::IsNullOrWhiteSpace($readStatus)) { $readStatus = 'не проверено' }

    $replyStatus = Get-ReplyProperty $Item 'replyStatus'
    if ([string]::IsNullOrWhiteSpace($replyStatus)) { $replyStatus = 'ожидаем' }

    return [pscustomobject]@{
        id = $id
        contactKey = Get-ReplyRecordContactKey $Item
        source = Get-ReplyProperty $Item 'source'
        createdAt = $createdAt
        profile = Get-ReplyProperty $Item 'profile'
        port = $port
        portFile = Get-ReplyProperty $Item 'portFile'
        contactName = Get-ReplyProperty $Item 'contactName'
        phone = Get-ReplyProperty $Item 'phone'
        groupName = Get-ReplyProperty $Item 'groupName'
        chatUrl = Get-ReplyProperty $Item 'chatUrl'
        chatTitle = Get-ReplyProperty $Item 'chatTitle'
        sentMessage = Get-ReplyProperty $Item 'sentMessage'
        messageSentAt = Get-ReplyProperty $Item 'messageSentAt'
        readStatus = $readStatus
        replyStatus = $replyStatus
        lastReplyText = Get-ReplyProperty $Item 'lastReplyText'
        lastCheckedAt = Get-ReplyProperty $Item 'lastCheckedAt'
        lastError = Get-ReplyProperty $Item 'lastError'
        notifiedReadAt = Get-ReplyProperty $Item 'notifiedReadAt'
        notifiedReplyText = Get-ReplyProperty $Item 'notifiedReplyText'
    }
}

function Load-ReplyRecords {
    param([switch]$Force)

    if ($script:ReplyRecordsLoaded -and -not $Force) { return }

    if (-not (Test-Path -LiteralPath $script:RepliesPath)) {
        $script:ReplyRecords.Clear()
        $script:ReplyRecordsLoaded = $true
        return
    }

    try {
        $raw = Get-Content -Raw -Encoding UTF8 -LiteralPath $script:RepliesPath
        if ([string]::IsNullOrWhiteSpace($raw)) {
            $script:ReplyRecords.Clear()
            $script:ReplyRecordsLoaded = $true
            return
        }

        $parsed = $raw | ConvertFrom-Json
        $items = if ($parsed -is [System.Array]) { $parsed } else { @($parsed) }

        $loaded = New-Object System.Collections.Generic.List[object]
        foreach ($item in $items) {
            if ($null -eq $item) { continue }
            $loaded.Add((New-ReplyRecordObject $item))
        }

        $script:ReplyRecords.Clear()
        foreach ($record in $loaded) {
            $script:ReplyRecords.Add($record)
        }
        $script:ReplyRecordsLoaded = $true
    }
    catch {
        $script:ReplyRecordsLoaded = $true
    }
}

function Save-ReplyRecords {
    try {
        $records = @($script:ReplyRecords | ForEach-Object { $_ })
        $json = if ($records.Count -gt 0) { $records | ConvertTo-Json -Depth 8 } else { '[]' }
        Set-Content -LiteralPath $script:RepliesPath -Encoding UTF8 -Value $json
        $script:ReplyRecordsLoaded = $true
    }
    catch {
    }
}

function Find-ReplyRecord {
    param(
        [string]$Profile,
        [int]$Port,
        [string]$Phone,
        [string]$GroupName,
        [string]$ChatUrl
    )

    foreach ($record in $script:ReplyRecords) {
        if (-not [string]::IsNullOrWhiteSpace($ChatUrl) -and
            [string]::Equals([string]$record.chatUrl, $ChatUrl, [StringComparison]::OrdinalIgnoreCase)) {
            return $record
        }

        if ([string]::Equals([string]$record.profile, $Profile, [StringComparison]::OrdinalIgnoreCase) -and
            [int]$record.port -eq $Port -and
            [string]::Equals([string]$record.phone, $Phone, [StringComparison]::OrdinalIgnoreCase) -and
            [string]::Equals([string]$record.groupName, $GroupName, [StringComparison]::OrdinalIgnoreCase)) {
            return $record
        }
    }

    return $null
}

function Find-ReplyRecordByContact {
    param($Contact)

    $key = Get-ContactReplyKey $Contact
    if ([string]::IsNullOrWhiteSpace($key)) { return $null }

    foreach ($record in $script:ReplyRecords) {
        $recordKey = [string]$record.contactKey
        if ([string]::IsNullOrWhiteSpace($recordKey)) {
            $recordKey = Get-ReplyRecordContactKey $record
            $record.contactKey = $recordKey
        }
        if ([string]::Equals($recordKey, $key, [StringComparison]::OrdinalIgnoreCase)) {
            return $record
        }
    }

    return $null
}

function Test-ContactAlreadyWritten {
    param($Contact)

    Load-ReplyRecords
    $record = Find-ReplyRecordByContact $Contact
    if ($null -eq $record) { return $false }

    return -not [string]::IsNullOrWhiteSpace([string]$record.messageSentAt)
}

function Get-SentReplyContactKeySet {
    Load-ReplyRecords

    $keys = @{}
    foreach ($record in $script:ReplyRecords) {
        if ($null -eq $record) { continue }
        if ([string]::IsNullOrWhiteSpace([string]$record.messageSentAt)) { continue }
        $key = [string]$record.contactKey
        if ([string]::IsNullOrWhiteSpace($key)) {
            $key = Get-ReplyRecordContactKey $record
            $record.contactKey = $key
        }
        if (-not [string]::IsNullOrWhiteSpace($key)) {
            $keys[$key.ToLowerInvariant()] = $true
        }
    }
    return $keys
}

function Test-ContactAlreadyWrittenCached {
    param(
        $Contact,
        [hashtable]$SentKeys
    )

    if ($null -eq $SentKeys) { return (Test-ContactAlreadyWritten $Contact) }
    $key = Get-ContactReplyKey $Contact
    if ([string]::IsNullOrWhiteSpace($key)) { return $false }
    return $SentKeys.ContainsKey($key.ToLowerInvariant())
}

function Ensure-ReplyRecordsForContacts {
    param([array]$Contacts)

    if ($null -eq $Contacts -or $Contacts.Count -eq 0) { return 0 }

    Load-ReplyRecords
    $added = 0
    $now = (Get-Date).ToString('s')

    foreach ($contact in $Contacts) {
        if ($null -eq $contact) { continue }
        $key = Get-ContactReplyKey $contact
        if ([string]::IsNullOrWhiteSpace($key)) { continue }

        $existing = Find-ReplyRecordByContact $contact
        if ($existing) {
            $existing.contactKey = $key
            $existing.contactName = [string]$contact.FullName
            $existing.phone = [string]$contact.Phone
            if ([string]::IsNullOrWhiteSpace([string]$existing.source)) {
                $existing.source = 'contact-list'
            }
            if ([string]::IsNullOrWhiteSpace([string]$existing.replyStatus)) {
                $existing.replyStatus = 'в списке'
            }
            continue
        }

        $record = New-ReplyRecordObject ([pscustomobject]@{
            id = [guid]::NewGuid().ToString()
            contactKey = $key
            source = 'contact-list'
            createdAt = $now
            contactName = [string]$contact.FullName
            phone = [string]$contact.Phone
            readStatus = 'не проверено'
            replyStatus = 'в списке'
        })
        $script:ReplyRecords.Add($record)
        $added++
    }

    if ($added -gt 0) {
        Save-ReplyRecords
        Refresh-OpenRepliesWindow
    }

    return $added
}

function Register-OneByOneReplyWatch {
    param(
        $Session,
        $Contact,
        [string]$GroupName,
        [string]$MessageText,
        $GroupResult
    )

    if ([string]::IsNullOrWhiteSpace($MessageText)) { return }

    try {
        $profile = [string]$Session.Profile
        $port = [int]$Session.Port
        $phone = [string]$Contact.Phone
        $chatUrl = if ($null -ne $GroupResult -and $GroupResult.url) { [string]$GroupResult.url } else { "" }
        $chatTitle = if ($null -ne $GroupResult -and $GroupResult.title) { [string]$GroupResult.title } else { "" }
        $contactKey = Get-ContactReplyKey $Contact
        $now = (Get-Date).ToString('s')
        $existing = Find-ReplyRecord -Profile $profile -Port $port -Phone $phone -GroupName $GroupName -ChatUrl $chatUrl
        if (-not $existing) {
            $existing = Find-ReplyRecordByContact $Contact
        }

        if ($existing) {
            $existing.createdAt = $now
            $existing.contactKey = $contactKey
            $existing.source = 'sent'
            $existing.profile = $profile
            $existing.port = $port
            $existing.portFile = [string]$Session.PortFile
            $existing.contactName = [string]$Contact.FullName
            $existing.phone = $phone
            $existing.groupName = $GroupName
            $existing.chatUrl = $chatUrl
            $existing.chatTitle = $chatTitle
            $existing.sentMessage = $MessageText
            $existing.messageSentAt = $now
            $existing.readStatus = 'не проверено'
            $existing.replyStatus = 'ожидаем'
            $existing.lastReplyText = ''
            $existing.lastCheckedAt = ''
            $existing.lastError = ''
            $existing.notifiedReadAt = ''
            $existing.notifiedReplyText = ''
        }
        else {
            $record = New-ReplyRecordObject ([pscustomobject]@{
                id = [guid]::NewGuid().ToString()
                contactKey = $contactKey
                source = 'sent'
                createdAt = $now
                profile = $profile
                port = $port
                portFile = [string]$Session.PortFile
                contactName = [string]$Contact.FullName
                phone = $phone
                groupName = $GroupName
                chatUrl = $chatUrl
                chatTitle = $chatTitle
                sentMessage = $MessageText
                messageSentAt = $now
                readStatus = 'не проверено'
                replyStatus = 'ожидаем'
            })
            $script:ReplyRecords.Add($record)
        }

        Save-ReplyRecords
        Refresh-OpenRepliesWindow
    }
    catch {
    }
}

function Get-ReplyRecordById {
    param([string]$Id)

    foreach ($record in $script:ReplyRecords) {
        if ([string]::Equals([string]$record.id, $Id, [StringComparison]::OrdinalIgnoreCase)) {
            return $record
        }
    }

    return $null
}

function Get-ReplyRecordSession {
    param($Record)

    if ($null -eq $Record) { return $null }

    $port = 0
    if (-not [int]::TryParse([string]$Record.port, [ref]$port) -or $port -le 0) {
        return $null
    }

    $match = @($script:MaxitochkaSessions | Where-Object {
        [int]$_.Port -eq $port -and
        [string]::Equals([string]$_.Profile, [string]$Record.profile, [StringComparison]::OrdinalIgnoreCase)
    } | Select-Object -First 1)
    if ($match.Count -gt 0) { return $match[0] }

    return [pscustomobject]@{
        Profile = [string]$Record.profile
        Port = $port
        Status = 'MAX открыт'
        Title = [string]$Record.chatTitle
        Url = [string]$Record.chatUrl
        PortFile = [string]$Record.portFile
    }
}

function Test-MaxitochkaSpecificChatUrl {
    param([string]$Url)

    if ([string]::IsNullOrWhiteSpace($Url)) { return $false }
    if ($Url -match '^https?://web[.]max[.]ru/?(?:[#?].*)?$') { return $false }
    if ($Url -match '/(?:chat|chats|dialog|conversation|peer|im|c)/[^/?#]+') { return $true }
    if ($Url -match '[?&#](?:chat|dialog|conversation|peer|contact|user|id)=') { return $true }
    return $false
}

function New-MaxitochkaInspectChatScript {
    param(
        [string]$ChatUrl,
        [string]$SentMessage,
        [string]$ContactName = "",
        [string]$Phone = "",
        [string]$GroupName = ""
    )

    $payload = [ordered]@{
        chatUrl = $ChatUrl
        sentMessage = $SentMessage
        contactName = $ContactName
        phone = $Phone
        groupName = $GroupName
    }
    $json = $payload | ConvertTo-Json -Depth 4 -Compress
    $template = @'
(async () => {
  const job = __INSPECT_JSON__;
  const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
  const norm = s => String(s || '').trim().replace(/\s+/g, ' ');
  const visible = el => {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    const st = getComputedStyle(el);
    return r.width > 2 && r.height > 2 && st.visibility !== 'hidden' && st.display !== 'none';
  };
  const labelOf = el => norm(el.getAttribute('aria-label') || el.getAttribute('title') || el.getAttribute('placeholder') || el.innerText || el.textContent || '');
  const buttons = () => [...document.querySelectorAll('button,[role="button"],[role="listitem"],[role="option"],a')].filter(visible);
  const clickElement = el => {
    el.scrollIntoView({block:'center', inline:'center'});
    el.dispatchEvent(new MouseEvent('mousedown', {bubbles:true, cancelable:true, view:window}));
    el.dispatchEvent(new MouseEvent('mouseup', {bubbles:true, cancelable:true, view:window}));
    el.click();
  };
  const clickLabel = label => {
    const wanted = norm(label).toLowerCase();
    const item = buttons().find(el => labelOf(el).toLowerCase() === wanted);
    if (!item) return false;
    clickElement(item);
    return true;
  };
  const typeInput = async (el, value) => {
    el.focus();
    const hasValue = 'value' in el;
    const proto = hasValue && el.tagName.toLowerCase() === 'textarea' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = hasValue ? Object.getOwnPropertyDescriptor(proto, 'value').set : null;
    if (hasValue) setter.call(el, '');
    else el.textContent = '';
    el.dispatchEvent(new InputEvent('input', {bubbles:true, inputType:'deleteContentBackward', data:null}));
    await delay(120);
    if (hasValue) setter.call(el, value);
    else el.textContent = value;
    el.dispatchEvent(new InputEvent('input', {bubbles:true, inputType:'insertText', data:value}));
    el.dispatchEvent(new Event('change', {bubbles:true}));
  };
  const digits = s => String(s || '').replace(/\D/g, '');
  const splitName = norm(job.contactName).split(' ').filter(Boolean);
  const terms = [job.groupName, job.contactName, splitName[0], digits(job.phone).slice(-10)]
    .map(x => norm(x))
    .filter(x => x && x.length >= 3)
    .filter((x, i, arr) => arr.indexOf(x) === i);
  const matchTerm = text => {
    const hay = norm(text).toLowerCase();
    const hayDigits = digits(text);
    return terms.some(term => {
      const low = term.toLowerCase();
      const d = digits(term);
      if (d.length >= 6 && hayDigits.includes(d)) return true;
      return low.length >= 3 && hay.includes(low);
    });
  };
  const findChatCandidate = () => {
    const selectors = [
      'button',
      '[role="button"]',
      '[role="listitem"]',
      '[role="option"]',
      'a',
      '[class*="chat" i]',
      '[class*="cell" i]',
      '[class*="conversation" i]'
    ].join(',');
    return [...document.querySelectorAll(selectors)]
      .filter(visible)
      .map((el, index) => ({ el, index, text: labelOf(el), rect: el.getBoundingClientRect() }))
      .filter(item => item.text && matchTerm(item.text))
      .filter(item => !/создать|добавить|настройки|контакты|поиск/i.test(item.text))
      .sort((a, b) => (a.rect.top - b.rect.top) || (a.index - b.index))[0]?.el || null;
  };
  let foundChat = false;
  if (job.chatUrl && location.href !== job.chatUrl) {
    location.href = job.chatUrl;
    await delay(2600);
  }
  if (!job.chatUrl) {
    clickLabel('Чаты') || clickLabel('Chats');
    await delay(800);
    let candidate = findChatCandidate();
    if (!candidate) {
      const search = [...document.querySelectorAll('input,textarea,[contenteditable="true"],div[role="textbox"]')]
        .filter(visible)
        .find(el => /поиск|найти|search/i.test(labelOf(el)));
      const searchTerm = terms.find(x => !/^\d+$/.test(x)) || terms[0] || '';
      if (search && searchTerm) {
        await typeInput(search, searchTerm);
        await delay(1400);
        candidate = findChatCandidate();
      }
    }
    if (candidate) {
      clickElement(candidate);
      foundChat = true;
      await delay(2100);
    }
  } else {
    foundChat = true;
  }
  await delay(900);

  const labels = [...document.querySelectorAll('[aria-label],[title]')].filter(visible).map(labelOf).filter(Boolean);
  const body = String(document.body ? document.body.innerText || '' : '');
  const fullText = `${body}\n${labels.join('\n')}`;
  const read = /(прочитан|прочитано|просмотрен|seen|read)/i.test(fullText) && !/(не прочитан|не прочитано|unread)/i.test(fullText);

  const sent = norm(job.sentMessage);
  const sentNeedle = sent.slice(0, Math.min(96, sent.length));
  const ownStart = sent.slice(0, Math.min(28, sent.length));
  const junk = /^(MAX|Контакты|Чаты|Настройки|Создать|Добавить|Поиск|Найти|Сообщение|Написать|Отправить|Вложения|Сегодня|Вчера|Вы|You)$/i;
  const statusLine = /^(\d{1,2}:\d{2}|прочитан|прочитано|отправлено|доставлено|seen|read)$/i;
  const goodLine = line => line && line.length > 1 && !junk.test(line) && !statusLine.test(line) && (!ownStart || !line.includes(ownStart));
  const lines = body.split(/\n+/).map(norm).filter(Boolean);
  const messageSelectors = [
    '[data-testid*="message" i]',
    '[class*="message" i]',
    '[class*="bubble" i]',
    '[role="listitem"]',
    '[role="article"]'
  ].join(',');
  const nodes = [...document.querySelectorAll(messageSelectors)]
    .filter(visible)
    .map((el, index) => {
      const rect = el.getBoundingClientRect();
      const text = norm(el.innerText || el.textContent || '');
      const meta = norm(`${el.className || ''} ${labelOf(el)}`);
      return { index, top: rect.top, text, meta };
    })
    .filter(item => item.text && item.text.length > 1)
    .sort((a, b) => (a.top - b.top) || (a.index - b.index));

  let replyText = '';
  if (sentNeedle.length >= 8 && nodes.length) {
    const sentNodeIndex = nodes.findIndex(item => item.text.includes(sentNeedle) || (sentNeedle.includes(item.text) && item.text.length >= 28));
    if (sentNodeIndex >= 0) {
      const replies = nodes.slice(sentNodeIndex + 1)
        .map(item => item.text.split(/\n+/).map(norm).filter(goodLine).join(' '))
        .filter(Boolean)
        .filter((text, index, arr) => arr.indexOf(text) === index)
        .slice(0, 4);
      replyText = replies.join(' | ');
    }
  }
  if (!replyText && sentNeedle.length >= 8) {
    const sentIndex = lines.findIndex(line => line.includes(sentNeedle) || (sentNeedle.includes(line) && line.length >= 28));
    if (sentIndex >= 0) {
      const replies = lines.slice(sentIndex + 1)
        .filter(goodLine)
        .filter((text, index, arr) => arr.indexOf(text) === index)
        .slice(0, 4);
      replyText = replies.join(' | ');
    }
  }
  if (!replyText && foundChat) {
    const eventLines = lines
      .filter(line => /(покинул|покинула|вышел|вышла|удалил|удалила|left|removed)/i.test(line))
      .filter(goodLine)
      .filter((text, index, arr) => arr.indexOf(text) === index)
      .slice(-4);
    if (eventLines.length) {
      replyText = eventLines.join(' | ');
    }
  }
  if (!replyText && (!sentNeedle || sentNeedle.length < 8) && foundChat) {
    replyText = nodes
      .slice(-3)
      .map(item => item.text.split(/\n+/).map(norm).filter(goodLine).join(' '))
      .filter(Boolean)
      .filter((text, index, arr) => arr.indexOf(text) === index)
      .join(' | ');
  }
  if (!replyText && (!sentNeedle || sentNeedle.length < 8) && foundChat) {
    replyText = lines
      .filter(goodLine)
      .filter((text, index, arr) => arr.indexOf(text) === index)
      .slice(-3)
      .join(' | ');
  }

  return {
    ok: true,
    foundChat,
    url: location.href,
    title: document.title,
    read,
    replyText,
    bodyTail: lines.slice(-10).join(' | ')
  };
})()
'@
    return $template.Replace('__INSPECT_JSON__', $json)
}

function New-MaxitochkaScanRepliesListScript {
    param([array]$Records)

    $template = @'
(() => {
  const norm = s => String(s || '').trim().replace(/\s+/g, ' ');
  const visible = el => {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    const st = getComputedStyle(el);
    return r.width > 4 && r.height > 4 && st.visibility !== 'hidden' && st.display !== 'none' && Number(st.opacity || 1) > 0;
  };
  const pushTextParts = (target, value) => {
    String(value || '')
      .split(/\n+|\t+| {2,}/)
      .map(norm)
      .filter(Boolean)
      .forEach(part => target.push(part));
  };
  const textLinesOf = el => {
    const parts = [];
    pushTextParts(parts, el.getAttribute('aria-label'));
    pushTextParts(parts, el.getAttribute('title'));
    pushTextParts(parts, el.innerText || el.textContent || '');
    const children = [...el.querySelectorAll('*')].slice(0, 160);
    for (const child of children) {
      if (!visible(child)) continue;
      const hasDirectText = [...child.childNodes].some(node => node.nodeType === Node.TEXT_NODE && norm(node.textContent || ''));
      if (child.children.length > 0 && !hasDirectText && !/(message|bubble|chat|dialog|cell|item|title|name|text|badge|counter|unread|last)/i.test(String(child.className || ''))) continue;
      pushTextParts(parts, child.getAttribute('aria-label'));
      pushTextParts(parts, child.getAttribute('title'));
      pushTextParts(parts, child.innerText || child.textContent || '');
    }
    const seen = new Set();
    return parts
      .map(norm)
      .filter(Boolean)
      .filter(part => {
        const key = part.toLowerCase();
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      })
      .slice(0, 48);
  };
  const junk = /^(MAX|Контакты|Чаты|Настройки|Создать|Добавить|Поиск|Найти|Сообщение|Написать|Отправить|Вложения|Сегодня|Вчера|Вы|You|Online|Offline|Emoji|Attach|Close|Back)$/i;
  const statusLine = /^(\d{1,2}:\d{2}|прочитан|прочитано|отправлено|доставлено|seen|read|unread|непрочитано|\d{1,3})$/i;
  const badText = text => {
    const clean = norm(text);
    if (!clean || clean.length < 2 || clean.length > 700) return true;
    if (junk.test(clean) || statusLine.test(clean)) return true;
    if (/^(создать группу|добавить контакт|настройки|поиск|открыть|очистить)$/i.test(clean)) return true;
    return false;
  };
  const quickTextOf = el => norm(el.getAttribute('aria-label') || el.getAttribute('title') || el.textContent || '');
  const hasDirectText = el => [...el.childNodes].some(node => node.nodeType === Node.TEXT_NODE && norm(node.textContent || ''));
  const hash = text => {
    let h = 2166136261;
    for (let i = 0; i < text.length; i++) {
      h ^= text.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return (h >>> 0).toString(36);
  };
  const selectors = [
    '[data-testid*="message" i]',
    '[class*="message" i]',
    '[class*="bubble" i]',
    '[data-testid*="chat" i]',
    '[data-testid*="conversation" i]',
    '[class*="chat" i]',
    '[class*="conversation" i]',
    '[class*="dialog" i]',
    '[class*="cell" i]',
    '[class*="item" i]',
    '[role="listitem"]',
    '[role="option"]',
    'article',
    'li',
    'button',
    'a'
  ].join(',');
  const semanticElements = [...document.querySelectorAll(selectors)].filter(visible);
  const genericElements = [...document.querySelectorAll('div,span,p,li,button,a,[role]')]
    .filter(visible)
    .filter(el => el.children.length === 0 || hasDirectText(el))
    .filter(el => !badText(quickTextOf(el)));
  const candidates = [...new Set([...semanticElements, ...genericElements])];
  const rows = candidates
    .map((el, index) => {
      const rect = el.getBoundingClientRect();
      const lines = textLinesOf(el);
      const text = lines.join('\n');
      return { index, text, lines, top: rect.top, left: rect.left, width: rect.width, height: rect.height };
    })
    .filter(item => item.text && item.width >= 16 && item.height >= 10)
    .filter(item => !badText(item.text))
    .sort((a, b) => (a.top - b.top) || (a.left - b.left));

  const seen = new Set();
  const matches = [];
  for (const row of rows) {
    const useful = row.lines.filter(line => !badText(line));
    if (!useful.length) continue;

    let title = useful[0] || document.title;
    let sender = useful.find((line, index) => index > 0 && /:\s*$/.test(line)) || '';
    sender = norm(sender.replace(/\s+\d+\s*:\s*$/, '').replace(/:\s*$/, ''));
    let bodyLines = useful.filter(line => line !== title && (!sender || line.replace(/:\s*$/, '') !== sender));
    if (!bodyLines.length) bodyLines = useful.slice(-3);
    const replyText = bodyLines.join(' | ');
    if (badText(replyText)) continue;

    const rawKey = `${location.href}|${document.title}|${title}|${sender}|${replyText}`.toLowerCase();
    const key = hash(rawKey);
    if (seen.has(key)) continue;
    seen.add(key);

    matches.push({
      id: '',
      contactKey: `visible:${key}`,
      contactName: sender || title || 'MAX',
      groupName: title,
      chatTitle: title,
      replyText,
      rowText: row.text,
      title: document.title,
      url: location.href
    });
    if (matches.length >= 80) break;
  }

  return {ok:true, url: location.href, title: document.title, rowCount: rows.length, matches};
})()
'@
    return $template
}

function Show-RepliesNotification {
    param([array]$Lines)

    if ($null -eq $Lines -or $Lines.Count -eq 0) { return }

    $text = (($Lines | Select-Object -First 8) -join "`n")
    if ($Lines.Count -gt 8) {
        $text += "`n..."
    }
    [System.Windows.Forms.MessageBox]::Show($text, 'Ответы MAX', 'OK', 'Information') | Out-Null
}

function Update-ReplyRecordFromMaxitochka {
    param(
        $Record,
        $Changes = $null
    )

    if ($null -eq $Record) { return $false }

    $Record.lastCheckedAt = (Get-Date).ToString('s')
    $Record.lastError = ''

    $sessionsToTry = New-Object System.Collections.Generic.List[object]
    if (-not [string]::IsNullOrWhiteSpace([string]$Record.chatUrl)) {
        $session = Get-ReplyRecordSession $Record
        if ($session) { $sessionsToTry.Add($session) }
    }
    if ($sessionsToTry.Count -eq 0) {
        foreach ($session in @(Get-SelectedMaxitochkaSessions)) {
            if ($session -and $session.Status -eq 'MAX открыт') { $sessionsToTry.Add($session) }
        }
    }
    if ($sessionsToTry.Count -eq 0) {
        foreach ($session in @($script:MaxitochkaSessions | Where-Object { $_.Status -eq 'MAX открыт' })) {
            $sessionsToTry.Add($session)
        }
    }
    if ($sessionsToTry.Count -eq 0) {
        $Record.replyStatus = 'MAX не найден'
        $Record.lastError = 'Нажми "Найти MAX", чтобы программа могла проверить чаты.'
        return $false
    }

    $lastError = ''
    foreach ($session in @($sessionsToTry)) {
      try {
        $inspectScript = New-MaxitochkaInspectChatScript -ChatUrl ([string]$Record.chatUrl) -SentMessage ([string]$Record.sentMessage) -ContactName ([string]$Record.contactName) -Phone ([string]$Record.phone) -GroupName ([string]$Record.groupName)
        $result = Invoke-MaxitochkaScript -Session $session -Expression $inspectScript -TimeoutMs 22000
        if ($result.ok) {
            if ([bool]$result.foundChat -or -not [string]::IsNullOrWhiteSpace([string]$Record.chatUrl)) {
                $Record.profile = [string]$session.Profile
                $Record.port = [int]$session.Port
                $Record.portFile = [string]$session.PortFile
                $Record.chatUrl = if ($result.url) { [string]$result.url } else { [string]$Record.chatUrl }
                $Record.chatTitle = if ($result.title) { [string]$result.title } else { [string]$Record.chatTitle }
            }
            elseif ([string]::IsNullOrWhiteSpace([string]$Record.chatUrl)) {
                $Record.replyStatus = 'чат не найден'
                $Record.lastError = 'Не нашел чат по имени/телефону в открытых MAX.'
                continue
            }

            if ([bool]$result.read) {
                $Record.readStatus = 'прочитано'
                if ($Changes -and [string]::IsNullOrWhiteSpace([string]$Record.notifiedReadAt)) {
                    $Changes.Add("$($Record.contactName): сообщение прочитано")
                    $Record.notifiedReadAt = (Get-Date).ToString('s')
                }
            }
            elseif ([string]::IsNullOrWhiteSpace([string]$Record.readStatus) -or $Record.readStatus -eq 'не проверено') {
                $Record.readStatus = 'не видно'
            }

            $replyText = if ($result.replyText) { [string]$result.replyText } else { "" }
            if (-not [string]::IsNullOrWhiteSpace($replyText)) {
                $Record.replyStatus = 'есть ответ'
                $Record.lastReplyText = $replyText
                if ($Changes -and -not [string]::Equals([string]$Record.notifiedReplyText, $replyText, [StringComparison]::Ordinal)) {
                    $Changes.Add("$($Record.contactName): $replyText")
                    $Record.notifiedReplyText = $replyText
                }
            }
            elseif ($Record.replyStatus -ne 'есть ответ') {
                $Record.replyStatus = 'ждем ответ'
            }
            return $true
        }

        $Record.replyStatus = 'ошибка проверки'
        $Record.lastError = if ($result.error) { [string]$result.error } else { 'MAX не вернул результат проверки' }
        $lastError = $Record.lastError
      }
      catch {
        $lastError = $_.Exception.Message
        $Record.replyStatus = 'ошибка проверки'
        $Record.lastError = $lastError
      }
    }

    if (-not [string]::IsNullOrWhiteSpace($lastError)) {
        $Record.lastError = $lastError
    }
    return $false
}

function Update-ReplyRecordsFromMaxitochka {
    param(
        $StatusLabel = $null,
        [bool]$Notify = $true
    )

    Load-ReplyRecords
    if ($script:ReplyRecords.Count -eq 0) {
        if ($StatusLabel) { $StatusLabel.Text = 'Ответы: пока нет отправленных чатов' }
        return
    }

    $changes = New-Object System.Collections.Generic.List[string]
    $total = $script:ReplyRecords.Count
    $index = 0

    foreach ($record in @($script:ReplyRecords)) {
        $index++
        if ($StatusLabel) {
            $StatusLabel.Text = "Проверяю: $index/$total | $($record.contactName)"
            [System.Windows.Forms.Application]::DoEvents()
        }

        [void](Update-ReplyRecordFromMaxitochka -Record $record -Changes $changes)
    }

    Save-ReplyRecords

    if ($StatusLabel) {
        $StatusLabel.Text = "Ответы: проверено $total | найдено: $(@($script:ReplyRecords | Where-Object { $_.replyStatus -eq 'есть ответ' }).Count)"
    }
    if ($Notify -and $changes.Count -gt 0) {
        Show-RepliesNotification -Lines $changes.ToArray()
    }
}

function Update-ReplyRecordsFromVisibleChats {
    param(
        $StatusLabel = $null,
        [bool]$Notify = $true,
        [int]$IntervalSeconds = 3
    )

    if ($script:RepliesAutoCheckBusy -or $script:MaxitochkaDevToolsBusy) { return $false }
    if (((Get-Date) - $script:RepliesLastVisibleScanAt).TotalSeconds -lt $IntervalSeconds) { return $false }
    $script:RepliesLastVisibleScanAt = Get-Date

    Load-ReplyRecords
    Ensure-MaxitochkaSessionsForReplies
    $watchCount = $script:ReplyRecords.Count

    $sessions = New-Object System.Collections.Generic.List[object]
    $seenSessions = @{}
    foreach ($session in @($script:MaxitochkaSessions | Where-Object { $_.Status -eq 'MAX открыт' })) {
        $key = Get-MaxitochkaSessionKey $session
        if ($seenSessions.ContainsKey($key)) { continue }
        $seenSessions[$key] = $true
        $sessions.Add($session)
    }
    if ($sessions.Count -eq 0) {
        foreach ($session in @(Get-SelectedMaxitochkaSessions)) {
            if ($session -and $session.Status -eq 'MAX открыт') { $sessions.Add($session) }
        }
    }
    if ($sessions.Count -eq 0) {
        if ($StatusLabel) { $StatusLabel.Text = 'Ответы: нажми "Найти MAX"' }
        return $false
    }

    $records = @($script:ReplyRecords | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_.contactKey) })

    $script:RepliesAutoCheckBusy = $true
    $changed = $false
    $changes = New-Object System.Collections.Generic.List[string]
    $scannedSessions = 0
    $totalRows = 0
    $totalMatches = 0
    try {
        for ($sessionIndex = 0; $sessionIndex -lt $sessions.Count; $sessionIndex++) {
            $session = $sessions[$sessionIndex]
            if ($StatusLabel) {
                $StatusLabel.Text = "Быстро проверяю: $($session.Profile)"
                [System.Windows.Forms.Application]::DoEvents()
            }

            try {
                $scanScript = New-MaxitochkaScanRepliesListScript -Records $records
                $result = Invoke-MaxitochkaScript -Session $session -Expression $scanScript -TimeoutMs 9000
                if (-not $result.ok) { continue }
                $scannedSessions++
                try { $totalRows += [int]$result.rowCount } catch {}
                if (-not $result.matches) { continue }
                $totalMatches += @($result.matches).Count

                foreach ($match in @($result.matches)) {
                    $matchUrl = [string]$match.url
                    $specificChatUrl = if (Test-MaxitochkaSpecificChatUrl $matchUrl) { $matchUrl } else { "" }
                    $record = Get-ReplyRecordById ([string]$match.id)
                    if (-not $record -and -not [string]::IsNullOrWhiteSpace([string]$match.contactKey)) {
                        $record = @($script:ReplyRecords | Where-Object {
                            [string]::Equals([string]$_.contactKey, [string]$match.contactKey, [StringComparison]::OrdinalIgnoreCase)
                        } | Select-Object -First 1)
                        if ($record.Count -gt 0) { $record = $record[0] }
                    }
                    if (-not $record) {
                        $record = New-ReplyRecordObject ([pscustomobject]@{
                            id = [guid]::NewGuid().ToString()
                            contactKey = [string]$match.contactKey
                            source = 'max-scan'
                            createdAt = (Get-Date).ToString('s')
                            contactName = [string]$match.contactName
                            groupName = [string]$match.groupName
                            chatUrl = $specificChatUrl
                            chatTitle = if ($match.chatTitle) { [string]$match.chatTitle } else { [string]$match.title }
                            readStatus = 'не проверено'
                            replyStatus = 'есть ответ'
                        })
                        $script:ReplyRecords.Add($record)
                    }

                    $replyText = [string]$match.replyText
                    if ([string]::IsNullOrWhiteSpace($replyText)) { continue }

                    if (-not [string]::IsNullOrWhiteSpace([string]$match.contactName)) {
                        $record.contactName = [string]$match.contactName
                    }
                    $record.profile = [string]$session.Profile
                    $record.port = [int]$session.Port
                    $record.portFile = [string]$session.PortFile
                    if (-not [string]::IsNullOrWhiteSpace([string]$match.groupName)) {
                        $record.groupName = [string]$match.groupName
                    }
                    if (-not [string]::IsNullOrWhiteSpace($specificChatUrl)) {
                        $record.chatUrl = $specificChatUrl
                    }
                    $record.chatTitle = if ($match.chatTitle) { [string]$match.chatTitle } elseif ($match.title) { [string]$match.title } else { [string]$record.chatTitle }
                    $record.lastCheckedAt = (Get-Date).ToString('s')
                    $record.lastError = ''
                    $record.replyStatus = 'есть ответ'
                    $record.lastReplyText = $replyText

                    if (-not [string]::Equals([string]$record.notifiedReplyText, $replyText, [StringComparison]::Ordinal)) {
                        $changes.Add("$($record.contactName): $replyText")
                        $record.notifiedReplyText = $replyText
                    }
                    $changed = $true
                }
            }
            catch {
            }
        }
    }
    finally {
        $script:RepliesAutoCheckBusy = $false
        $script:RepliesLastVisibleScanStats = [pscustomobject]@{
            scannedAt = (Get-Date).ToString('s')
            sessions = $scannedSessions
            rows = $totalRows
            matches = $totalMatches
        }
    }

    if ($changed) {
        Save-ReplyRecords
        Refresh-OpenRepliesWindow
    }
    elseif ($StatusLabel) {
        $answerCount = @($script:ReplyRecords | Where-Object { $_.replyStatus -eq 'есть ответ' -and -not [string]::IsNullOrWhiteSpace([string]$_.lastReplyText) }).Count
        $StatusLabel.Text = "Ответы: наблюдение $watchCount | найдено: $answerCount"
    }
    if ($Notify -and $changes.Count -gt 0) {
        Show-RepliesNotification -Lines $changes.ToArray()
    }
    return $changed
}

function Ensure-MaxitochkaSessionsForReplies {
    $openCount = @($script:MaxitochkaSessions | Where-Object { $_.Status -eq 'MAX открыт' }).Count
    if ($openCount -gt 0) { return }
    if (-not $maxitochkaPathBox) { return }

    try {
        $root = $maxitochkaPathBox.Text.Trim()
        if ([string]::IsNullOrWhiteSpace($root) -or -not (Test-Path -LiteralPath $root)) { return }

        $script:MaxitochkaSessions = Get-MaxitochkaOpenSessions $root
        if ($maxitochkaGrid) {
            Refresh-MaxitochkaGrid
        }
    }
    catch {
    }
}

function Update-NextReplyRecordFromMaxitochka {
    param(
        $StatusLabel = $null,
        [bool]$Notify = $true,
        [int]$IntervalSeconds = 12
    )

    if ($script:RepliesAutoCheckBusy -or $script:MaxitochkaDevToolsBusy -or $script:OneByOneRunning) { return }
    if (((Get-Date) - $script:RepliesLastAutoCheckAt).TotalSeconds -lt $IntervalSeconds) { return }

    $script:RepliesAutoCheckBusy = $true
    $script:RepliesLastAutoCheckAt = Get-Date
    try {
        Load-ReplyRecords
        $total = $script:ReplyRecords.Count
        if ($total -eq 0) {
            if ($StatusLabel) { $StatusLabel.Text = 'Ответы: пока нет отправленных чатов' }
            return
        }

        if ($script:RepliesAutoCheckCursor -ge $total -or $script:RepliesAutoCheckCursor -lt 0) {
            $script:RepliesAutoCheckCursor = 0
        }

        $record = $script:ReplyRecords[$script:RepliesAutoCheckCursor]
        $script:RepliesAutoCheckCursor = ($script:RepliesAutoCheckCursor + 1) % $total
        if ($StatusLabel) {
            $StatusLabel.Text = "Авто-проверка: $($record.contactName)"
            [System.Windows.Forms.Application]::DoEvents()
        }

        $changes = New-Object System.Collections.Generic.List[string]
        [void](Update-ReplyRecordFromMaxitochka -Record $record -Changes $changes)
        Save-ReplyRecords
        Refresh-OpenRepliesWindow

        if ($StatusLabel) {
            $answerCount = @($script:ReplyRecords | Where-Object { $_.replyStatus -eq 'есть ответ' }).Count
            $StatusLabel.Text = "Ответы: записей $total | найдено: $answerCount"
        }
        if ($Notify -and $changes.Count -gt 0) {
            Show-RepliesNotification -Lines $changes.ToArray()
        }
    }
    finally {
        $script:RepliesAutoCheckBusy = $false
    }
}

function Open-ReplyRecordChat {
    param($Record)

    if ($null -eq $Record) { return }
    Ensure-MaxitochkaSessionsForReplies

    $sessionsToTry = New-Object System.Collections.Generic.List[object]
    $session = Get-ReplyRecordSession $Record
    if ($session) { $sessionsToTry.Add($session) }
    if ($sessionsToTry.Count -eq 0) {
        foreach ($item in @(Get-SelectedMaxitochkaSessions)) {
            if ($item -and $item.Status -eq 'MAX открыт') { $sessionsToTry.Add($item) }
        }
    }
    if ($sessionsToTry.Count -eq 0) {
        foreach ($item in @($script:MaxitochkaSessions | Where-Object { $_.Status -eq 'MAX открыт' })) {
            $sessionsToTry.Add($item)
        }
    }
    if ($sessionsToTry.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show('Не найден открытый MAX-профиль для этой записи. Открой MAX и нажми "Найти MAX".', 'Ответы MAX', 'OK', 'Warning') | Out-Null
        return
    }

    $lastError = ''
    foreach ($sessionToOpen in @($sessionsToTry)) {
        try {
            $hasSpecificChatUrl = Test-MaxitochkaSpecificChatUrl ([string]$Record.chatUrl)
            if ($hasSpecificChatUrl) {
                $urlJson = [string]$Record.chatUrl | ConvertTo-Json -Compress
                $scriptText = "(async () => { location.href = $urlJson; return {ok:true, foundChat:true, url: location.href}; })()"
                $result = Invoke-MaxitochkaScript -Session $sessionToOpen -Expression $scriptText -TimeoutMs 9000
            }
            else {
                $scriptText = New-MaxitochkaInspectChatScript -ChatUrl "" -SentMessage ([string]$Record.sentMessage) -ContactName ([string]$Record.contactName) -Phone ([string]$Record.phone) -GroupName ([string]$Record.groupName)
                $result = Invoke-MaxitochkaScript -Session $sessionToOpen -Expression $scriptText -TimeoutMs 22000
            }

            if ($result.ok -and ([bool]$result.foundChat -or $hasSpecificChatUrl)) {
                $Record.profile = [string]$sessionToOpen.Profile
                $Record.port = [int]$sessionToOpen.Port
                $Record.portFile = [string]$sessionToOpen.PortFile
                if ($result.url) { $Record.chatUrl = [string]$result.url }
                if ($result.title) { $Record.chatTitle = [string]$result.title }
                Save-ReplyRecords
                try { Invoke-MaxitochkaBringToFront -Session $sessionToOpen -TimeoutMs 6000 | Out-Null } catch {}
                Invoke-MaxitochkaWindowToFront -Session $sessionToOpen -DelayMs ([Math]::Max(500, [int]$script:SwitchDelayMs)) | Out-Null
                return
            }
        }
        catch {
            $lastError = $_.Exception.Message
        }
    }

    if ([string]::IsNullOrWhiteSpace($lastError)) { $lastError = 'Не нашел чат по этой строке.' }
    [System.Windows.Forms.MessageBox]::Show("Не удалось открыть чат:`n$lastError", 'Ответы MAX', 'OK', 'Error') | Out-Null
}

function Refresh-RepliesGrid {
    param([System.Windows.Forms.DataGridView]$GridControl, $StatusLabel = $null)

    if ($null -eq $GridControl) { return }

    Load-ReplyRecords
    $GridControl.SuspendLayout()
    try {
        $GridControl.Rows.Clear()
        $answerRecords = @(
            $script:ReplyRecords |
                Where-Object { $_.replyStatus -eq 'есть ответ' -and -not [string]::IsNullOrWhiteSpace([string]$_.lastReplyText) } |
                Sort-Object lastCheckedAt, createdAt -Descending
        )
        foreach ($record in $answerRecords) {
            $rowIndex = $GridControl.Rows.Add(
                [string]$record.createdAt,
                [string]$record.profile,
                [string]$record.contactName,
                [string]$record.phone,
                [string]$record.groupName,
                [string]$record.readStatus,
                [string]$record.replyStatus,
                [string]$record.lastReplyText,
                [string]$record.lastCheckedAt,
                [string]$record.id
            )
            $GridControl.Rows[$rowIndex].Tag = [string]$record.id
            if ([string]$record.replyStatus -eq 'есть ответ') {
                $GridControl.Rows[$rowIndex].DefaultCellStyle.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 9)
            }
        }
        $GridControl.ClearSelection()
    }
    finally {
        $GridControl.ResumeLayout()
    }

    if ($StatusLabel) {
        $answerCount = @($script:ReplyRecords | Where-Object { $_.replyStatus -eq 'есть ответ' -and -not [string]::IsNullOrWhiteSpace([string]$_.lastReplyText) }).Count
        $StatusLabel.Text = "Ответы: $answerCount | наблюдение: $($script:ReplyRecords.Count)"
    }
}

function Refresh-OpenRepliesWindow {
    if (-not ($script:RepliesWindow -is [System.Windows.Forms.Form])) { return }
    if ($script:RepliesWindow.IsDisposed) { return }
    if (-not ($script:RepliesWindowGrid -is [System.Windows.Forms.DataGridView])) { return }
    if ($script:RepliesWindowGrid.IsDisposed) { return }

    try {
        Refresh-RepliesGrid -GridControl $script:RepliesWindowGrid -StatusLabel $script:RepliesWindowStatusLabel
    }
    catch {
    }
}

function Get-SelectedReplyRecordFromGrid {
    param([System.Windows.Forms.DataGridView]$GridControl)

    if ($null -eq $GridControl -or $GridControl.SelectedRows.Count -eq 0) { return $null }
    $row = $GridControl.SelectedRows[0]
    if ($row.IsNewRow) { return $null }

    $id = if ($GridControl.Columns.Contains('Id')) { [string]$row.Cells['Id'].Value } else { [string]$row.Tag }
    if ([string]::IsNullOrWhiteSpace($id)) { return $null }

    Load-ReplyRecords
    return Get-ReplyRecordById $id
}

function Show-RepliesWindow {
    if ($script:Contacts -and $script:Contacts.Count -gt 0) {
        [void](Ensure-ReplyRecordsForContacts -Contacts @(Get-ValidContacts))
    }
    Ensure-MaxitochkaSessionsForReplies

    if ($script:RepliesWindow) {
        if ($script:RepliesWindow -is [System.Windows.Forms.Form] -and -not $script:RepliesWindow.IsDisposed) {
            try { $script:RepliesWindow.TopMost = $true } catch {}
            try { $script:RepliesWindow.Activate() } catch {}
            Refresh-OpenRepliesWindow
            return
        }

        $script:RepliesWindow = $null
        $script:RepliesWindowGrid = $null
        $script:RepliesWindowStatusLabel = $null
    }

    Load-ReplyRecords

    $replyForm = New-Object System.Windows.Forms.Form
    $replyForm.Text = 'Ответы'
    $replyForm.StartPosition = 'Manual'
    $replyForm.MinimumSize = New-Object System.Drawing.Size(580, 340)
    $replyForm.Size = New-Object System.Drawing.Size(760, 430)
    $replyForm.Font = New-Object System.Drawing.Font('Segoe UI', 9)
    $replyForm.FormBorderStyle = 'SizableToolWindow'
    $replyForm.ShowInTaskbar = $false
    try { $replyForm.TopMost = $true } catch {}
    try {
        $screen = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
        $replyForm.Location = New-Object System.Drawing.Point -ArgumentList ([int]($screen.Right - $replyForm.Width - 24)), ([int]($screen.Top + 205))
    }
    catch {
        $replyForm.StartPosition = 'CenterScreen'
    }
    Enable-DoubleBuffer $replyForm

    $layout = New-Object System.Windows.Forms.TableLayoutPanel
    $layout.Dock = 'Fill'
    $layout.ColumnCount = 1
    $layout.RowCount = 3
    $layout.Padding = New-Object System.Windows.Forms.Padding(10)
    $layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 30))) | Out-Null
    $layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
    $layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 48))) | Out-Null
    $replyForm.Controls.Add($layout)

    $statusLabel = New-Object System.Windows.Forms.Label
    $statusLabel.Dock = 'Fill'
    $statusLabel.TextAlign = 'MiddleLeft'
    $statusLabel.AccessibleName = 'MutedLabel'
    $layout.Controls.Add($statusLabel, 0, 0)

    $replyGrid = New-Object System.Windows.Forms.DataGridView
    $replyGrid.Dock = 'Fill'
    $replyGrid.AllowUserToAddRows = $false
    $replyGrid.AllowUserToDeleteRows = $false
    $replyGrid.ReadOnly = $true
    $replyGrid.SelectionMode = 'FullRowSelect'
    $replyGrid.MultiSelect = $false
    $replyGrid.AutoSizeColumnsMode = 'Fill'
    $replyGrid.RowHeadersVisible = $false
    [void]$replyGrid.Columns.Add('CreatedAt', 'Отправлено')
    [void]$replyGrid.Columns.Add('Profile', 'MAX')
    [void]$replyGrid.Columns.Add('ContactName', 'Человек')
    [void]$replyGrid.Columns.Add('Phone', 'Телефон')
    [void]$replyGrid.Columns.Add('GroupName', 'Чат')
    [void]$replyGrid.Columns.Add('ReadStatus', 'Прочитано')
    [void]$replyGrid.Columns.Add('ReplyStatus', 'Ответ')
    [void]$replyGrid.Columns.Add('LastReplyText', 'Последний ответ')
    [void]$replyGrid.Columns.Add('LastCheckedAt', 'Проверено')
    [void]$replyGrid.Columns.Add('Id', 'Id')
    $replyGrid.Columns['CreatedAt'].FillWeight = 95
    $replyGrid.Columns['Profile'].FillWeight = 90
    $replyGrid.Columns['ContactName'].FillWeight = 150
    $replyGrid.Columns['Phone'].FillWeight = 105
    $replyGrid.Columns['GroupName'].FillWeight = 140
    $replyGrid.Columns['ReadStatus'].FillWeight = 85
    $replyGrid.Columns['ReplyStatus'].FillWeight = 90
    $replyGrid.Columns['LastReplyText'].FillWeight = 220
    $replyGrid.Columns['LastCheckedAt'].FillWeight = 95
    $replyGrid.Columns['CreatedAt'].Visible = $false
    $replyGrid.Columns['Phone'].Visible = $false
    $replyGrid.Columns['LastCheckedAt'].Visible = $false
    $replyGrid.Columns['Id'].Visible = $false
    $replyGrid.Columns['Profile'].FillWeight = 70
    $replyGrid.Columns['ContactName'].FillWeight = 135
    $replyGrid.Columns['GroupName'].FillWeight = 120
    $replyGrid.Columns['ReadStatus'].FillWeight = 80
    $replyGrid.Columns['ReplyStatus'].FillWeight = 80
    $replyGrid.Columns['LastReplyText'].FillWeight = 235
    Set-DataGridLayout $replyGrid
    $layout.Controls.Add($replyGrid, 0, 1)

    $actionPanel = New-Object System.Windows.Forms.FlowLayoutPanel
    $actionPanel.Dock = 'Fill'
    $actionPanel.FlowDirection = 'LeftToRight'
    $actionPanel.WrapContents = $false
    $actionPanel.Padding = New-Object System.Windows.Forms.Padding(0, 7, 0, 0)
    $layout.Controls.Add($actionPanel, 0, 2)

    $refreshButton = New-Object System.Windows.Forms.Button
    $refreshButton.Text = 'Обновить ›'
    $refreshButton.Width = 132
    $refreshButton.Height = 34
    $refreshButton.Margin = New-Object System.Windows.Forms.Padding(0, 0, 10, 0)
    $refreshButton.AccessibleName = 'PrimaryAction'
    $actionPanel.Controls.Add($refreshButton)

    $openButton = New-Object System.Windows.Forms.Button
    $openButton.Text = 'В чат ›'
    $openButton.Width = 118
    $openButton.Height = 34
    $openButton.Margin = New-Object System.Windows.Forms.Padding(0, 0, 10, 0)
    $openButton.AccessibleName = 'MenuRow'
    $actionPanel.Controls.Add($openButton)

    $closeButton = New-Object System.Windows.Forms.Button
    $closeButton.Text = 'Закрыть'
    $closeButton.Width = 118
    $closeButton.Height = 34
    $closeButton.Margin = New-Object System.Windows.Forms.Padding(0, 0, 10, 0)
    $closeButton.AccessibleName = 'MenuRow'
    $actionPanel.Controls.Add($closeButton)

    $refreshButton.Add_Click({
        try {
            $refreshButton.Enabled = $false
            $openButton.Enabled = $false
            if ($script:RepliesWindowTimer) { $script:RepliesWindowTimer.Stop() }
            $script:RepliesLastVisibleScanAt = [DateTime]::MinValue
            try { [void](Update-ReplyRecordsFromVisibleChats -StatusLabel $statusLabel -Notify $true -IntervalSeconds 0) } catch {}
            try { Update-ReplyRecordsFromMaxitochka -StatusLabel $statusLabel -Notify $true } catch {}
            Refresh-RepliesGrid -GridControl $replyGrid -StatusLabel $statusLabel
        }
        catch {
            if ($statusLabel) { $statusLabel.Text = "Ответы: ошибка обновления, работа продолжается" }
        }
        finally {
            if ($script:RepliesWindowTimer) { $script:RepliesWindowTimer.Start() }
            $refreshButton.Enabled = $true
            $openButton.Enabled = $true
        }
    })
    $openButton.Add_Click({
        try {
            $record = Get-SelectedReplyRecordFromGrid $replyGrid
            if (-not $record) {
                [System.Windows.Forms.MessageBox]::Show('Выбери строку с человеком.', 'Ответы MAX', 'OK', 'Information') | Out-Null
                return
            }
            Open-ReplyRecordChat $record
        }
        catch {
            if ($statusLabel) { $statusLabel.Text = "Ответы: не удалось открыть чат" }
        }
    })
    $replyGrid.Add_CellDoubleClick({
        try {
            $record = Get-SelectedReplyRecordFromGrid $replyGrid
            if ($record) { Open-ReplyRecordChat $record }
        }
        catch {
            if ($statusLabel) { $statusLabel.Text = "Ответы: не удалось открыть чат" }
        }
    })
    $closeButton.Add_Click({ $replyForm.Close() })

    Refresh-RepliesGrid -GridControl $replyGrid -StatusLabel $statusLabel

    $autoRefreshTimer = New-Object System.Windows.Forms.Timer
    $autoRefreshTimer.Interval = 1200
    $autoRefreshTimer.Add_Tick({
        try {
            if (-not ($script:RepliesWindow -is [System.Windows.Forms.Form]) -or $script:RepliesWindow.IsDisposed) {
                if ($script:RepliesWindowTimer) {
                    $script:RepliesWindowTimer.Stop()
                }
                return
            }
            Refresh-OpenRepliesWindow
        }
        catch {
            if ($script:RepliesWindowStatusLabel) {
                $script:RepliesWindowStatusLabel.Text = 'Ответы: таймер остановлен из-за ошибки'
            }
            try {
                if ($script:RepliesWindowTimer) { $script:RepliesWindowTimer.Stop() }
            }
            catch {
            }
        }
    })
    $script:RepliesWindowTimer = $autoRefreshTimer
    $autoRefreshTimer.Start()

    try {
        $palette = if ($script:CurrentThemePalette) { $script:CurrentThemePalette } else { Get-AppThemePalette $script:UiTheme }
        Set-ControlTheme -Control $replyForm -Palette $palette
        Set-WindowFrameTheme -TargetForm $replyForm -Palette $palette -UseDarkMode ($script:UiTheme -in @('Карбон', 'Темная', 'Коричневая', 'Дота', 'Раст', 'Радуга', 'COURAGE'))
    }
    catch {
    }

    $replyForm.Add_Shown({
        param($sender, $eventArgs)
        if ($sender -is [System.Windows.Forms.Form]) {
            try { $sender.TopMost = $true } catch {}
        }
    })
    $replyForm.Add_FormClosed({
        try {
            if ($script:RepliesWindowTimer) {
                $script:RepliesWindowTimer.Stop()
                $script:RepliesWindowTimer.Dispose()
            }
        }
        catch {
        }
        $script:RepliesWindow = $null
        $script:RepliesWindowGrid = $null
        $script:RepliesWindowStatusLabel = $null
        $script:RepliesWindowTimer = $null
    })
    $script:RepliesWindow = $replyForm
    $script:RepliesWindowGrid = $replyGrid
    $script:RepliesWindowStatusLabel = $statusLabel
    if ($form) {
        [void]$replyForm.Show($form)
    }
    else {
        [void]$replyForm.Show()
    }
}

Load-ProcessingState
Load-ReplyRecords

$form = New-Object System.Windows.Forms.Form
$form.Text = $script:AppTitle
$form.StartPosition = 'CenterScreen'
$form.AutoScaleMode = 'Font'
$form.Font = New-Object System.Drawing.Font('Segoe UI', 9)
$form.FormBorderStyle = 'None'
$form.KeyPreview = $true
$form.Padding = New-Object System.Windows.Forms.Padding(1)
$form.ShowInTaskbar = $true
$form.MinimumSize = New-Object System.Drawing.Size(1120, 760)
$form.Size = New-Object System.Drawing.Size(1240, 840)
Enable-DoubleBuffer $form

$rootPanel = New-Object System.Windows.Forms.TableLayoutPanel
$rootPanel.Dock = 'Fill'
$rootPanel.ColumnCount = 1
$rootPanel.RowCount = 3
$rootPanel.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 38))) | Out-Null
$rootPanel.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 42))) | Out-Null
$rootPanel.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
$form.Controls.Add($rootPanel)

$titlePanel = New-Object System.Windows.Forms.TableLayoutPanel
$titlePanel.Dock = 'Fill'
$titlePanel.ColumnCount = 5
$titlePanel.RowCount = 1
$titlePanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 38))) | Out-Null
$titlePanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
$titlePanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 44))) | Out-Null
$titlePanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 44))) | Out-Null
$titlePanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 44))) | Out-Null
$rootPanel.Controls.Add($titlePanel, 0, 0)

$titleIconLabel = New-Object System.Windows.Forms.Label
$titleIconLabel.Text = ''
$titleIconLabel.Dock = 'Fill'
$titleIconLabel.TextAlign = 'MiddleCenter'
$titleIconLabel.Font = New-Object System.Drawing.Font('Segoe UI', 13)
$titleIconLabel.Margin = New-Object System.Windows.Forms.Padding(6, 0, 4, 0)
$titleIconLabel.Cursor = [System.Windows.Forms.Cursors]::Hand
$titlePanel.Controls.Add($titleIconLabel, 0, 0)

$titleLabel = New-Object System.Windows.Forms.Label
$titleLabel.Text = "$($script:AppTitle) v$($script:AppVersion)"
$titleLabel.Dock = 'Fill'
$titleLabel.TextAlign = 'MiddleLeft'
$titleLabel.AutoEllipsis = $true
$titleLabel.Margin = New-Object System.Windows.Forms.Padding(0, 0, 8, 0)
$titlePanel.Controls.Add($titleLabel, 1, 0)

$titleMinButton = New-Object System.Windows.Forms.Button
$titleMinButton.Text = '−'
$titleMinButton.Dock = 'Fill'
$titleMinButton.FlatStyle = 'Flat'
$titleMinButton.UseVisualStyleBackColor = $false
$titleMinButton.FlatAppearance.BorderSize = 0
$titlePanel.Controls.Add($titleMinButton, 2, 0)

$titleMaxButton = New-Object System.Windows.Forms.Button
$titleMaxButton.Text = '□'
$titleMaxButton.Dock = 'Fill'
$titleMaxButton.FlatStyle = 'Flat'
$titleMaxButton.UseVisualStyleBackColor = $false
$titleMaxButton.FlatAppearance.BorderSize = 0
$titlePanel.Controls.Add($titleMaxButton, 3, 0)

$titleCloseButton = New-Object System.Windows.Forms.Button
$titleCloseButton.Text = '×'
$titleCloseButton.Dock = 'Fill'
$titleCloseButton.FlatStyle = 'Flat'
$titleCloseButton.UseVisualStyleBackColor = $false
$titleCloseButton.FlatAppearance.BorderSize = 0
$titlePanel.Controls.Add($titleCloseButton, 4, 0)

$navPanel = New-Object System.Windows.Forms.TableLayoutPanel
$navPanel.Dock = 'Fill'
$navPanel.ColumnCount = 4
$navPanel.RowCount = 1
$navPanel.Padding = New-Object System.Windows.Forms.Padding(14, 6, 14, 4)
$navPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 132))) | Out-Null
$navPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 132))) | Out-Null
$navPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 150))) | Out-Null
$navPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
Enable-DoubleBuffer $navPanel
$rootPanel.Controls.Add($navPanel, 0, 1)

$workNavButton = New-Object System.Windows.Forms.Button
$workNavButton.Text = 'Работа'
$workNavButton.Dock = 'Fill'
$workNavButton.FlatStyle = 'Flat'
$workNavButton.UseVisualStyleBackColor = $false
$workNavButton.FlatAppearance.BorderSize = 0
$workNavButton.AccessibleName = 'NavButton'
$workNavButton.Margin = New-Object System.Windows.Forms.Padding(0, 0, 8, 0)
$navPanel.Controls.Add($workNavButton, 0, 0)

$settingsNavButton = New-Object System.Windows.Forms.Button
$settingsNavButton.Text = 'Настройки'
$settingsNavButton.Dock = 'Fill'
$settingsNavButton.FlatStyle = 'Flat'
$settingsNavButton.UseVisualStyleBackColor = $false
$settingsNavButton.FlatAppearance.BorderSize = 0
$settingsNavButton.AccessibleName = 'NavButton'
$settingsNavButton.Margin = New-Object System.Windows.Forms.Padding(0, 0, 8, 0)
$navPanel.Controls.Add($settingsNavButton, 1, 0)

$updatesNavButton = New-Object System.Windows.Forms.Button
$updatesNavButton.Text = 'Обновления'
$updatesNavButton.Dock = 'Fill'
$updatesNavButton.FlatStyle = 'Flat'
$updatesNavButton.UseVisualStyleBackColor = $false
$updatesNavButton.FlatAppearance.BorderSize = 0
$updatesNavButton.AccessibleName = 'NavButton'
$updatesNavButton.Margin = New-Object System.Windows.Forms.Padding(0, 0, 8, 0)
$navPanel.Controls.Add($updatesNavButton, 2, 0)

$contentPanel = New-Object System.Windows.Forms.Panel
$contentPanel.Dock = 'Fill'
Enable-DoubleBuffer $contentPanel
$rootPanel.Controls.Add($contentPanel, 0, 2)

$workTab = New-Object System.Windows.Forms.Panel
$workTab.Dock = 'Fill'

$settingsTab = New-Object System.Windows.Forms.Panel
$settingsTab.Dock = 'Fill'
$settingsTab.Visible = $false

$updatesTab = New-Object System.Windows.Forms.Panel
$updatesTab.Dock = 'Fill'
$updatesTab.Visible = $false

$contentPanel.Controls.Add($updatesTab)
$contentPanel.Controls.Add($settingsTab)
$contentPanel.Controls.Add($workTab)
$workTab.BringToFront()

function Update-NavigationButtons {
    if (-not $workNavButton -or -not $settingsNavButton -or -not $updatesNavButton) { return }

    $palette = if ($script:CurrentThemePalette) { $script:CurrentThemePalette } else { Get-AppThemePalette $script:UiTheme }
    $wallpaperEnabled = Test-AppWallpaperEnabled
    $workActive = ($workTab -and $workTab.Visible)
    $settingsActive = ($settingsTab -and $settingsTab.Visible)
    $updatesActive = ($updatesTab -and $updatesTab.Visible)

    foreach ($item in @(
        [pscustomobject]@{ Button = $workNavButton; Active = $workActive },
        [pscustomobject]@{ Button = $settingsNavButton; Active = $settingsActive },
        [pscustomobject]@{ Button = $updatesNavButton; Active = $updatesActive }
    )) {
        $button = $item.Button
        if (-not $button) { continue }

        $backColor = if ($item.Active) {
            if ($wallpaperEnabled) { Convert-HtmlColorWithAlpha $palette.Row 150 } else { Convert-HtmlColor $palette.Row }
        }
        else {
            if ($wallpaperEnabled) { Convert-HtmlColorWithAlpha $palette.Form 70 } else { Convert-HtmlColor $palette.Form }
        }
        Set-ControlBackColorSafe -Control $button -Color $backColor -FallbackColor (Convert-HtmlColor $(if ($item.Active) { $palette.Row } else { $palette.Form }))
        $button.ForeColor = Convert-HtmlColor $(if ($item.Active) { $palette.Text } else { $palette.Muted })
        $button.Font = New-Object System.Drawing.Font($(if ($item.Active) { 'Segoe UI Semibold' } else { 'Segoe UI' }), 9)
        $button.FlatAppearance.BorderSize = 0
        $button.FlatAppearance.MouseOverBackColor = if ($wallpaperEnabled) { Convert-HtmlColorWithAlpha $palette.RowHover 165 } else { Convert-HtmlColor $palette.RowHover }
        $button.FlatAppearance.MouseDownBackColor = if ($wallpaperEnabled) { Convert-HtmlColorWithAlpha $palette.Selection 205 } else { Convert-HtmlColor $palette.Selection }
        $button.Invalidate()
    }
}

function Show-AppPage {
    param([string]$Page)

    if (-not $workTab -or -not $settingsTab -or -not $updatesTab) { return }

    try {
        if ($contentPanel) { $contentPanel.SuspendLayout() }
        $showSettings = ([string]::Equals($Page, 'settings', [StringComparison]::OrdinalIgnoreCase))
        $showUpdates = ([string]::Equals($Page, 'updates', [StringComparison]::OrdinalIgnoreCase))
        $workTab.Visible = (-not $showSettings -and -not $showUpdates)
        $settingsTab.Visible = $showSettings
        $updatesTab.Visible = $showUpdates
        if ($showUpdates) {
            $updatesTab.BringToFront()
        }
        elseif ($showSettings) {
            $settingsTab.BringToFront()
        }
        else {
            $workTab.BringToFront()
        }
        Update-NavigationButtons
    }
    finally {
        if ($contentPanel) { $contentPanel.ResumeLayout($true) }
    }
}

$workNavButton.Add_Click({ Show-AppPage 'work' })
$settingsNavButton.Add_Click({ Show-AppPage 'settings' })
$updatesNavButton.Add_Click({ Show-AppPage 'updates' })

$updatesAdminMode = Test-AppUpdateAdminMode
$updatesAdminSourceRowHeight = if ($updatesAdminMode) { 52 } else { 0 }
$updatesAdminPublishRowHeight = if ($updatesAdminMode) { 48 } else { 0 }

$updatesMain = New-Object System.Windows.Forms.TableLayoutPanel
$updatesMain.Dock = 'Fill'
$updatesMain.ColumnCount = 1
$updatesMain.RowCount = 5
$updatesMain.Padding = New-Object System.Windows.Forms.Padding(24, 18, 24, 18)
Enable-DoubleBuffer $updatesMain
$updatesMain.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 52))) | Out-Null
$updatesMain.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, $updatesAdminSourceRowHeight))) | Out-Null
$updatesMain.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, $updatesAdminPublishRowHeight))) | Out-Null
$updatesMain.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 54))) | Out-Null
$updatesMain.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 46))) | Out-Null
$updatesTab.Controls.Add($updatesMain)

$updatesHeader = New-Object System.Windows.Forms.TableLayoutPanel
$updatesHeader.Dock = 'Fill'
$updatesHeader.ColumnCount = 3
$updatesHeader.RowCount = 1
$updatesHeader.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
$updatesHeader.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 190))) | Out-Null
$updatesHeader.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 140))) | Out-Null
Enable-DoubleBuffer $updatesHeader
$updatesMain.Controls.Add($updatesHeader, 0, 0)

$updatesTitleLabel = New-Object System.Windows.Forms.Label
$updatesTitleLabel.Text = 'Обновления'
$updatesTitleLabel.Dock = 'Fill'
$updatesTitleLabel.TextAlign = 'MiddleLeft'
$updatesTitleLabel.AccessibleName = 'SettingsLabel'
$updatesHeader.Controls.Add($updatesTitleLabel, 0, 0)

$updatesVersionLabel = New-Object System.Windows.Forms.Label
$updatesVersionLabel.Text = "Текущая версия: v$($script:AppVersion)"
$updatesVersionLabel.Dock = 'Fill'
$updatesVersionLabel.TextAlign = 'MiddleLeft'
$updatesVersionLabel.AccessibleName = 'MutedLabel'
$updatesHeader.Controls.Add($updatesVersionLabel, 1, 0)

$updatesUpdateButton = New-Object System.Windows.Forms.Button
$updatesUpdateButton.Text = 'Обновить'
$updatesUpdateButton.Dock = 'Fill'
$updatesUpdateButton.AccessibleName = 'MenuRow'
$updatesHeader.Controls.Add($updatesUpdateButton, 2, 0)

$updatesSourcePanel = New-Object System.Windows.Forms.TableLayoutPanel
$updatesSourcePanel.Dock = 'Fill'
$updatesSourcePanel.ColumnCount = 4
$updatesSourcePanel.RowCount = 1
$updatesSourcePanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 160))) | Out-Null
$updatesSourcePanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
$updatesSourcePanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 118))) | Out-Null
$updatesSourcePanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 118))) | Out-Null
Enable-DoubleBuffer $updatesSourcePanel
$updatesSourcePanel.Visible = $updatesAdminMode
$updatesMain.Controls.Add($updatesSourcePanel, 0, 1)

$updatesSourceLabel = New-Object System.Windows.Forms.Label
$updatesSourceLabel.Text = 'Сайт / канал'
$updatesSourceLabel.Dock = 'Fill'
$updatesSourceLabel.TextAlign = 'MiddleLeft'
$updatesSourceLabel.AccessibleName = 'SettingsLabel'
$updatesSourcePanel.Controls.Add($updatesSourceLabel, 0, 0)

$updatesSourceBox = New-Object System.Windows.Forms.TextBox
$updatesSourceBox.Dock = 'Fill'
$updatesSourceBox.Text = [string]$script:UpdateSourcePath
$updatesSourcePanel.Controls.Add($updatesSourceBox, 1, 0)

$updatesBrowseSourceButton = New-Object System.Windows.Forms.Button
$updatesBrowseSourceButton.Text = 'Выбрать'
$updatesBrowseSourceButton.Dock = 'Fill'
$updatesBrowseSourceButton.AccessibleName = 'MenuRow'
$updatesSourcePanel.Controls.Add($updatesBrowseSourceButton, 2, 0)

$updatesSaveSourceButton = New-Object System.Windows.Forms.Button
$updatesSaveSourceButton.Text = 'Сохранить'
$updatesSaveSourceButton.Dock = 'Fill'
$updatesSaveSourceButton.AccessibleName = 'MenuRow'
$updatesSourcePanel.Controls.Add($updatesSaveSourceButton, 3, 0)

$updatesPublishPanel = New-Object System.Windows.Forms.TableLayoutPanel
$updatesPublishPanel.Dock = 'Fill'
$updatesPublishPanel.ColumnCount = 2
$updatesPublishPanel.RowCount = 1
$updatesPublishPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
$updatesPublishPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 180))) | Out-Null
Enable-DoubleBuffer $updatesPublishPanel
$updatesPublishPanel.Visible = $updatesAdminMode
$updatesMain.Controls.Add($updatesPublishPanel, 0, 2)

$updatesChannelStatusLabel = New-Object System.Windows.Forms.Label
$updatesChannelStatusLabel.Text = 'Укажи папку или ссылку https://site.ru/gus-updates/. Рабочие ПК читают этот канал.'
$updatesChannelStatusLabel.Dock = 'Fill'
$updatesChannelStatusLabel.TextAlign = 'MiddleLeft'
$updatesChannelStatusLabel.AutoEllipsis = $true
$updatesChannelStatusLabel.AccessibleName = 'MutedLabel'
$updatesPublishPanel.Controls.Add($updatesChannelStatusLabel, 0, 0)

$updatesPublishButton = New-Object System.Windows.Forms.Button
$updatesPublishButton.Text = 'Опубликовать'
$updatesPublishButton.Dock = 'Fill'
$updatesPublishButton.AccessibleName = 'MenuRow'
$updatesPublishPanel.Controls.Add($updatesPublishButton, 1, 0)

$updatesGrid = New-Object System.Windows.Forms.DataGridView
$updatesGrid.Dock = 'Fill'
$updatesGrid.AllowUserToAddRows = $false
$updatesGrid.AllowUserToDeleteRows = $false
$updatesGrid.AllowUserToResizeRows = $false
$updatesGrid.AutoSizeRowsMode = 'AllCells'
$updatesGrid.BackgroundColor = [System.Drawing.Color]::White
$updatesGrid.BorderStyle = 'None'
$updatesGrid.ColumnHeadersHeight = 34
$updatesGrid.ColumnHeadersHeightSizeMode = 'DisableResizing'
$updatesGrid.EditMode = 'EditProgrammatically'
$updatesGrid.MultiSelect = $false
$updatesGrid.ReadOnly = $true
$updatesGrid.RowHeadersVisible = $false
$updatesGrid.SelectionMode = 'FullRowSelect'
$updatesGrid.Margin = New-Object System.Windows.Forms.Padding(0, 8, 0, 8)
[void]$updatesGrid.Columns.Add('Version', 'Версия')
[void]$updatesGrid.Columns.Add('Date', 'Дата')
[void]$updatesGrid.Columns.Add('Title', 'Что изменилось')
$updatesGrid.Columns['Version'].Width = 110
$updatesGrid.Columns['Date'].Width = 130
$updatesGrid.Columns['Title'].AutoSizeMode = 'Fill'
$updatesMain.Controls.Add($updatesGrid, 0, 3)

$updatesDetailsBox = New-Object System.Windows.Forms.TextBox
$updatesDetailsBox.Dock = 'Fill'
$updatesDetailsBox.Multiline = $true
$updatesDetailsBox.ReadOnly = $true
$updatesDetailsBox.ScrollBars = 'Vertical'
$updatesDetailsBox.Margin = New-Object System.Windows.Forms.Padding(0, 6, 0, 0)
$updatesMain.Controls.Add($updatesDetailsBox, 0, 4)

function Show-SelectedUpdateDetails {
    if (-not $updatesGrid -or -not $updatesDetailsBox) { return }
    if ($updatesGrid.SelectedRows.Count -le 0) { return }

    $entry = $updatesGrid.SelectedRows[0].Tag
    if (-not $entry) { return }

    $lines = New-Object System.Collections.Generic.List[string]
    $lines.Add(("v{0} - {1}" -f $entry.Version, $entry.Title))
    $lines.Add(("Дата: {0}" -f $entry.Date))
    $lines.Add('')
    $lines.Add('Изменения:')
    foreach ($change in @($entry.Changes)) {
        $lines.Add(("- {0}" -f $change))
    }
    $updatesDetailsBox.Text = ($lines -join [Environment]::NewLine)
}

foreach ($entry in @($script:UpdateHistory)) {
    $rowIndex = $updatesGrid.Rows.Add()
    $row = $updatesGrid.Rows[$rowIndex]
    $row.Cells['Version'].Value = "v$($entry.Version)"
    $row.Cells['Date'].Value = [string]$entry.Date
    $row.Cells['Title'].Value = [string]$entry.Title
    $row.Tag = $entry
}
if ($updatesGrid.Rows.Count -gt 0) {
    $updatesGrid.Rows[0].Selected = $true
}
$updatesGrid.Add_SelectionChanged({ Show-SelectedUpdateDetails })
$updatesUpdateButton.Add_Click({ Invoke-AppUpdate })
$updatesBrowseSourceButton.Add_Click({
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = 'Выбери папку канала обновлений'
    $dialog.ShowNewFolderButton = $true
    if ($dialog.ShowDialog() -eq 'OK') {
        $updatesSourceBox.Text = $dialog.SelectedPath
    }
})
$updatesSaveSourceButton.Add_Click({
    if (Set-AppUpdateSourceText $updatesSourceBox.Text) {
        $updatesChannelStatusLabel.Text = 'Канал обновлений сохранен.'
        [System.Windows.Forms.MessageBox]::Show('Канал обновлений сохранен. Теперь кнопка Обновить будет проверять этот путь.', 'Обновления', 'OK', 'Information') | Out-Null
    }
    else {
        [System.Windows.Forms.MessageBox]::Show('Не удалось сохранить канал обновлений. Укажи папку, сетевой путь или ссылку.', 'Обновления', 'OK', 'Warning') | Out-Null
    }
})
$updatesPublishButton.Add_Click({
    try {
        $target = Publish-AppUpdateChannel $updatesSourceBox.Text
        if (Test-AppUpdateUrl $updatesSourceBox.Text) {
            $updatesChannelStatusLabel.Text = "Файлы для сайта готовы: $target"
            [System.Windows.Forms.MessageBox]::Show("Файлы для сайта готовы:`n$target`n`nЗалей их на сайт по ссылке:`n$($updatesSourceBox.Text.Trim())`n`nПосле этого рабочие ПК смогут нажать Обновить.", 'Обновления', 'OK', 'Information') | Out-Null
        }
        else {
            $updatesChannelStatusLabel.Text = "Опубликована версия $($script:AppVersion): $target"
            [System.Windows.Forms.MessageBox]::Show("Обновление опубликовано:`n$target`n`nРабочие ПК смогут нажать Обновить.", 'Обновления', 'OK', 'Information') | Out-Null
        }
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show("Не удалось опубликовать обновление:`n$($_.Exception.Message)", 'Обновления', 'OK', 'Error') | Out-Null
    }
})
Show-SelectedUpdateDetails

$main = New-Object System.Windows.Forms.TableLayoutPanel
$main.Dock = 'Fill'
$main.ColumnCount = 1
$main.RowCount = 4
$main.Padding = New-Object System.Windows.Forms.Padding(18, 16, 18, 16)
Enable-DoubleBuffer $main
$main.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 46))) | Out-Null
$main.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
$main.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 156))) | Out-Null
$main.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 70))) | Out-Null
$workTab.Controls.Add($main)

$topPanel = New-Object System.Windows.Forms.TableLayoutPanel
$topPanel.Dock = 'Fill'
$topPanel.ColumnCount = 4
$topPanel.RowCount = 3
$topPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 150))) | Out-Null
$topPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 45))) | Out-Null
$topPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 120))) | Out-Null
$topPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 55))) | Out-Null
$topPanel.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 38))) | Out-Null
$topPanel.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 0))) | Out-Null
$topPanel.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 0))) | Out-Null
$main.Controls.Add($topPanel, 0, 0)

$openButton = New-Object System.Windows.Forms.Button
$openButton.Text = 'Открыть TXT   ›'
$openButton.Dock = 'Fill'
$openButton.Margin = New-Object System.Windows.Forms.Padding(0, 0, 10, 0)
$openButton.AccessibleName = 'MenuRow'
$topPanel.Controls.Add($openButton, 0, 0)

$fileLabel = New-Object System.Windows.Forms.Label
$fileLabel.Text = 'Файл не выбран'
$fileLabel.TextAlign = 'MiddleLeft'
$fileLabel.Dock = 'Fill'
$fileLabel.AutoEllipsis = $true
$fileLabel.Margin = New-Object System.Windows.Forms.Padding(10, 0, 8, 0)
$fileLabel.AccessibleName = 'MutedLabel'
$topPanel.Controls.Add($fileLabel, 1, 0)

$groupLabel = New-Object System.Windows.Forms.Label
$groupLabel.Text = 'Группа'
$groupLabel.TextAlign = 'MiddleRight'
$groupLabel.Dock = 'Fill'
$groupLabel.Visible = $false
$topPanel.Controls.Add($groupLabel, 2, 0)

$groupBox = New-Object System.Windows.Forms.TextBox
$groupBox.Dock = 'Fill'
$groupBox.Text = 'Новая группа'
$groupBox.Margin = New-Object System.Windows.Forms.Padding(10, 4, 0, 4)
$topPanel.Controls.Add($groupBox, 3, 0)

$formatLabel = New-Object System.Windows.Forms.Label
$formatLabel.Text = ''
$formatLabel.TextAlign = 'MiddleLeft'
$formatLabel.Dock = 'Fill'
$topPanel.SetColumnSpan($formatLabel, 2)
$topPanel.Controls.Add($formatLabel, 0, 1)

$statsLabel = New-Object System.Windows.Forms.Label
$statsLabel.Text = 'Контактов: 0 | OK: 0 | Проверить: 0'
$statsLabel.TextAlign = 'MiddleRight'
$statsLabel.Dock = 'Fill'
$statsLabel.AutoEllipsis = $true
$statsLabel.AccessibleName = 'MutedLabel'
$topPanel.SetColumnSpan($statsLabel, 2)
$topPanel.Controls.Add($statsLabel, 2, 0)

$groupModeHint = New-Object System.Windows.Forms.Label
$groupModeHint.Text = ''
$groupModeHint.TextAlign = 'MiddleLeft'
$groupModeHint.Dock = 'Fill'
$topPanel.SetColumnSpan($groupModeHint, 2)
$topPanel.Controls.Add($groupModeHint, 0, 2)

$groupNameModeLabel = New-Object System.Windows.Forms.Label
$groupNameModeLabel.Text = 'Шаблон группы'
$groupNameModeLabel.TextAlign = 'MiddleRight'
$groupNameModeLabel.Dock = 'Fill'
$topPanel.Controls.Add($groupNameModeLabel, 2, 2)

$groupNameModeBox = New-Object System.Windows.Forms.ComboBox
$groupNameModeBox.Dock = 'Fill'
$groupNameModeBox.DropDownStyle = 'DropDownList'
Enable-ThemedComboBox $groupNameModeBox
[void]$groupNameModeBox.Items.Add('Домофон')
[void]$groupNameModeBox.Items.Add('Ключи')
[void]$groupNameModeBox.Items.Add('Фамилия + Домофон')
[void]$groupNameModeBox.Items.Add('Фамилия + Ключи')
$groupNameModeBox.SelectedIndex = 2
$topPanel.Controls.Add($groupNameModeBox, 3, 2)

$grid = New-Object System.Windows.Forms.DataGridView
$grid.Dock = 'Fill'
$grid.AllowUserToAddRows = $false
$grid.AllowUserToDeleteRows = $false
$grid.ReadOnly = $true
$grid.SelectionMode = 'FullRowSelect'
$grid.AutoSizeColumnsMode = 'Fill'
$grid.RowHeadersVisible = $false
$grid.Columns.Add('Line', 'Строка') | Out-Null
$grid.Columns.Add('FullName', 'ФИО') | Out-Null
$grid.Columns.Add('Phone', 'Телефон') | Out-Null
$grid.Columns.Add('BirthDate', 'Дата рождения') | Out-Null
$grid.Columns.Add('MaxUserId', 'MaxUserId') | Out-Null
$grid.Columns.Add('Status', 'Статус') | Out-Null
$grid.Columns['Line'].FillWeight = 45
$grid.Columns['FullName'].FillWeight = 180
$grid.Columns['Phone'].FillWeight = 110
$grid.Columns['BirthDate'].FillWeight = 100
$grid.Columns['MaxUserId'].FillWeight = 100
$grid.Columns['Status'].FillWeight = 90
$grid.Columns['MaxUserId'].Visible = $false
Set-DataGridLayout $grid
$main.Controls.Add($grid, 0, 1)

$messagePanel = New-Object System.Windows.Forms.TableLayoutPanel
$messagePanel.Dock = 'Fill'
$messagePanel.ColumnCount = 1
$messagePanel.RowCount = 2
$messagePanel.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 36))) | Out-Null
$messagePanel.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
$main.Controls.Add($messagePanel, 0, 2)

$messageHeaderPanel = New-Object System.Windows.Forms.TableLayoutPanel
$messageHeaderPanel.Dock = 'Fill'
$messageHeaderPanel.ColumnCount = 4
$messageHeaderPanel.RowCount = 1
$messageHeaderPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
$messageHeaderPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 136))) | Out-Null
$messageHeaderPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 130))) | Out-Null
$messageHeaderPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 238))) | Out-Null
$messagePanel.Controls.Add($messageHeaderPanel, 0, 0)

$messageLabel = New-Object System.Windows.Forms.Label
$messageLabel.Text = 'Текст сообщения'
$messageLabel.Dock = 'Fill'
$messageLabel.TextAlign = 'MiddleLeft'
$messageLabel.AccessibleName = 'AccentLabel'
$messageHeaderPanel.Controls.Add($messageLabel, 0, 0)

$loadTextsButton = New-Object System.Windows.Forms.Button
$loadTextsButton.Text = 'Тексты TXT'
$loadTextsButton.Dock = 'Fill'
$loadTextsButton.AccessibleName = 'MenuRow'
$messageHeaderPanel.Controls.Add($loadTextsButton, 1, 0)

$clearTextsButton = New-Object System.Windows.Forms.Button
$clearTextsButton.Text = 'Один текст'
$clearTextsButton.Dock = 'Fill'
$clearTextsButton.AccessibleName = 'MenuRow'
$messageHeaderPanel.Controls.Add($clearTextsButton, 2, 0)

$messageTemplatesStatusLabel = New-Object System.Windows.Forms.Label
$messageTemplatesStatusLabel.Text = 'Текстов: 1 | из поля ниже'
$messageTemplatesStatusLabel.Dock = 'Fill'
$messageTemplatesStatusLabel.TextAlign = 'MiddleLeft'
$messageTemplatesStatusLabel.AccessibleName = 'MutedLabel'
$messageHeaderPanel.Controls.Add($messageTemplatesStatusLabel, 3, 0)

$messageBox = New-Object System.Windows.Forms.TextBox
$messageBox.Multiline = $true
$messageBox.ScrollBars = 'Vertical'
$messageBox.Dock = 'Fill'
$messageBox.Text = "Здравствуйте, {fio}! Вы добавлены в группу ""{group}""."
if ($script:MessageTemplates.Count -gt 0) {
    $messageBox.Text = [string]$script:MessageTemplates[$script:MessageTemplateIndex % $script:MessageTemplates.Count]
}
$messagePanel.Controls.Add($messageBox, 0, 1)

$apiPanel = New-Object System.Windows.Forms.TableLayoutPanel
$apiPanel.Dock = 'Fill'
$apiPanel.ColumnCount = 4
$apiPanel.RowCount = 2
$apiPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 120))) | Out-Null
$apiPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 58))) | Out-Null
$apiPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 90))) | Out-Null
$apiPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 42))) | Out-Null
$apiPanel.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 34))) | Out-Null
$apiPanel.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 34))) | Out-Null

$tokenLabel = New-Object System.Windows.Forms.Label
$tokenLabel.Text = 'MAX токен'
$tokenLabel.Dock = 'Fill'
$tokenLabel.TextAlign = 'MiddleRight'
$apiPanel.Controls.Add($tokenLabel, 0, 0)

$tokenBox = New-Object System.Windows.Forms.TextBox
$tokenBox.Dock = 'Fill'
$tokenBox.UseSystemPasswordChar = $true
$apiPanel.Controls.Add($tokenBox, 1, 0)

$chatIdLabel = New-Object System.Windows.Forms.Label
$chatIdLabel.Text = 'Chat ID'
$chatIdLabel.Dock = 'Fill'
$chatIdLabel.TextAlign = 'MiddleRight'
$apiPanel.Controls.Add($chatIdLabel, 2, 0)

$chatIdBox = New-Object System.Windows.Forms.TextBox
$chatIdBox.Dock = 'Fill'
$apiPanel.Controls.Add($chatIdBox, 3, 0)

$consentCheck = New-Object System.Windows.Forms.CheckBox
$consentCheck.Checked = $true
$consentCheck.Visible = $false

$apiHint = New-Object System.Windows.Forms.Label
$apiHint.Text = ''
$apiHint.Dock = 'Fill'
$apiHint.TextAlign = 'MiddleLeft'
$apiPanel.SetColumnSpan($apiHint, 4)
$apiPanel.Controls.Add($apiHint, 0, 1)

$maxitochkaPanel = New-Object System.Windows.Forms.TableLayoutPanel
$maxitochkaPanel.Dock = 'Fill'
$maxitochkaPanel.ColumnCount = 5
$maxitochkaPanel.RowCount = 2
$maxitochkaPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 92))) | Out-Null
$maxitochkaPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
$maxitochkaPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 118))) | Out-Null
$maxitochkaPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 112))) | Out-Null
$maxitochkaPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 270))) | Out-Null
$maxitochkaPanel.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 40))) | Out-Null
$maxitochkaPanel.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
$main.Controls.Add($maxitochkaPanel, 0, 2)

$maxitochkaLabel = New-Object System.Windows.Forms.Label
$maxitochkaLabel.Text = 'MAX'
$maxitochkaLabel.Dock = 'Fill'
$maxitochkaLabel.TextAlign = 'MiddleLeft'
$maxitochkaLabel.AccessibleName = 'SettingsLabel'
$maxitochkaPanel.Controls.Add($maxitochkaLabel, 0, 0)

$maxitochkaPathBox = New-Object System.Windows.Forms.TextBox
$maxitochkaPathBox.Dock = 'Fill'
$maxitochkaPathBox.Text = if (-not [string]::IsNullOrWhiteSpace($script:MaxitochkaRootPath) -and (Test-Path -LiteralPath $script:MaxitochkaRootPath)) {
    $script:MaxitochkaRootPath
}
else {
    Get-DefaultMaxitochkaPath
}
$maxitochkaPathBox.Margin = New-Object System.Windows.Forms.Padding(10, 4, 10, 4)
$maxitochkaPanel.Controls.Add($maxitochkaPathBox, 1, 0)

$scanMaxitochkaButton = New-Object System.Windows.Forms.Button
$scanMaxitochkaButton.Text = 'Найти MAX ›'
$scanMaxitochkaButton.Dock = 'Fill'
$scanMaxitochkaButton.Margin = New-Object System.Windows.Forms.Padding(0, 0, 10, 0)
$scanMaxitochkaButton.AccessibleName = 'MenuRow'
$maxitochkaPanel.Controls.Add($scanMaxitochkaButton, 2, 0)

$saveMaxitochkaPathButton = New-Object System.Windows.Forms.Button
$saveMaxitochkaPathButton.Text = 'Сохр. путь'
$saveMaxitochkaPathButton.Dock = 'Fill'
$saveMaxitochkaPathButton.Margin = New-Object System.Windows.Forms.Padding(0, 0, 10, 0)
$saveMaxitochkaPathButton.AccessibleName = 'MenuRow'
$maxitochkaPanel.Controls.Add($saveMaxitochkaPathButton, 3, 0)

$maxitochkaStatusLabel = New-Object System.Windows.Forms.Label
$maxitochkaStatusLabel.Text = 'Открытых MAX: 0 | Найдено браузеров: 0'
$maxitochkaStatusLabel.Dock = 'Fill'
$maxitochkaStatusLabel.TextAlign = 'MiddleLeft'
$maxitochkaStatusLabel.AutoEllipsis = $true
$maxitochkaStatusLabel.Margin = New-Object System.Windows.Forms.Padding(10, 0, 0, 0)
$maxitochkaStatusLabel.AccessibleName = 'MutedLabel'
$maxitochkaPanel.Controls.Add($maxitochkaStatusLabel, 4, 0)

$maxitochkaGrid = New-Object System.Windows.Forms.DataGridView
$maxitochkaGrid.Dock = 'Fill'
$maxitochkaGrid.AllowUserToAddRows = $false
$maxitochkaGrid.AllowUserToDeleteRows = $false
$maxitochkaGrid.ReadOnly = $false
$maxitochkaGrid.SelectionMode = 'FullRowSelect'
$maxitochkaGrid.MultiSelect = $true
$maxitochkaGrid.EditMode = 'EditOnEnter'
$maxitochkaGrid.AutoSizeColumnsMode = 'Fill'
$maxitochkaGrid.RowHeadersVisible = $false
$mxUseColumn = New-Object System.Windows.Forms.DataGridViewCheckBoxColumn
$mxUseColumn.Name = 'MxUse'
$mxUseColumn.HeaderText = 'Исп.'
$mxUseColumn.TrueValue = $true
$mxUseColumn.FalseValue = $false
$mxUseColumn.IndeterminateValue = $false
$mxUseColumn.FillWeight = 42
[void]$maxitochkaGrid.Columns.Add($mxUseColumn)
$maxitochkaGrid.Columns.Add('MxProfile', 'Профиль') | Out-Null
$maxitochkaGrid.Columns.Add('MxPort', 'Порт') | Out-Null
$maxitochkaGrid.Columns.Add('MxStatus', 'Статус') | Out-Null
$maxitochkaGrid.Columns.Add('MxTitle', 'Заголовок') | Out-Null
$maxitochkaGrid.Columns.Add('MxUrl', 'URL') | Out-Null
$maxitochkaGrid.Columns.Add('MxKey', 'Key') | Out-Null
$maxitochkaGrid.Columns['MxProfile'].FillWeight = 130
$maxitochkaGrid.Columns['MxPort'].FillWeight = 60
$maxitochkaGrid.Columns['MxStatus'].FillWeight = 110
$maxitochkaGrid.Columns['MxTitle'].FillWeight = 220
$maxitochkaGrid.Columns['MxUrl'].FillWeight = 220
$maxitochkaGrid.Columns['MxUrl'].Visible = $false
$maxitochkaGrid.Columns['MxKey'].Visible = $false
foreach ($columnName in @('MxProfile', 'MxPort', 'MxStatus', 'MxTitle', 'MxUrl', 'MxKey')) {
    $maxitochkaGrid.Columns[$columnName].ReadOnly = $true
}
Set-DataGridLayout $maxitochkaGrid
$maxitochkaGrid.Add_CurrentCellDirtyStateChanged({
    if ($maxitochkaGrid.IsCurrentCellDirty) {
        $maxitochkaGrid.CommitEdit([System.Windows.Forms.DataGridViewDataErrorContexts]::Commit)
    }
})
$maxitochkaGrid.Add_CellValueChanged({
    param($sender, $eventArgs)
    if ($eventArgs.RowIndex -ge 0 -and $eventArgs.ColumnIndex -eq $maxitochkaGrid.Columns['MxUse'].Index) {
        Refresh-MaxitochkaStatus
    }
})
$maxitochkaPanel.SetColumnSpan($maxitochkaGrid, 5)
$maxitochkaPanel.Controls.Add($maxitochkaGrid, 0, 1)

$buttonsPanel = New-Object System.Windows.Forms.FlowLayoutPanel
$buttonsPanel.Dock = 'Fill'
$buttonsPanel.FlowDirection = 'LeftToRight'
$buttonsPanel.WrapContents = $false
$buttonsPanel.Padding = New-Object System.Windows.Forms.Padding(0, 10, 0, 0)
$main.Controls.Add($buttonsPanel, 0, 3)

function New-ActionButton {
    param([string]$Text)
    $button = New-Object System.Windows.Forms.Button
    $button.Text = $Text
    $button.Width = 136
    $button.Height = 40
    $button.Margin = New-Object System.Windows.Forms.Padding(0, 0, 12, 0)
    $button.FlatStyle = 'Flat'
    $button.UseVisualStyleBackColor = $false
    $button.TextAlign = 'MiddleCenter'
    $button.Cursor = [System.Windows.Forms.Cursors]::Hand
    $button.FlatAppearance.BorderSize = 0
    return $button
}

$exportMaxitochkaJobButton = New-ActionButton 'Задание JSON   ›'
$exportVcfButton = New-ActionButton 'Экспорт VCF   ›'
$exportCsvButton = New-ActionButton 'Экспорт CSV   ›'
$exportMessagesButton = New-ActionButton 'Черновики TXT   ›'
$exportPayloadsButton = New-ActionButton 'MAX JSON   ›'
$addMembersButton = New-ActionButton 'Добавить в чат   ›'
$sendGroupButton = New-ActionButton 'Отправить в чат   ›'
$autoAddContactsButton = New-ActionButton 'MAX: все контакты   ›'
$autoCreateGroupButton = New-ActionButton 'MAX: общая группа   ›'
$autoOneByOneButton = New-ActionButton 'Старт'
$cancelOneByOneButton = New-ActionButton 'Стоп'
$delayedStartButton = New-ActionButton 'Отложить сообщения   ›'
$replyCenterButton = New-ActionButton 'Ответы   ›'
$autoOneByOneButton.Width = 168
$cancelOneByOneButton.Width = 138
$delayedStartButton.Width = 196
$replyCenterButton.Width = 138
$autoOneByOneButton.AccessibleName = 'PrimaryAction'
$cancelOneByOneButton.AccessibleName = 'PrimaryAction'
$delayedStartButton.AccessibleName = 'MenuRow'
$replyCenterButton.AccessibleName = 'MenuRow'
$cancelOneByOneButton.Enabled = $false

$delayedStartStatusLabel = New-Object System.Windows.Forms.Label
$delayedStartStatusLabel.Text = 'Отложено: нет'
$delayedStartStatusLabel.Width = 210
$delayedStartStatusLabel.Height = 40
$delayedStartStatusLabel.TextAlign = 'MiddleLeft'
$delayedStartStatusLabel.AutoEllipsis = $true
$delayedStartStatusLabel.Margin = New-Object System.Windows.Forms.Padding(2, 0, 8, 0)
$delayedStartStatusLabel.AccessibleName = 'MutedLabel'

$queueStatusLabel = New-Object System.Windows.Forms.Label
$queueStatusLabel.Text = 'Очередь: 0/0'
$queueStatusLabel.Width = 230
$queueStatusLabel.Height = 40
$queueStatusLabel.TextAlign = 'MiddleLeft'
$queueStatusLabel.AutoEllipsis = $true
$queueStatusLabel.Margin = New-Object System.Windows.Forms.Padding(8, 0, 0, 0)
$queueStatusLabel.AccessibleName = 'MutedLabel'

$settingsLabel = New-Object System.Windows.Forms.Label
$settingsLabel.Text = 'Настройки'
$settingsLabel.Width = 82
$settingsLabel.Height = 34
$settingsLabel.TextAlign = 'MiddleRight'
$settingsLabel.Margin = New-Object System.Windows.Forms.Padding(12, 4, 4, 4)

$themeBox = New-Object System.Windows.Forms.ComboBox
$themeBox.DropDownStyle = 'DropDownList'
$themeBox.Dock = 'Fill'
$themeBox.Width = 110
$themeBox.Height = 34
$themeBox.Margin = New-Object System.Windows.Forms.Padding(4)
Enable-ThemedComboBox $themeBox
[void]$themeBox.Items.Add('Светлая')
[void]$themeBox.Items.Add('Карбон')
[void]$themeBox.Items.Add('Темная')
[void]$themeBox.Items.Add('COURAGE')
[void]$themeBox.Items.Add('Синяя')
[void]$themeBox.Items.Add('Зеленая')
[void]$themeBox.Items.Add('Розовая')
[void]$themeBox.Items.Add('Радуга')
[void]$themeBox.Items.Add('Коричневая')
[void]$themeBox.Items.Add('Дота')
[void]$themeBox.Items.Add('Раст')
if ($themeBox.Items.Contains($script:UiTheme)) {
    $themeBox.SelectedItem = $script:UiTheme
}
else {
    $themeBox.SelectedItem = 'Карбон'
    $script:UiTheme = 'Карбон'
}

$versionLabel = New-Object System.Windows.Forms.Label
$versionLabel.Text = "Текущая версия: v$($script:AppVersion)"
$versionLabel.Dock = 'Fill'
$versionLabel.TextAlign = 'MiddleLeft'
$versionLabel.AutoEllipsis = $true
$versionLabel.Margin = New-Object System.Windows.Forms.Padding(4)
$versionLabel.AccessibleName = 'MutedLabel'

$updateLabel = New-Object System.Windows.Forms.Label
$updateLabel.Text = 'Обновление'
$updateLabel.Dock = 'Fill'
$updateLabel.TextAlign = 'MiddleLeft'
$updateLabel.AccessibleName = 'SettingsLabel'

$updateButton = New-Object System.Windows.Forms.Button
$updateButton.Text = 'Обновить'
$updateButton.Dock = 'Fill'
$updateButton.AccessibleName = 'MenuRow'

$activateWindowCheck = New-Object System.Windows.Forms.CheckBox
$activateWindowCheck.Text = 'Переключать окна MAX'
$activateWindowCheck.Dock = 'Fill'
$activateWindowCheck.Width = 178
$activateWindowCheck.Height = 34
$activateWindowCheck.Checked = [bool]$script:ActivateMaxWindow
$activateWindowCheck.Margin = New-Object System.Windows.Forms.Padding(4)

$switchDelayLabel = New-Object System.Windows.Forms.Label
$switchDelayLabel.Text = 'Пауза окна'
$switchDelayLabel.Width = 78
$switchDelayLabel.Height = 34
$switchDelayLabel.TextAlign = 'MiddleRight'
$switchDelayLabel.Margin = New-Object System.Windows.Forms.Padding(4)

$switchDelayBox = New-Object System.Windows.Forms.NumericUpDown
$switchDelayBox.Minimum = 200
$switchDelayBox.Maximum = 5000
$switchDelayBox.Increment = 100
$switchDelayBox.Value = [decimal]$script:SwitchDelayMs
$switchDelayBox.Dock = 'Left'
$switchDelayBox.Width = 78
$switchDelayBox.Height = 34
$switchDelayBox.Margin = New-Object System.Windows.Forms.Padding(4)

$opacityTrack = New-Object System.Windows.Forms.TrackBar
$opacityTrack.Minimum = 75
$opacityTrack.Maximum = 100
$opacityTrack.TickFrequency = 5
$opacityTrack.SmallChange = 1
$opacityTrack.LargeChange = 5
$opacityTrack.Value = [Math]::Max($opacityTrack.Minimum, [Math]::Min($opacityTrack.Maximum, [int]$script:AppOpacityPercent))
$opacityTrack.Dock = 'Fill'
$opacityTrack.AutoSize = $false
$opacityTrack.Height = 34
$opacityTrack.Margin = New-Object System.Windows.Forms.Padding(8, 8, 8, 8)
Enable-DoubleBuffer $opacityTrack

$opacityValueLabel = New-Object System.Windows.Forms.Label
$opacityValueLabel.Dock = 'Fill'
$opacityValueLabel.TextAlign = 'MiddleLeft'
$opacityValueLabel.AccessibleName = 'MutedLabel'
$opacityValueLabel.Text = "$($opacityTrack.Value)%"

$opacitySaveButton = New-Object System.Windows.Forms.Button
$opacitySaveButton.Text = 'Сохранить ›'
$opacitySaveButton.Dock = 'Fill'
$opacitySaveButton.AccessibleName = 'MenuRow'

$personDelayTrack = New-Object System.Windows.Forms.TrackBar
$personDelayTrack.Minimum = 10
$personDelayTrack.Maximum = 180
$personDelayTrack.TickFrequency = 10
$personDelayTrack.SmallChange = 5
$personDelayTrack.LargeChange = 15
$personDelayTrack.Value = [Math]::Max($personDelayTrack.Minimum, [Math]::Min($personDelayTrack.Maximum, [int]$script:PersonDelaySeconds))
$personDelayTrack.Dock = 'Fill'
$personDelayTrack.AutoSize = $false
$personDelayTrack.Height = 34
$personDelayTrack.Margin = New-Object System.Windows.Forms.Padding(8, 8, 8, 8)
Enable-DoubleBuffer $personDelayTrack

$personDelayValueLabel = New-Object System.Windows.Forms.Label
$personDelayValueLabel.Dock = 'Fill'
$personDelayValueLabel.TextAlign = 'MiddleLeft'
$personDelayValueLabel.AccessibleName = 'MutedLabel'
$personDelayValueLabel.Text = "$($personDelayTrack.Value) сек"

$personDelaySaveButton = New-Object System.Windows.Forms.Button
$personDelaySaveButton.Text = 'Сохранить ›'
$personDelaySaveButton.Dock = 'Fill'
$personDelaySaveButton.AccessibleName = 'MenuRow'

$peoplePerMaxBox = New-Object System.Windows.Forms.NumericUpDown
$peoplePerMaxBox.Minimum = 1
$peoplePerMaxBox.Maximum = 50
$peoplePerMaxBox.Increment = 1
$peoplePerMaxBox.Value = [decimal]([Math]::Max(1, [Math]::Min(50, [int]$script:PeoplePerMax)))
$peoplePerMaxBox.Dock = 'Left'
$peoplePerMaxBox.Width = 78
$peoplePerMaxBox.Height = 34
$peoplePerMaxBox.Margin = New-Object System.Windows.Forms.Padding(4)

$peoplePerMaxHintLabel = New-Object System.Windows.Forms.Label
$peoplePerMaxHintLabel.Dock = 'Fill'
$peoplePerMaxHintLabel.TextAlign = 'MiddleLeft'
$peoplePerMaxHintLabel.AccessibleName = 'MutedLabel'
$peoplePerMaxHintLabel.Text = 'чел. подряд'

$peoplePerMaxSaveButton = New-Object System.Windows.Forms.Button
$peoplePerMaxSaveButton.Text = 'Сохранить ›'
$peoplePerMaxSaveButton.Dock = 'Fill'
$peoplePerMaxSaveButton.AccessibleName = 'MenuRow'

$settingsMain = New-Object System.Windows.Forms.TableLayoutPanel
$settingsMain.Dock = 'Top'
$settingsMain.Height = 1080
$settingsMain.Padding = New-Object System.Windows.Forms.Padding(30, 22, 30, 22)
Enable-DoubleBuffer $settingsMain
$settingsMain.ColumnCount = 4
$settingsMain.RowCount = 15
$settingsMain.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 230))) | Out-Null
$settingsMain.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
$settingsMain.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 130))) | Out-Null
$settingsMain.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 130))) | Out-Null
$settingsMain.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 52))) | Out-Null
$settingsMain.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 52))) | Out-Null
$settingsMain.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 142))) | Out-Null
$settingsMain.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 52))) | Out-Null
$settingsMain.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 52))) | Out-Null
$settingsMain.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 52))) | Out-Null
$settingsMain.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 52))) | Out-Null
$settingsMain.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 52))) | Out-Null
$settingsMain.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 52))) | Out-Null
$settingsMain.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 52))) | Out-Null
$settingsMain.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 52))) | Out-Null
$settingsMain.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 170))) | Out-Null
$settingsMain.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 44))) | Out-Null
$settingsMain.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 34))) | Out-Null
$settingsMain.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 52))) | Out-Null
$settingsMain.RowStyles[10].Height = 54
$settingsScrollPanel = New-Object System.Windows.Forms.Panel
$settingsScrollPanel.Dock = 'Fill'
$settingsScrollPanel.AutoScroll = $true
Enable-DoubleBuffer $settingsScrollPanel
Enable-SmoothPanelScroll $settingsScrollPanel
$settingsScrollPanel.Controls.Add($settingsMain)
$settingsTab.Controls.Add($settingsScrollPanel)

$extraToolsWrap = New-Object System.Windows.Forms.TableLayoutPanel
$extraToolsWrap.Dock = 'Fill'
$extraToolsWrap.ColumnCount = 1
$extraToolsWrap.RowCount = 5
Enable-DoubleBuffer $extraToolsWrap
$extraToolsWrap.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 40))) | Out-Null
$extraToolsWrap.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 22))) | Out-Null
$extraToolsWrap.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 76))) | Out-Null
$extraToolsWrap.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 22))) | Out-Null
$extraToolsWrap.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 168))) | Out-Null
$settingsMain.SetColumnSpan($extraToolsWrap, 3)
$settingsMain.Controls.Add($extraToolsWrap, 1, 10)

$advancedSettingsButton = New-Object System.Windows.Forms.Button
$advancedSettingsButton.Text = 'Дополнительные настройки   ›'
$advancedSettingsButton.Dock = 'Left'
$advancedSettingsButton.Width = 330
$advancedSettingsButton.Height = 44
$advancedSettingsButton.Tag = $false
$advancedSettingsButton.AccessibleName = 'MenuRow'
$extraToolsWrap.Controls.Add($advancedSettingsButton, 0, 0)

$advancedAhkTitle = New-Object System.Windows.Forms.Label
$advancedAhkTitle.Text = 'AutoHotkey'
$advancedAhkTitle.Dock = 'Fill'
$advancedAhkTitle.TextAlign = 'BottomLeft'
$advancedAhkTitle.Visible = $false
$advancedAhkTitle.AccessibleName = 'AccentLabel'
$extraToolsWrap.Controls.Add($advancedAhkTitle, 0, 1)

$advancedAhkRow = New-Object System.Windows.Forms.TableLayoutPanel
$advancedAhkRow.Dock = 'Fill'
$advancedAhkRow.ColumnCount = 3
$advancedAhkRow.RowCount = 2
$advancedAhkRow.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 170))) | Out-Null
$advancedAhkRow.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
$advancedAhkRow.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 100))) | Out-Null
$advancedAhkRow.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 36))) | Out-Null
$advancedAhkRow.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 36))) | Out-Null
$advancedAhkRow.Visible = $false
$extraToolsWrap.Controls.Add($advancedAhkRow, 0, 2)

$advancedToolsTitle = New-Object System.Windows.Forms.Label
$advancedToolsTitle.Text = 'Редкие действия'
$advancedToolsTitle.Dock = 'Fill'
$advancedToolsTitle.TextAlign = 'BottomLeft'
$advancedToolsTitle.Visible = $false
$advancedToolsTitle.AccessibleName = 'AccentLabel'
$extraToolsWrap.Controls.Add($advancedToolsTitle, 0, 3)

$extraToolsPanel = New-Object System.Windows.Forms.FlowLayoutPanel
$extraToolsPanel.Dock = 'Fill'
$extraToolsPanel.FlowDirection = 'LeftToRight'
$extraToolsPanel.WrapContents = $true
$extraToolsPanel.Padding = New-Object System.Windows.Forms.Padding(0, 4, 0, 0)
$extraToolsPanel.Visible = $false
Enable-DoubleBuffer $extraToolsPanel
$extraToolsWrap.Controls.Add($extraToolsPanel, 0, 4)

$lowPerformanceModeCheck = New-Object System.Windows.Forms.CheckBox
$lowPerformanceModeCheck.Text = 'Для слабых ПК'
$lowPerformanceModeCheck.Width = 178
$lowPerformanceModeCheck.Height = 42
$lowPerformanceModeCheck.Margin = New-Object System.Windows.Forms.Padding(0, 0, 10, 10)
$lowPerformanceModeCheck.Checked = [bool]$script:LowPerformanceMode
$lowPerformanceModeCheck.AccessibleName = 'SettingsLabel'

$notificationWindowCheck = New-Object System.Windows.Forms.CheckBox
$notificationWindowCheck.Text = 'Уведомления в окне'
$notificationWindowCheck.Width = 178
$notificationWindowCheck.Height = 42
$notificationWindowCheck.Margin = New-Object System.Windows.Forms.Padding(0, 0, 10, 10)
$notificationWindowCheck.Checked = [bool]$script:NotificationWindowEnabled
$notificationWindowCheck.AccessibleName = 'SettingsLabel'

$extraToolsLabel = New-Object System.Windows.Forms.Label
$extraToolsLabel.Text = 'Дополнительно'
$extraToolsLabel.Dock = 'Fill'
$extraToolsLabel.TextAlign = 'MiddleLeft'
$extraToolsLabel.AccessibleName = 'SettingsLabel'
$settingsMain.Controls.Add($extraToolsLabel, 0, 10)

$settingsGroupBaseLabel = New-Object System.Windows.Forms.Label
$settingsGroupBaseLabel.Text = 'Базовая группа'
$settingsGroupBaseLabel.Dock = 'Fill'
$settingsGroupBaseLabel.TextAlign = 'MiddleLeft'
$settingsGroupBaseLabel.AccessibleName = 'SettingsLabel'
$settingsMain.Controls.Add($settingsGroupBaseLabel, 0, 0)
$settingsMain.Controls.Add($groupBox, 1, 0)
$settingsMain.SetColumnSpan($groupBox, 3)

$opacityLabel = New-Object System.Windows.Forms.Label
$opacityLabel.Text = 'Прозрачность'
$opacityLabel.Dock = 'Fill'
$opacityLabel.TextAlign = 'MiddleLeft'
$opacityLabel.AccessibleName = 'SettingsLabel'
$settingsMain.Controls.Add($opacityLabel, 0, 1)
$settingsMain.Controls.Add($opacityTrack, 1, 1)
$settingsMain.Controls.Add($opacityValueLabel, 2, 1)
$settingsMain.Controls.Add($opacitySaveButton, 3, 1)

$ahkLabel = New-Object System.Windows.Forms.Label
$ahkLabel.Text = 'AutoHotkey.exe'
$ahkLabel.Dock = 'Fill'
$ahkLabel.TextAlign = 'MiddleLeft'
$ahkLabel.AccessibleName = 'SettingsLabel'

$ahkTypingCheck = New-Object System.Windows.Forms.CheckBox
$ahkTypingCheck.Text = 'Использовать AHK для печати текста'
$ahkTypingCheck.Dock = 'Fill'
$ahkTypingCheck.Checked = [bool]$script:UseAhkTyping
$ahkTypingCheck.AccessibleName = 'SettingsLabel'
$advancedAhkRow.SetColumnSpan($ahkTypingCheck, 3)
$advancedAhkRow.Controls.Add($ahkTypingCheck, 0, 0)

$advancedAhkRow.Controls.Add($ahkLabel, 0, 1)

$ahkPathBox = New-Object System.Windows.Forms.TextBox
$ahkPathBox.Dock = 'Fill'
try {
    $initialAhkPath = Resolve-AhkExePath $script:AhkExePath
}
catch {
    $initialAhkPath = ''
}
$ahkPathBox.Text = if ([string]::IsNullOrWhiteSpace($initialAhkPath)) { [string]$script:AhkExePath } else { $initialAhkPath }
$script:AhkExePath = $ahkPathBox.Text
$advancedAhkRow.Controls.Add($ahkPathBox, 1, 1)

$ahkBrowseButton = New-Object System.Windows.Forms.Button
$ahkBrowseButton.Text = 'Выбрать ›'
$ahkBrowseButton.Dock = 'Fill'
$ahkBrowseButton.AccessibleName = 'MenuRow'
$advancedAhkRow.Controls.Add($ahkBrowseButton, 2, 1)

$settingsTextLabel = New-Object System.Windows.Forms.Label
$settingsTextLabel.Text = 'Текст сообщения'
$settingsTextLabel.Dock = 'Fill'
$settingsTextLabel.TextAlign = 'TopLeft'
$settingsTextLabel.AccessibleName = 'SettingsLabel'
$settingsMain.Controls.Add($settingsTextLabel, 0, 2)
$settingsMain.SetColumnSpan($messagePanel, 3)
$settingsMain.Controls.Add($messagePanel, 1, 2)

$personDelayLabel = New-Object System.Windows.Forms.Label
$personDelayLabel.Text = 'Время на человека'
$personDelayLabel.Dock = 'Fill'
$personDelayLabel.TextAlign = 'MiddleLeft'
$personDelayLabel.AccessibleName = 'SettingsLabel'
$settingsMain.Controls.Add($personDelayLabel, 0, 3)
$settingsMain.Controls.Add($personDelayTrack, 1, 3)
$settingsMain.Controls.Add($personDelayValueLabel, 2, 3)
$settingsMain.Controls.Add($personDelaySaveButton, 3, 3)

$peoplePerMaxLabel = New-Object System.Windows.Forms.Label
$peoplePerMaxLabel.Text = 'Пропись на MAX'
$peoplePerMaxLabel.Dock = 'Fill'
$peoplePerMaxLabel.TextAlign = 'MiddleLeft'
$peoplePerMaxLabel.AccessibleName = 'SettingsLabel'
$settingsMain.Controls.Add($peoplePerMaxLabel, 0, 4)
$settingsMain.Controls.Add($peoplePerMaxBox, 1, 4)
$settingsMain.Controls.Add($peoplePerMaxHintLabel, 2, 4)
$settingsMain.Controls.Add($peoplePerMaxSaveButton, 3, 4)

$settingsApiLabel = New-Object System.Windows.Forms.Label
$settingsApiLabel.Text = 'MAX API'
$settingsApiLabel.Dock = 'Fill'
$settingsApiLabel.TextAlign = 'TopRight'

$settingsThemeLabel = New-Object System.Windows.Forms.Label
$settingsThemeLabel.Text = 'Оформление'
$settingsThemeLabel.Dock = 'Fill'
$settingsThemeLabel.TextAlign = 'MiddleLeft'
$settingsThemeLabel.AccessibleName = 'SettingsLabel'
$settingsMain.Controls.Add($settingsThemeLabel, 0, 6)
$settingsMain.Controls.Add($themeBox, 1, 6)

$wallpaperLabel = New-Object System.Windows.Forms.Label
$wallpaperLabel.Text = 'Обои'
$wallpaperLabel.Dock = 'Fill'
$wallpaperLabel.TextAlign = 'MiddleLeft'
$wallpaperLabel.AccessibleName = 'SettingsLabel'
$settingsMain.Controls.Add($wallpaperLabel, 0, 7)

$wallpaperPathBox = New-Object System.Windows.Forms.TextBox
$wallpaperPathBox.Dock = 'Fill'
$wallpaperPathBox.ReadOnly = $true
$wallpaperPathBox.Text = [string]$script:WallpaperPath
$settingsMain.Controls.Add($wallpaperPathBox, 1, 7)

$wallpaperChooseButton = New-Object System.Windows.Forms.Button
$wallpaperChooseButton.Text = 'Выбрать ›'
$wallpaperChooseButton.Dock = 'Fill'
$wallpaperChooseButton.AccessibleName = 'MenuRow'
$settingsMain.Controls.Add($wallpaperChooseButton, 2, 7)

$wallpaperClearButton = New-Object System.Windows.Forms.Button
$wallpaperClearButton.Text = 'Очистить ›'
$wallpaperClearButton.Dock = 'Fill'
$wallpaperClearButton.AccessibleName = 'MenuRow'
$settingsMain.Controls.Add($wallpaperClearButton, 3, 7)

$settingsSwitchLabel = New-Object System.Windows.Forms.Label
$settingsSwitchLabel.Text = 'Окна MAX'
$settingsSwitchLabel.Dock = 'Fill'
$settingsSwitchLabel.TextAlign = 'MiddleLeft'
$settingsSwitchLabel.AccessibleName = 'SettingsLabel'
$settingsMain.Controls.Add($settingsSwitchLabel, 0, 8)
$settingsMain.Controls.Add($activateWindowCheck, 1, 8)

$settingsDelayLabel = New-Object System.Windows.Forms.Label
$settingsDelayLabel.Text = 'Пауза окна, мс'
$settingsDelayLabel.Dock = 'Fill'
$settingsDelayLabel.TextAlign = 'MiddleLeft'
$settingsDelayLabel.AccessibleName = 'SettingsLabel'
$settingsMain.Controls.Add($settingsDelayLabel, 0, 9)
$settingsMain.Controls.Add($switchDelayBox, 1, 9)

$textsPathLabel = New-Object System.Windows.Forms.Label
$textsPathLabel.Text = 'Файл текстов'
$textsPathLabel.Dock = 'Fill'
$textsPathLabel.TextAlign = 'MiddleLeft'
$textsPathLabel.AccessibleName = 'SettingsLabel'
$settingsMain.Controls.Add($textsPathLabel, 0, 5)

$messageTemplatesPathBox = New-Object System.Windows.Forms.TextBox
$messageTemplatesPathBox.Dock = 'Fill'
$messageTemplatesPathBox.ReadOnly = $true
$messageTemplatesPathBox.Text = [string]$script:MessageTemplatesPath
$settingsMain.Controls.Add($messageTemplatesPathBox, 1, 5)

$settingsBrowseTextsButton = New-Object System.Windows.Forms.Button
$settingsBrowseTextsButton.Text = 'Выбрать ›'
$settingsBrowseTextsButton.Dock = 'Fill'
$settingsBrowseTextsButton.AccessibleName = 'MenuRow'
$settingsMain.Controls.Add($settingsBrowseTextsButton, 2, 5)

$settingsClearTextsButton = New-Object System.Windows.Forms.Button
$settingsClearTextsButton.Text = 'Очистить ›'
$settingsClearTextsButton.Dock = 'Fill'
$settingsClearTextsButton.AccessibleName = 'MenuRow'
$settingsMain.Controls.Add($settingsClearTextsButton, 3, 5)

$groupExtrasLabel = New-Object System.Windows.Forms.Label
$groupExtrasLabel.Text = 'Случайные названия'
$groupExtrasLabel.Dock = 'Fill'
$groupExtrasLabel.TextAlign = 'TopLeft'
$groupExtrasLabel.AccessibleName = 'SettingsLabel'
$settingsMain.Controls.Add($groupExtrasLabel, 0, 11)

$groupExtrasBox = New-Object System.Windows.Forms.TextBox
$groupExtrasBox.Multiline = $true
$groupExtrasBox.ScrollBars = 'Vertical'
$groupExtrasBox.Dock = 'Fill'
$groupExtrasBox.Text = $script:GroupNameExtrasText
$settingsMain.SetColumnSpan($groupExtrasBox, 3)
$settingsMain.Controls.Add($groupExtrasBox, 1, 11)

$useGroupExtrasCheck = New-Object System.Windows.Forms.CheckBox
$useGroupExtrasCheck.Text = 'Брать случайное название группы из списка'
$useGroupExtrasCheck.Dock = 'Fill'
$useGroupExtrasCheck.Checked = [bool]$script:UseGroupNameExtras
$useGroupExtrasCheck.AccessibleName = 'SettingsLabel'
$settingsMain.SetColumnSpan($useGroupExtrasCheck, 2)
$settingsMain.Controls.Add($useGroupExtrasCheck, 1, 12)

$applyGroupExtrasButton = New-Object System.Windows.Forms.Button
$applyGroupExtrasButton.Text = 'Сохранить ›'
$applyGroupExtrasButton.Dock = 'Fill'
$applyGroupExtrasButton.AccessibleName = 'MenuRow'
$settingsMain.Controls.Add($applyGroupExtrasButton, 3, 12)

$groupExtrasHint = New-Object System.Windows.Forms.Label
$groupExtrasHint.Text = 'Одна строка - один вариант.'
$groupExtrasHint.Dock = 'Fill'
$groupExtrasHint.TextAlign = 'MiddleLeft'
$groupExtrasHint.AccessibleName = 'MutedLabel'
$settingsMain.SetColumnSpan($groupExtrasHint, 3)
$settingsMain.Controls.Add($groupExtrasHint, 1, 13)

$settingsMain.Controls.Add($updateLabel, 0, 14)
$settingsMain.SetColumnSpan($versionLabel, 3)
$settingsMain.Controls.Add($versionLabel, 1, 14)

$buttonsPanel.Controls.Add($autoOneByOneButton)
$buttonsPanel.Controls.Add($cancelOneByOneButton)
$buttonsPanel.Controls.Add($delayedStartButton)
$buttonsPanel.Controls.Add($delayedStartStatusLabel)
$buttonsPanel.Controls.Add($queueStatusLabel)

$extraToolsPanel.Controls.Add($notificationWindowCheck)
$extraToolsPanel.Controls.Add($lowPerformanceModeCheck)
$extraToolsPanel.Controls.Add($exportVcfButton)
$extraToolsPanel.Controls.Add($exportCsvButton)
$extraToolsPanel.Controls.Add($exportMessagesButton)
$extraToolsPanel.Controls.Add($exportMaxitochkaJobButton)
$extraToolsPanel.Controls.Add($autoAddContactsButton)
$extraToolsPanel.Controls.Add($autoCreateGroupButton)

foreach ($rareButton in @(
    $exportVcfButton,
    $exportCsvButton,
    $exportMessagesButton,
    $exportMaxitochkaJobButton,
    $autoAddContactsButton,
    $autoCreateGroupButton
)) {
    $rareButton.Width = 178
    $rareButton.Height = 42
    $rareButton.Margin = New-Object System.Windows.Forms.Padding(0, 0, 10, 10)
    $rareButton.AccessibleName = 'MenuRow'
}

Refresh-MessageTemplatesStatus
Refresh-OneByOneStatus
Refresh-DelayedStartStatus
Apply-AppTheme $script:UiTheme

$themeBox.Add_SelectedIndexChanged({
    if ($themeBox.SelectedItem) {
        $script:UiTheme = [string]$themeBox.SelectedItem
        Apply-AppTheme $script:UiTheme
        Save-ProcessingState
    }
})

$opacityTrack.Add_ValueChanged({
    $previewOpacityPercent = [Math]::Max(75, [Math]::Min(100, [int]$opacityTrack.Value))
    if ($opacityValueLabel) { $opacityValueLabel.Text = "$previewOpacityPercent%" }
})

$opacitySaveButton.Add_Click({
    $script:AppOpacityPercent = [Math]::Max(75, [Math]::Min(100, [int]$opacityTrack.Value))
    if ($opacityValueLabel) { $opacityValueLabel.Text = "$($script:AppOpacityPercent)%" }
    Apply-AppOpacity
    Save-ProcessingState
})

$personDelayTrack.Add_ValueChanged({
    $script:PersonDelaySeconds = [Math]::Max(10, [Math]::Min(180, [int]$personDelayTrack.Value))
    if ($personDelayValueLabel) { $personDelayValueLabel.Text = "$($script:PersonDelaySeconds) сек" }
})

$personDelaySaveButton.Add_Click({
    $script:PersonDelaySeconds = [Math]::Max(10, [Math]::Min(180, [int]$personDelayTrack.Value))
    if ($personDelayValueLabel) { $personDelayValueLabel.Text = "$($script:PersonDelaySeconds) сек" }
    Save-ProcessingState
})

$peoplePerMaxBox.Add_ValueChanged({
    $script:PeoplePerMax = [Math]::Max(1, [Math]::Min(50, [int]$peoplePerMaxBox.Value))
    Save-ProcessingState
})

$peoplePerMaxSaveButton.Add_Click({
    $script:PeoplePerMax = [Math]::Max(1, [Math]::Min(50, [int]$peoplePerMaxBox.Value))
    Save-ProcessingState
    [System.Windows.Forms.MessageBox]::Show("Теперь на одном MAX подряд будет прописываться: $($script:PeoplePerMax)", 'Пропись на MAX', 'OK', 'Information') | Out-Null
})

$wallpaperChooseButton.Add_Click({
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    $dialog.Filter = 'Images (*.png;*.jpg;*.jpeg;*.bmp;*.gif)|*.png;*.jpg;*.jpeg;*.bmp;*.gif|All files (*.*)|*.*'
    if (-not [string]::IsNullOrWhiteSpace($script:WallpaperPath)) {
        try {
            $dialog.InitialDirectory = Split-Path -Path $script:WallpaperPath -Parent
        }
        catch {
        }
    }
    if ($dialog.ShowDialog() -eq 'OK') {
        $script:WallpaperPath = $dialog.FileName
        Apply-AppWallpaper
        Save-ProcessingState
    }
})

$wallpaperClearButton.Add_Click({
    $script:WallpaperPath = ""
    if ($wallpaperPathBox) { $wallpaperPathBox.Text = "" }
    Clear-AppWallpaperImage
    Save-ProcessingState
    Apply-AppTheme $script:UiTheme
})

function Set-AdvancedSettingsVisible {
    param([bool]$Expanded)

    try {
        if ($settingsScrollPanel) { $settingsScrollPanel.SuspendLayout() }
        if ($settingsMain) { $settingsMain.SuspendLayout() }
        if ($extraToolsWrap) { $extraToolsWrap.SuspendLayout() }

        $advancedSettingsButton.Tag = $Expanded
        $advancedSettingsButton.Text = if ($Expanded) { 'Скрыть дополнительные настройки   ˄' } else { 'Дополнительные настройки   ›' }
        $advancedAhkTitle.Visible = $Expanded
        $advancedAhkRow.Visible = $Expanded
        $advancedToolsTitle.Visible = $Expanded
        $extraToolsPanel.Visible = $Expanded
        if ($settingsMain -and $settingsMain.RowStyles.Count -gt 10) {
            $settingsMain.RowStyles[10].Height = if ($Expanded) { 338 } else { 54 }
        }
        if ($settingsMain) {
            $settingsMain.Height = if ($Expanded) { 1366 } else { 1080 }
        }
    }
    finally {
        if ($extraToolsWrap) { $extraToolsWrap.ResumeLayout($true) }
        if ($settingsMain) { $settingsMain.ResumeLayout($true) }
        if ($settingsScrollPanel) { $settingsScrollPanel.ResumeLayout($true) }
    }
}

$advancedSettingsButton.Add_Click({
    Set-AdvancedSettingsVisible -Expanded (-not [bool]$advancedSettingsButton.Tag)
})

$notificationWindowCheck.Add_CheckedChanged({
    $enabled = [bool]$notificationWindowCheck.Checked
    if ([bool]$script:NotificationWindowEnabled -eq $enabled) { return }

    $script:NotificationWindowEnabled = $enabled
    if ($script:OneByOneStopSignal) {
        $script:OneByOneStopSignal.NotificationsEnabled = $enabled
    }
    if ($script:OneByOneRunning) {
        Show-OneByOneStopWindow
    }
    Save-ProcessingState
})

$lowPerformanceModeCheck.Add_CheckedChanged({
    $enabled = [bool]$lowPerformanceModeCheck.Checked
    if ([bool]$script:LowPerformanceMode -eq $enabled) { return }

    $script:LowPerformanceMode = $enabled
    Apply-AppTheme $script:UiTheme
    Save-ProcessingState
})

$settingsScrollPanel.Add_Resize({
    if ($settingsMain) {
        $settingsMain.Width = [Math]::Max(760, $settingsScrollPanel.ClientSize.Width - 24)
    }
})

$activateWindowCheck.Add_CheckedChanged({
    $script:ActivateMaxWindow = [bool]$activateWindowCheck.Checked
    Save-ProcessingState
})

$switchDelayBox.Add_ValueChanged({
    $script:SwitchDelayMs = [int]$switchDelayBox.Value
    Save-ProcessingState
})

$ahkTypingCheck.Add_CheckedChanged({
    $script:UseAhkTyping = [bool]$ahkTypingCheck.Checked
    $script:AhkExePath = $ahkPathBox.Text.Trim()
    Save-ProcessingState
})

$ahkPathBox.Add_TextChanged({
    $script:AhkExePath = $ahkPathBox.Text.Trim()
})

$ahkPathBox.Add_Leave({
    $script:AhkExePath = $ahkPathBox.Text.Trim()
    Save-ProcessingState
})

$ahkBrowseButton.Add_Click({
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    $dialog.Filter = 'AutoHotkey.exe (*.exe)|*.exe'
    if ($dialog.ShowDialog() -eq 'OK') {
        if (-not [IO.Path]::GetExtension($dialog.FileName).Equals('.exe', [StringComparison]::OrdinalIgnoreCase)) {
            [System.Windows.Forms.MessageBox]::Show('Выбери именно AutoHotkey.exe, не .ahk файл.', 'AutoHotkey', 'OK', 'Warning') | Out-Null
            return
        }
        $ahkPathBox.Text = $dialog.FileName
        $script:AhkExePath = $dialog.FileName
        Save-ProcessingState
    }
})

function Minimize-AppWindow {
    if ($form) {
        [MaxContactWin32]::ShowWindowAsync($form.Handle, 6) | Out-Null
    }
}

function Restore-AppWindow {
    if ($form) {
        [MaxContactWin32]::ShowWindowAsync($form.Handle, 9) | Out-Null
        $form.Activate()
        [MaxContactWin32]::SetForegroundWindow($form.Handle) | Out-Null
    }
}

function Toggle-AppMaximized {
    if ($form.WindowState -eq 'Maximized') {
        $form.WindowState = 'Normal'
        $titleMaxButton.Text = '□'
    }
    else {
        $form.WindowState = 'Maximized'
        $titleMaxButton.Text = '❐'
    }
}

$titleMinButton.Add_Click({
    Minimize-AppWindow
})

$titleMaxButton.Add_Click({
    Toggle-AppMaximized
})

$titleCloseButton.Add_Click({
    $form.Close()
})

$windowDragHandler = {
    param($sender, $eventArgs)
    if ($eventArgs.Button -eq [System.Windows.Forms.MouseButtons]::Left) {
        [void][MaxContactWin32]::ReleaseCapture()
        [void][MaxContactWin32]::SendMessage($form.Handle, 0xA1, 0x2, 0)
    }
}

$windowMaximizeHandler = {
    Toggle-AppMaximized
}

$titlePanel.Add_MouseDown($windowDragHandler)
$titleLabel.Add_MouseDown($windowDragHandler)
$titleIconLabel.Add_Click({
    Show-GoosePhrase
})
$titlePanel.Add_DoubleClick($windowMaximizeHandler)
$titleLabel.Add_DoubleClick($windowMaximizeHandler)

$form.Add_FormClosing({
    param($sender, $eventArgs)
    if ($script:OneByOneRunning) {
        Request-OneByOneStop
        Save-ProcessingState
        $eventArgs.Cancel = $true
        $maxitochkaStatusLabel.Text = 'Остановка запрошена. Дождись завершения текущего человека.'
        [System.Windows.Forms.MessageBox]::Show('Программа сейчас работает. Я остановлю ее после текущего человека, потом окно можно будет закрыть.', 'Остановка', 'OK', 'Information') | Out-Null
    }
})

$form.Add_FormClosed({
    $script:OneByOneCancelRequested = $true
    if ($script:AnswerWindowRequestTimer) {
        try { $script:AnswerWindowRequestTimer.Stop() } catch {}
        try { $script:AnswerWindowRequestTimer.Dispose() } catch {}
        $script:AnswerWindowRequestTimer = $null
    }
    if ($script:DelayedStartTimer) {
        try { $script:DelayedStartTimer.Stop() } catch {}
        try { $script:DelayedStartTimer.Dispose() } catch {}
        $script:DelayedStartTimer = $null
    }
    if ($script:OneByOneStopSignal) {
        $script:OneByOneStopSignal.Requested = $true
        $script:OneByOneStopSignal.Paused = $false
        $script:OneByOneStopSignal.Close = $true
    }
    $script:OneByOneRunning = $false
    Close-OneByOneStopWindow
    Save-ProcessingState
    if ($script:AppMutex) {
        try { $script:AppMutex.ReleaseMutex() } catch {}
        try { $script:AppMutex.Dispose() } catch {}
        $script:AppMutex = $null
    }
    if ($script:AppTitleImage) {
        try { $script:AppTitleImage.Dispose() } catch {}
        $script:AppTitleImage = $null
    }
    Clear-AppWallpaperImage
    if ($script:AppIcon) {
        try { $script:AppIcon.Dispose() } catch {}
        $script:AppIcon = $null
    }
})

$form.Add_Shown({
    Apply-AppTheme $script:UiTheme
    Refresh-DelayedStartStatus
    if (-not $script:DelayedStartTimer) {
        $script:DelayedStartTimer = New-Object System.Windows.Forms.Timer
        $script:DelayedStartTimer.Interval = 15000
        $script:DelayedStartTimer.Add_Tick({
            Invoke-DelayedStartTimerTick
        })
    }
    $script:DelayedStartTimer.Start()
})

$form.Add_KeyDown({
    param($sender, $eventArgs)
    if ($script:OneByOneRunning -and $eventArgs.KeyCode -eq [System.Windows.Forms.Keys]::Escape) {
        Request-OneByOneStop
        $eventArgs.Handled = $true
    }
})

$form.Add_Resize({
    if ($titleMaxButton) {
        $titleMaxButton.Text = if ($form.WindowState -eq 'Maximized') { '❐' } else { '□' }
    }
})

$openButton.Add_Click({
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    $dialog.Filter = 'Text files (*.txt;*.csv)|*.txt;*.csv|All files (*.*)|*.*'
    if ($dialog.ShowDialog() -eq 'OK') {
        try {
            $script:LastFilePath = $dialog.FileName
            $script:Contacts = Parse-ContactsFile $dialog.FileName
            $sameSavedFile = $false
            if (-not [string]::IsNullOrWhiteSpace($script:SavedContactFilePath)) {
                $sameSavedFile = [string]::Equals(
                    [IO.Path]::GetFullPath($script:SavedContactFilePath),
                    [IO.Path]::GetFullPath($dialog.FileName),
                    [StringComparison]::OrdinalIgnoreCase
                )
            }
            if (-not $sameSavedFile) {
                $script:OneByOneNextIndex = 0
                $script:SavedContactFilePath = $dialog.FileName
            }
            $validCount = @(Get-ValidContacts).Count
            if ($script:OneByOneNextIndex -gt $validCount) {
                $script:OneByOneNextIndex = $validCount
            }
            Save-ProcessingState
            $fileLabel.Text = Split-Path -Path $dialog.FileName -Leaf
            Refresh-Grid
        }
        catch {
            [System.Windows.Forms.MessageBox]::Show("Не удалось прочитать файл: $($_.Exception.Message)", 'Ошибка', 'OK', 'Error') | Out-Null
        }
    }
})

$loadTextsButton.Add_Click({
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    $dialog.Filter = 'Text files (*.txt)|*.txt|All files (*.*)|*.*'
    if ($dialog.ShowDialog() -eq 'OK') {
        try {
            Load-MessageTemplatesFromPath $dialog.FileName
            [System.Windows.Forms.MessageBox]::Show("Загружено текстов: $($script:MessageTemplates.Count).`nРазделитель между текстами: -------", 'Тексты', 'OK', 'Information') | Out-Null
        }
        catch {
            [System.Windows.Forms.MessageBox]::Show("Не удалось прочитать тексты: $($_.Exception.Message)", 'Тексты', 'OK', 'Error') | Out-Null
        }
    }
})

$clearTextsButton.Add_Click({
    Clear-MessageTemplates
})

$settingsBrowseTextsButton.Add_Click({
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    $dialog.Filter = 'Text files (*.txt)|*.txt|All files (*.*)|*.*'
    if ($dialog.ShowDialog() -eq 'OK') {
        try {
            Load-MessageTemplatesFromPath $dialog.FileName
            [System.Windows.Forms.MessageBox]::Show("Файл текстов сохранен в настройках.`nТекстов: $($script:MessageTemplates.Count)", 'Настройки', 'OK', 'Information') | Out-Null
        }
        catch {
            [System.Windows.Forms.MessageBox]::Show("Не удалось прочитать тексты: $($_.Exception.Message)", 'Настройки', 'OK', 'Error') | Out-Null
        }
    }
})

$settingsClearTextsButton.Add_Click({
    Clear-MessageTemplates
})

$applyGroupExtrasButton.Add_Click({
    Set-GroupNameExtrasFromText $groupExtrasBox.Text
    $script:UseGroupNameExtras = [bool]$useGroupExtrasCheck.Checked
    Save-ProcessingState
    [System.Windows.Forms.MessageBox]::Show("Дополнительных названий групп: $($script:GroupNameExtras.Count)", 'Настройки', 'OK', 'Information') | Out-Null
})

$useGroupExtrasCheck.Add_CheckedChanged({
    $script:UseGroupNameExtras = [bool]$useGroupExtrasCheck.Checked
    Save-ProcessingState
})

$exportVcfButton.Add_Click({
    $path = Choose-SavePath 'vCard (*.vcf)|*.vcf' 'contacts.vcf'
    if ($path) {
        Export-VCard -Path $path -GroupName $groupBox.Text.Trim()
        [System.Windows.Forms.MessageBox]::Show("VCF сохранен:`n$path", 'Готово', 'OK', 'Information') | Out-Null
    }
})

$exportCsvButton.Add_Click({
    $path = Choose-SavePath 'CSV (*.csv)|*.csv' 'contacts.csv'
    if ($path) {
        Export-CsvFile -Path $path
        [System.Windows.Forms.MessageBox]::Show("CSV сохранен:`n$path", 'Готово', 'OK', 'Information') | Out-Null
    }
})

$exportMessagesButton.Add_Click({
    $path = Choose-SavePath 'Text (*.txt)|*.txt' 'message_drafts.txt'
    if ($path) {
        Export-Messages -Path $path -Template $messageBox.Text -GroupName $groupBox.Text.Trim()
        [System.Windows.Forms.MessageBox]::Show("Черновики сохранены:`n$path", 'Готово', 'OK', 'Information') | Out-Null
    }
})

$exportPayloadsButton.Add_Click({
    $path = Choose-SavePath 'JSON (*.json)|*.json' 'max_payloads.json'
    if ($path) {
        Export-MaxPayloads -Path $path -Template $messageBox.Text -GroupName $groupBox.Text.Trim() -ChatId $chatIdBox.Text.Trim()
        [System.Windows.Forms.MessageBox]::Show("JSON сохранен:`n$path", 'Готово', 'OK', 'Information') | Out-Null
    }
})

function Save-MaxitochkaRootPathFromBox {
    param([switch]$ShowMessage)

    $root = $maxitochkaPathBox.Text.Trim()
    if ([string]::IsNullOrWhiteSpace($root) -or -not (Test-Path -LiteralPath $root)) {
        if ($ShowMessage) {
            [System.Windows.Forms.MessageBox]::Show('Укажи существующую папку Maxitochka, например C:\Users\...\Desktop\3\Maxitochka.', 'Maxitochka', 'OK', 'Warning') | Out-Null
        }
        return $false
    }

    try {
        $root = [IO.Path]::GetFullPath($root)
        $maxitochkaPathBox.Text = $root
    }
    catch {
    }

    $script:MaxitochkaRootPath = $root
    Save-ProcessingState
    if ($ShowMessage) {
        $maxitochkaStatusLabel.Text = "Путь сохранен: $root"
        [System.Windows.Forms.MessageBox]::Show("Путь Maxitochka сохранен:`n$root", 'Maxitochka', 'OK', 'Information') | Out-Null
    }
    return $true
}

$saveMaxitochkaPathButton.Add_Click({
    [void](Save-MaxitochkaRootPathFromBox -ShowMessage)
})

$maxitochkaPathBox.Add_Leave({
    [void](Save-MaxitochkaRootPathFromBox)
})

$scanMaxitochkaButton.Add_Click({
    try {
        if (-not (Save-MaxitochkaRootPathFromBox -ShowMessage)) { return }
        $root = $script:MaxitochkaRootPath

        $scanMaxitochkaButton.Enabled = $false
        $saveMaxitochkaPathButton.Enabled = $false
        $maxitochkaStatusLabel.Text = 'Сканирую открытые MAX...'
        Show-GooseLoading -Owner $form -Text 'Гусь ищет открытые MAX...'
        [System.Windows.Forms.Application]::DoEvents()
        Update-GooseLoadingText 'Проверяю окна Maxitochka и порты...'
        $script:MaxitochkaSessions = Get-MaxitochkaOpenSessions $root
        Update-GooseLoadingText "Найдено браузеров: $($script:MaxitochkaSessions.Count)"
        Refresh-MaxitochkaGrid
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show("Ошибка сканирования Maxitochka: $($_.Exception.Message)", 'Maxitochka', 'OK', 'Error') | Out-Null
    }
    finally {
        Hide-GooseLoading
        $scanMaxitochkaButton.Enabled = $true
        $saveMaxitochkaPathButton.Enabled = $true
    }
})

$exportMaxitochkaJobButton.Add_Click({
    $path = Choose-SavePath 'JSON (*.json)|*.json' 'maxitochka_job.json'
    if ($path) {
        Export-MaxitochkaJob -Path $path -Template $messageBox.Text -GroupName $groupBox.Text.Trim()
        [System.Windows.Forms.MessageBox]::Show("Задание сохранено:`n$path", 'Готово', 'OK', 'Information') | Out-Null
    }
})

$autoAddContactsButton.Add_Click({ Add-ContactsViaMaxitochka })
$autoCreateGroupButton.Add_Click({ Create-GroupViaMaxitochka })
$autoOneByOneButton.Add_Click({
    Invoke-OneByOneViaMaxitochka
})
$delayedStartButton.Add_Click({
    Show-DelayedStartDialog
})
$cancelOneByOneButton.Add_MouseDown({ Request-OneByOneStop })
$cancelOneByOneButton.Add_Click({ Request-OneByOneStop })
$addMembersButton.Add_Click({ Add-MaxMembers })
$sendGroupButton.Add_Click({ Send-GroupMessage })

if (-not $NoGui) {
    [void]$form.ShowDialog()
}












