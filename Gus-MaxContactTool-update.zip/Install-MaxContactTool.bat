@echo off
chcp 65001 >nul
setlocal

set "SRC=%~dp0"
set "DST=%USERPROFILE%\Desktop\MaxContactTool"
set "DESKTOP_RUN=%USERPROFILE%\Desktop\Gus-MaxContactTool.bat"
set "UPDATE_SOURCE="
if exist "%SRC%update_source.txt" set /p UPDATE_SOURCE=<"%SRC%update_source.txt"

echo Installing MaxContactTool...
echo Source: "%SRC%"
echo Target: "%DST%"

if not exist "%DST%" mkdir "%DST%"
if not exist "%DST%" (
    echo Failed to create target folder.
    pause
    exit /b 1
)

for %%F in (
    Install-MaxContactTool.bat
    MaxContactTool.ps1
    Run-MaxContactTool.bat
    Run-MaxContactTool.vbs
    gus_update.json
    Gus-MaxContactTool-update.zip
    VERSION.txt
    update_source.txt
    update_channel.txt
    max_contact_replies.json
    README.md
    sample_contacts.txt
    sample_messages.txt
    type_text_ahk_v1.ahk
    type_text_ahk_v2.ahk
) do (
    if exist "%SRC%%%F" copy /Y "%SRC%%%F" "%DST%\" >nul
)

if not "%UPDATE_SOURCE%"=="" (
    > "%DST%\update_source.txt" echo %UPDATE_SOURCE%
    > "%DST%\update_channel.txt" echo %UPDATE_SOURCE%
)
> "%DST%\VERSION.txt" echo 1.9.5

if exist "%SRC%assets" (
    xcopy "%SRC%assets" "%DST%\assets\" /E /I /Y >nul
)

(
    echo @echo off
    echo wscript.exe "%DST%\Run-MaxContactTool.vbs"
) > "%DESKTOP_RUN%"

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "try { Get-ChildItem -LiteralPath '%DST%' -Recurse -Force | Unblock-File -ErrorAction SilentlyContinue } catch {}" >nul 2>nul

echo.
echo Installed.
echo Start from: "%DESKTOP_RUN%"
echo max_contact_state.json is not overwritten, so old PC paths are not moved.
echo In the app, choose the Maxitochka folder and press the save-path button.
pause

