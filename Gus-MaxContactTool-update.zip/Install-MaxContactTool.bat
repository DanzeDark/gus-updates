@echo off
chcp 65001 >nul
setlocal

set "SRC=%~dp0"
set "DST=%USERPROFILE%\Desktop\MaxContactTool"
set "DESKTOP_RUN=%USERPROFILE%\Desktop\Gus-MaxContactTool.bat"
set "UPDATE_SOURCE="
if exist "%SRC%update_source.txt" set /p UPDATE_SOURCE=<"%SRC%update_source.txt"

echo Installing MaxContactTool...
echo Source: "%SRC%"
echo Target: "%DST%"

if not exist "%DST%" mkdir "%DST%"
if not exist "%DST%" (
    echo Failed to create target folder.
    pause
    exit /b 1
)

for %%F in (
    Gus-MaxContactTool.exe
    Install-MaxContactTool.bat
    MaxContactTool.ps1
    Run-MaxContactTool.bat
    Run-MaxContactTool.vbs
    gus_update.json
    gus_accounts.json
    Gus-MaxContactTool-update.zip
    VERSION.txt
    update_source.txt
    update_channel.txt
    max_contact_replies.json
    README.md
    sample_contacts.txt
    sample_messages.txt
    type_text_ahk_v1.ahk
    type_text_ahk_v2.ahk
) do (
    if exist "%SRC%%%F" copy /Y "%SRC%%%F" "%DST%\" >nul
)

if not "%UPDATE_SOURCE%"=="" (
    > "%DST%\update_source.txt" echo %UPDATE_SOURCE%
    > "%DST%\update_channel.txt" echo %UPDATE_SOURCE%
)
if not exist "%DST%\VERSION.txt" (
    if exist "%SRC%VERSION.txt" (
        copy /Y "%SRC%VERSION.txt" "%DST%\VERSION.txt" >nul
    )
)

if exist "%SRC%assets" (
    xcopy "%SRC%assets" "%DST%\assets\" /E /I /Y >nul
)

if exist "%SRC%Maxitochka" (
    xcopy "%SRC%Maxitochka" "%DST%\Maxitochka\" /E /I /Y >nul
)

(
    echo @echo off
    if exist "%DST%\Gus-MaxContactTool.exe" (
        echo start "" "%DST%\Gus-MaxContactTool.exe"
    ) else (
        echo wscript.exe "%DST%\Run-MaxContactTool.vbs"
    )
) > "%DESKTOP_RUN%"

if exist "%DST%\Maxitochka\Maxitochka.exe" (
    (
        echo @echo off
        echo start "" "%DST%\Maxitochka\Maxitochka.exe"
    ) > "%USERPROFILE%\Desktop\Maxitochka.bat"
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "try { Get-ChildItem -LiteralPath '%DST%' -Recurse -Force | Unblock-File -ErrorAction SilentlyContinue } catch {}" >nul 2>nul

echo.
echo Installed.
echo Start from: "%DESKTOP_RUN%"
echo max_contact_state.json is not overwritten, so old PC paths are not moved.
echo In the app, choose the Maxitochka folder and press the save-path button.
pause

