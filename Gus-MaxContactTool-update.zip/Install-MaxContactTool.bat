@echo off
chcp 65001 >nul
setlocal

set "SCRIPT=%~dp0Install-MaxContactTool.ps1"
if not exist "%SCRIPT%" (
    echo Installer script not found:
    echo "%SCRIPT%"
    pause
    exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%SCRIPT%" -SourceRoot "%~dp0"
if errorlevel 1 (
    echo.
    echo Installer failed.
    pause
    exit /b 1
)

pause
